# Prompt Besar 2 Handoff

Only proceed after P1 R3 Preview UAT PASS.
Prompt Besar 2 scope: reconciliation, idempotent replay/failback to Firebase, full failure drill, final Production gate.
