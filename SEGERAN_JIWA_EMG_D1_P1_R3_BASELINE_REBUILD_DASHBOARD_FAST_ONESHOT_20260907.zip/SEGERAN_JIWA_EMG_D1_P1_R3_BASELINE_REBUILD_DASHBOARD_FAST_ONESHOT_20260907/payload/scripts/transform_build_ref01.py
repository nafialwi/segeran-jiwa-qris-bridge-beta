#!/usr/bin/env python3
from pathlib import Path

path = Path('scripts/build-ref01.mjs')
s = path.read_text()
if 'EMG_D1_P1_ENTRY' in s or 'DASHBOARD_FAST_P1_ENTRY' in s:
    raise SystemExit('HARD STOP: EMG-D1 P1/R2 already applied')

entry = "const ENTRY='<script type=\"module\" src=\"./src/ref01-entry.js\" data-sj-ref01-entry=\"true\"></script>';"
if s.count(entry) != 1:
    raise SystemExit('HARD STOP: REF01 ENTRY anchor not unique')
insert = (
    "const DASHBOARD_FAST_P1_ENTRY='<script src=\"./src/compat/emg-d1-p1-dashboard-fast.js\" data-sj-emg-d1-p1-dashboard-fast=\"true\"></script>';\n"
    "const EMG_D1_P1_CONFIG_ENTRY='<script src=\"./src/compat/emg-d1-p1-config.js\" data-sj-emg-d1-p1-config=\"true\"></script>';\n"
    "const EMG_D1_P1_ENTRY='<script src=\"./src/compat/emg-d1-p1-emergency.js\" data-sj-emg-d1-p1=\"true\"></script>';\n" + entry
)
s = s.replace(entry, insert, 1)

# Dashboard fast compat must load after the Product Cup UI compat but before the frozen R6/REF01 tail.
needle_dashboard = '${PRODUCT_CUP_UI_ENTRY}\\n${R6D_SALES_RECURSION_ENTRY}'
if s.count(needle_dashboard) != 1:
    raise SystemExit('HARD STOP: Product UI -> frozen R6 tail anchor not unique')
s = s.replace(needle_dashboard, '${PRODUCT_CUP_UI_ENTRY}\\n${DASHBOARD_FAST_P1_ENTRY}\\n${R6D_SALES_RECURSION_ENTRY}', 1)

# D1 launcher/config are allowed after the frozen REF01 module entry. They are independent standby surfaces.
needle_tail = '${ENTRY}\\n</body>`);'
if s.count(needle_tail) != 1:
    raise SystemExit('HARD STOP: build tail anchor not unique')
s = s.replace(needle_tail, '${ENTRY}\\n${EMG_D1_P1_CONFIG_ENTRY}\\n${EMG_D1_P1_ENTRY}\\n</body>`);', 1)

path.write_text(s)
print('EMG-D1 P1 R2 build-ref01 transform applied (Cup-01B + dashboard-fast + frozen tail preserved)')
