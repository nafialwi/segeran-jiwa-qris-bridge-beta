# EMG-D1-P1 R3 Preview UAT

1. Beranda Owner should render immediately from local/cloudData cache; exact Firebase refresh runs in background.
2. Emergency D1 launcher remains explicit/manual, never automatic failover.
3. Emergency payment methods: Tunai, Transfer, QRIS Manual.
4. Open/close emergency shift and expense path work in drill mode.
5. Normal Firebase POS, QRIS R6, Cup-01B mapping remain unchanged.
