# EMG-D1-P1 R3 — READ FIRST

Correction package untuk kegagalan P1 R2 pada baseline Cup-01B.

Root cause: `main` sudah membawa authority/build Cup-01B, tetapi `dist-ref01/index.html` yang ter-commit masih stale. Test Cup-01B membaca `dist-ref01` langsung, sehingga baseline test gagal sebelum P1 sempat diterapkan.

R3 memaksa `rm -f dist-ref01/.ref01-build-fingerprint && npm run build:ref01` SEBELUM baseline Cup-01B test. Setelah itu baru P1 D1 + Fast Beranda dijalankan.

R3 memakai branch/worktree baru dan tidak menyentuh failed R2 worktree.
