# Rollback

P0-BW01 changes only:
- `src/compat/rc01-qris-deferred-settlement-compat.js`
- `src/compat/rc01-qris-manual-bypass.js`
- `tests/p0-bw01-bandwidth-hardening.test.mjs`

After Production, preferred rollback is a one-commit revert of the P0-BW01 commit. Do not delete Firebase transactions/evidence to address bandwidth.

If Preview fails before Production, simply discard/recreate the hotfix branch from `main` rather than force-applying.
