# SESSION 2 — GITHUB ROOT UPLOAD → CODESPACES

Workflow ini dibuat khusus karena user tidak bisa upload file melalui Codespaces.

## Aturan utama
- Upload hanya ke temporary branch `transfer/p0-bw01-upload`.
- Jangan upload ZIP ke `main`.
- File ZIP harus berada di root repository.
- Nama file harus persis: `SEGERAN_JIWA_LEGACY_P0_BW01_SESSION2_GITHUB_ROOT_READY_20260906.zip`.
- Temporary branch harus berasal dari baseline Production `292bfc2` dan hanya boleh menambah satu file ZIP tersebut.

## Setelah upload melalui GitHub web
Di Codespaces:

```bash
git fetch origin
git switch transfer/p0-bw01-upload
git pull --ff-only origin transfer/p0-bw01-upload
rm -rf /tmp/p0bw01-session2
mkdir -p /tmp/p0bw01-session2
unzip -q SEGERAN_JIWA_LEGACY_P0_BW01_SESSION2_GITHUB_ROOT_READY_20260906.zip -d /tmp/p0bw01-session2
bash /tmp/p0bw01-session2/SEGERAN_JIWA_LEGACY_P0_BW01_SESSION2_GITHUB_ROOT_READY_20260906/SESSION2_FROM_GITHUB_ROOT_UPLOAD.sh \
  "$PWD/SEGERAN_JIWA_LEGACY_P0_BW01_SESSION2_GITHUB_ROOT_READY_20260906.zip"
```

Wrapper akan fail-closed bila branch, baseline, file transfer, checksum package, atau working tree tidak sesuai. Jika lolos, wrapper membuat branch `p0-bw01-firebase-bandwidth` langsung dari `292bfc2`, lalu menjalankan apply dan full regression dari package P0-BW01.
