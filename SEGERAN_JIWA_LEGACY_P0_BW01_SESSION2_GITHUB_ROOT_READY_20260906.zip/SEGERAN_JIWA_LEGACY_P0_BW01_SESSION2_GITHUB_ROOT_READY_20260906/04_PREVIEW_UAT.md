# Preview UAT — P0-BW01

Use the real POS device/browser profile.

Critical checks:
1. Login as the normal cashier/owner used operationally.
2. Wait a few seconds after login, then open an ordinary QRIS sale.
3. Manual QRIS page must still appear; checkbox gate and QRIS accounting behavior remain unchanged.
4. Tunai, Transfer, and Kasbon still open their previous flows.
5. If there is no unresolved parked QRIS, QRIS must proceed normally after evidence listener initialization.
6. Historical parked/matched QRIS surface must still be viewable/recoverable if such evidence exists.
7. If an unresolved parked QRIS exists, opening a second QRIS must be blocked.
8. Shift open/close smoke test must PASS.
9. No repeated Firebase reconnect/error banner should appear.

Optional diagnostic if browser console is available:
`SJRC01S10AQrisCompat.diagnostics()`

Expected normal result: no repeating `permissionDenied=true` listener error. If filtered queries are denied, the one-shot fallback may be visible in `fallbacks` but must not repeat on a fixed timer.
