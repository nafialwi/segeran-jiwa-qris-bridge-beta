# Firebase Usage Observation

Do not judge by the existing 16.67 GB total; consumed quota does not reset when code is fixed.

After Production hotfix, compare **growth rate** rather than total:
- Rules evaluations should stop increasing at the prior polling-like rate;
- Downloads growth should become dramatically flatter;
- active client count can remain similar without generating hundreds of thousands of recurring evidence reads.

Old QRIS polling scale sanity check: one continuously open client could run about 61,714 refresh cycles/day, with roughly three subtree reads per cycle (~185,000 subtree reads/day/client). P0-BW01 removes that fixed Firebase read loop entirely.

If growth remains unexpectedly high after a meaningful active-use window, proceed to a narrowly-scoped P0-BW02 for the secondary bounded recovery readers identified in `03_SECONDARY_BANDWIDTH_AUDIT.md` rather than migrating databases immediately.
