# P0-BW01 — READ FIRST

Scope: **Segeran Jiwa POS legacy/current Production only. BUKAN POS Next.**

Expected Production baseline: short commit `292bfc2`.
Zero-cost policy remains mandatory.

This package removes the dominant Firebase bandwidth pattern found in the deployed QRIS deferred-settlement compatibility layer: full pending/signals evidence scans every 1.4 seconds per active client.

Production is NOT to be changed directly. Apply on a branch, run the automated gate, deploy Preview, perform real-device UAT, then request user approval before Production.

`LEGACY-CUP-01A` remains PAUSED until P0-BW01 is deployed and bandwidth growth is materially lower.
