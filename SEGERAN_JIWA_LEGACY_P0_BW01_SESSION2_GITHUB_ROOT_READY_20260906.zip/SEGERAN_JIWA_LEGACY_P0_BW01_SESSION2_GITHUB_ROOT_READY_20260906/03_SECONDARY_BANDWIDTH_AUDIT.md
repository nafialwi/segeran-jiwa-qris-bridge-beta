# Secondary Bandwidth Audit

The 1.4-second QRIS full-subtree polling remains the P0 target by a wide margin. Additional runtime inspection found:

1. Production Architecture P3 supersedes the old monolithic `/global` listener. Current listeners are per-path and have cleanup via `stopGlobalListeners()`.
2. Device session heartbeat writes approximately every 60 seconds and watches only the current device row. This is not a plausible explanation for 16.67 GB downloads.
3. QRIS Signal Beta already uses 24-hour lookback queries for signals/pending/events rather than an unlimited full-history listener.
4. Two secondary bounded recovery readers remain in the legacy inline baseline:
   - costing reservation recovery: query `limitToLast(60)`, effectively gated to about once every 30 seconds;
   - refund costing recovery for Owner: query `limitToLast(80)`, gated to about once every 15 seconds. P3 already maintains a bounded refunds listener, so this may be redundant.

These secondary readers are deliberately not mixed into P0-BW01 because changing the large inline legacy baseline would substantially widen hotfix risk. After QRIS hotfix Production deployment, Firebase Usage determines whether a follow-up P0-BW02 is necessary.
