# P0-BW01 Implementation Report

## Root cause addressed
The deployed compatibility layer called `refreshEvidence()` every 1.4 seconds. A refresh performed up to three full QRIS subtree reads: pending, signals, and pending again. This is the strongest source-level explanation for the ~930K Rules Allows and abnormal 16.67 GB RTDB downloads.

## Hotfix design
P0-BW01 does not increase the polling interval. It removes fixed Firebase evidence polling and replaces it with event-driven, filtered RTDB query listeners:

- four pending listeners filtered by unresolved status: `WAITING_QRIS`, `MATCHED`, `FINALIZING`, `MANUAL_FALLBACK`;
- one signals listener filtered to `resolutionState = REVIEW_REQUIRED`;
- late-review cashier ownership is resolved only through exact pending-ID reads when needed;
- listener teardown/rebind is deterministic when cashier identity changes;
- a one-shot fallback to the old evidence reader exists only if the filtered listener fails, never on a timer;
- listener/read errors are recorded locally through `SJRC01S10AQrisCompat.diagnostics()` / `window.__SJ_P0_BW01_DIAGNOSTICS`, including permission-denied classification.

## Safety compatibility
Manual QRIS Bypass remains the QRIS ordinary-sale UI. The patch additionally makes it consult the existing parked-payment safety gate before opening a new manual QRIS payment, preserving second-QRIS blocking while unresolved parked evidence exists.

No Firebase schema migration, no transaction writer change, no historical QRIS deletion, and no database provider migration are included.
