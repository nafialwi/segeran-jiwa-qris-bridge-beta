#!/usr/bin/env bash
set -euo pipefail

EXPECTED_TRANSFER_BRANCH="transfer/p0-bw01-upload"
EXPECTED_BASELINE="292bfc2"
WORK_BRANCH="p0-bw01-firebase-bandwidth"
ZIP_NAME="SEGERAN_JIWA_LEGACY_P0_BW01_SESSION2_GITHUB_ROOT_READY_20260906.zip"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIP_PATH="${1:-}"

hard_stop() {
  echo >&2
  echo "HARD STOP: $*" >&2
  echo "Tidak ada source Production yang diubah." >&2
  exit 1
}

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  hard_stop "Jalankan perintah dari dalam repository Segeran Jiwa POS legacy di Codespaces."
fi

REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT"

CURRENT_BRANCH="$(git branch --show-current)"
[[ "$CURRENT_BRANCH" == "$EXPECTED_TRANSFER_BRANCH" ]] || \
  hard_stop "Branch saat ini '$CURRENT_BRANCH'. Harus '$EXPECTED_TRANSFER_BRANCH'. Jangan jalankan dari main."

[[ -z "$(git status --porcelain)" ]] || {
  git status --short >&2
  hard_stop "Working tree harus bersih setelah file ZIP sudah di-commit lewat GitHub."
}

git cat-file -e "${EXPECTED_BASELINE}^{commit}" 2>/dev/null || \
  hard_stop "Baseline $EXPECTED_BASELINE tidak ditemukan di repository ini. Jalankan git fetch origin dahulu."

git merge-base --is-ancestor "$EXPECTED_BASELINE" HEAD || \
  hard_stop "Transfer branch bukan turunan baseline $EXPECTED_BASELINE."

mapfile -t CHANGED < <(git diff --name-only "$EXPECTED_BASELINE..HEAD")
if [[ ${#CHANGED[@]} -ne 1 || "${CHANGED[0]}" != "$ZIP_NAME" ]]; then
  echo "Perubahan antara baseline $EXPECTED_BASELINE dan transfer branch:" >&2
  printf '  %s\n' "${CHANGED[@]:-<tidak ada>}" >&2
  hard_stop "Transfer branch harus hanya berisi satu file ZIP di root: $ZIP_NAME"
fi

if [[ -z "$ZIP_PATH" ]]; then
  ZIP_PATH="$REPO_ROOT/$ZIP_NAME"
fi
[[ -f "$ZIP_PATH" ]] || hard_stop "ZIP tidak ditemukan: $ZIP_PATH"

ACTUAL_ZIP_SHA="$(sha256sum "$ZIP_PATH" | awk '{print $1}')"
echo "ZIP SHA256: $ACTUAL_ZIP_SHA"

[[ -f "$SCRIPT_DIR/SHA256SUMS.txt" ]] || hard_stop "SHA256SUMS.txt tidak ditemukan di package hasil extract."
(
  cd "$SCRIPT_DIR"
  sha256sum -c SHA256SUMS.txt
) || hard_stop "Validasi isi package gagal. Jangan lanjut."

if git show-ref --verify --quiet "refs/heads/$WORK_BRANCH"; then
  hard_stop "Branch kerja '$WORK_BRANCH' sudah ada. Jangan overwrite otomatis."
fi

echo
echo "Gate transfer PASS. Membuat branch kerja bersih dari baseline $EXPECTED_BASELINE ..."
git switch -c "$WORK_BRANCH" "$EXPECTED_BASELINE"

echo
echo "Menjalankan P0-BW01 apply + full verification ..."
bash "$SCRIPT_DIR/APPLY_P0_BW01.sh"

echo
echo "============================================================"
echo "SESSION 2 LOCAL GATE PASS"
echo "Branch kerja: $WORK_BRANCH"
echo "Baseline:     $EXPECTED_BASELINE"
echo "Production belum disentuh."
echo "============================================================"
echo
echo "Status perubahan yang akan di-commit:"
git status --short

echo
echo "NEXT COMMANDS (jalankan hanya bila output di atas PASS):"
echo "  git add src/compat/rc01-qris-deferred-settlement-compat.js src/compat/rc01-qris-manual-bypass.js tests/p0-bw01-bandwidth-hardening.test.mjs"
echo "  git commit -m \"fix: harden legacy QRIS Firebase bandwidth\""
echo "  git push -u origin $WORK_BRANCH"
echo
echo "Setelah push: buka Cloudflare Preview untuk branch $WORK_BRANCH. Jangan promote ke Production."
