import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';

const ROOT=dirname(dirname(fileURLToPath(import.meta.url)));
const DEFERRED=readFileSync(join(ROOT,'src','compat','rc01-qris-deferred-settlement-compat.js'),'utf8');
const MANUAL=readFileSync(join(ROOT,'src','compat','rc01-qris-manual-bypass.js'),'utf8');

test('P0-BW01 removes fixed 1.4 second Firebase evidence polling',()=>{
  assert.equal(DEFERRED.includes('setInterval(refreshEvidence,1400)'),false);
  assert.equal(/setInterval\s*\(\s*refreshEvidence\s*,/.test(DEFERRED),false);
});

test('P0-BW01 observes only unresolved pending statuses and review-required signals',()=>{
  assert.match(DEFERRED,/UNRESOLVED_STATUS/);
  assert.match(DEFERRED,/orderByChild\(['"]status['"]\)\.equalTo\(status\)/);
  assert.match(DEFERRED,/orderByChild\(['"]resolutionState['"]\)\.equalTo\(['"]REVIEW_REQUIRED['"]\)/);
  assert.equal(DEFERRED.includes("ref(runtime.roots.qris+'/pending').once('value')"),false);
  assert.equal(DEFERRED.includes("ref(runtime.roots.qris+'/signals').once('value')"),false);
});

test('P0-BW01 listener lifecycle has deterministic cleanup and owner rebinding',()=>{
  assert.match(DEFERRED,/function stopEvidenceWatch\(/);
  assert.match(DEFERRED,/\.off\(['"]value['"]/);
  assert.match(DEFERRED,/evidenceOwner/);
  assert.match(DEFERRED,/cashierId\(\)/);
});

test('deferred QRIS compatibility exposes the second-QRIS safety gate',()=>{
  assert.match(DEFERRED,/guardSecondQris\s*:\s*guardSecondQris/);
});

test('manual QRIS bypass consults parked-payment safety before opening manual QRIS',()=>{
  assert.match(MANUAL,/SJRC01S10AQrisCompat/);
  assert.match(MANUAL,/guardSecondQris/);
  assert.match(MANUAL,/if\([^\n]*guardSecondQris\(\)[^\n]*\)return false/);
});

test('P0-BW01 records listener/read failures locally without adding Firebase writes',()=>{
  assert.match(DEFERRED,/BW01/);
  assert.match(DEFERRED,/permission/i);
  assert.match(DEFERRED,/diagnostic/i);
});

test('event listener installation is re-entrant safe when Firebase value callback fires immediately',()=>{
  const code=DEFERRED;
  let onCalls=0;
  const listeners=[];
  function query(path){
    const q={path,child:null,value:null,
      orderByChild(child){this.child=child;return this},
      equalTo(value){this.value=value;return this},
      on(event,cb){assert.equal(event,'value');onCalls++;listeners.push({path:this.path,child:this.child,value:this.value,cb});cb({val:()=>({})});return cb},
      off(){return true}
    };return q;
  }
  const runtime={
    db:{ref:path=>query(path)},roots:{qris:'qris-root'},
    policy:{isUnresolvedParkedPending:()=>false,isLateQuarantineStatus:()=>false,classifyLateSignalConflict:()=>null},
    readPending:async()=>null,findOwnedUnresolvedParked:async()=>[],findLateReviewSignals:async()=>[],writer:{}
  };
  const context={console,window:null,globalThis:null,currentLoginId:'kasir01',
    __SJ_QRIS_DEFERRED_SETTLEMENT_RUNTIME:runtime,
    SJQrisSignalCore:{cartFingerprint:()=>'',matchSignal:()=>({})},
    SJQrisSignalBeta:{status:()=>({activePendingId:''}),matchSignal:()=>({})},
    SJCommercialFinalV5961:{cartMethod:'Tunai',openPayment:()=>true},
    setInterval:()=>1,clearInterval:()=>{},setTimeout:fn=>{fn();return 1},clearTimeout:()=>{},
    addEventListener:()=>{}
  };
  context.window=context;context.globalThis=context;
  vm.createContext(context);
  assert.doesNotThrow(()=>vm.runInContext(code,context));
  assert.equal(onCalls,5,'four unresolved-status queries plus one review-required query');
});


test('manual QRIS bypass fails closed when parked-payment guard blocks',()=>{
  const calls=[];
  const context={console,window:null,globalThis:null,document:undefined,cart:[{p:1000,q:1}],payMethod:'Tunai',
    SJRC01S10AQrisCompat:{guardSecondQris(){calls.push('guard');return false}},
    SJCommercialFinalV5961:{cartMethod:'Tunai',openPayment(method){calls.push('base:'+method);return true}},
    setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{}}
  context.window=context;context.globalThis=context;
  vm.createContext(context);
  vm.runInContext(MANUAL,context);
  const out=context.SJCommercialFinalV5961.openPayment('QRIS');
  assert.equal(out,false);
  assert.deepEqual(calls,['guard']);
});

test('evidence watcher detaches old query listeners before rebinding to a new cashier',async()=>{
  let onCalls=0,offCalls=0;
  function query(path){return{path,orderByChild(){return this},equalTo(){return this},on(_event,cb){onCalls++;cb({val:()=>({})})},off(){offCalls++}}}
  const runtime={db:{ref:path=>query(path)},roots:{qris:'qris-root'},policy:{isUnresolvedParkedPending:()=>false,isLateQuarantineStatus:()=>false,classifyLateSignalConflict:()=>null},readPending:async()=>null,findOwnedUnresolvedParked:async()=>[],findLateReviewSignals:async()=>[],writer:{}};
  const context={console,window:null,globalThis:null,currentLoginId:'kasir01',__SJ_QRIS_DEFERRED_SETTLEMENT_RUNTIME:runtime,
    SJQrisSignalCore:{cartFingerprint:()=>'',matchSignal:()=>({})},SJQrisSignalBeta:{status:()=>({activePendingId:''}),matchSignal:()=>({})},SJCommercialFinalV5961:{cartMethod:'Tunai',openPayment:()=>true},
    setInterval:()=>1,clearInterval:()=>{},setTimeout:fn=>{fn();return 1},clearTimeout:()=>{},addEventListener:()=>{}};
  context.window=context;context.globalThis=context;vm.createContext(context);vm.runInContext(DEFERRED,context);
  assert.equal(onCalls,5);
  context.currentLoginId='kasir02';
  await context.SJRC01S10AQrisCompat.refreshEvidence();
  assert.equal(offCalls,5);
  assert.equal(onCalls,10);
});
