#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD_SHORT="292bfc2"
EXPECTED_BRANCH="p0-bw01-firebase-bandwidth"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/P0_BW01_FIREBASE_BANDWIDTH_HARDENING.patch"

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "HARD STOP: jalankan dari root repository Segeran Jiwa POS legacy." >&2
  exit 10
fi

CURRENT_SHORT="$(git rev-parse --short=7 HEAD)"
if [[ "$CURRENT_SHORT" != "$EXPECTED_HEAD_SHORT" ]]; then
  echo "HARD STOP: HEAD saat ini $CURRENT_SHORT, expected Production QRIS baseline $EXPECTED_HEAD_SHORT." >&2
  echo "Jangan force apply. Audit commit terbaru dahulu." >&2
  exit 11
fi

if [[ -n "$(git status --porcelain)" ]]; then
  echo "HARD STOP: working tree tidak bersih." >&2
  git status --short >&2
  exit 12
fi

check_sha() {
  local expected="$1" file="$2" actual
  [[ -f "$file" ]] || { echo "HARD STOP: file precondition tidak ditemukan: $file" >&2; exit 13; }
  actual="$(sha256sum "$file" | awk '{print $1}')"
  if [[ "$actual" != "$expected" ]]; then
    echo "HARD STOP: baseline file berbeda: $file" >&2
    echo "expected=$expected" >&2
    echo "actual=$actual" >&2
    exit 14
  fi
}

# Exact deployed QRIS baseline preconditions.
check_sha d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355 src/compat/rc01-qris-deferred-settlement-compat.js
check_sha 80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156 src/compat/rc01-qris-manual-bypass.js
check_sha be8380798923df1ce45edbf2bd6c36e08eaa076843db6b13bdacbed117fbead9 src/app/qris-deferred-settlement-bootstrap.js
check_sha 7b4b9d436c736bb414ffe1bda1b976cf73578b02c1b45e6813b24dc71cd4f86e scripts/build-ref01.mjs
check_sha a5dab40966f1467c12cb95cc66cc749ed9c0a485a91986ae4eb626544c6d98b5 tests/rc01-qris-manual-bypass.test.mjs

BRANCH="$(git branch --show-current)"
if [[ "$BRANCH" == "main" ]]; then
  git switch -c "$EXPECTED_BRANCH"
elif [[ "$BRANCH" != "$EXPECTED_BRANCH" ]]; then
  echo "HARD STOP: jalankan dari main atau branch $EXPECTED_BRANCH; sekarang: $BRANCH" >&2
  exit 15
fi

git apply --check "$PATCH_FILE"
git apply "$PATCH_FILE"

node --test tests/p0-bw01-bandwidth-hardening.test.mjs
node --test tests/rc01-qris-manual-bypass.test.mjs

mkdir -p audit
npm run build
npm run verify
npm run verify:rc01:s10c-r6d

git diff --check -- \
  src/compat/rc01-qris-deferred-settlement-compat.js \
  src/compat/rc01-qris-manual-bypass.js \
  tests/p0-bw01-bandwidth-hardening.test.mjs

echo
echo "P0-BW01 applied and verified on the local branch."
echo "Next gate: commit/push branch -> Cloudflare Preview -> real-device UAT."
echo "Do NOT promote to Production before Preview/UAT approval."
