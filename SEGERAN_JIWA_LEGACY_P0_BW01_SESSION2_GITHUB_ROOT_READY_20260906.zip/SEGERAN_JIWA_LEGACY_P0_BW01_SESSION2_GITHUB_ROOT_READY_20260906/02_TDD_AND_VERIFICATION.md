# P0-BW01 TDD / Verification

Local handoff reproduction used the exact deployed source hashes from the package.

TDD sequence:
- first RED contract: 0/6 PASS, 6/6 FAIL on the current Production source;
- first GREEN: 6/6 PASS;
- a re-entrant Firebase callback test then exposed a real duplicate-listener/recursive-attach defect in the first implementation;
- that test failed before the correction and passed after moving listener registration before `.on()` activation;
- final targeted suite: **9/9 PASS**;
- JavaScript syntax checks: PASS.

The handoff ZIP does not contain the complete Git repository/test suite, so full Production regression is intentionally delegated to `APPLY_P0_BW01.sh`, which runs the new targeted test, existing QRIS Manual test, build, generic verify, and R6D verifier in the real checkout before Preview.
