# User steps

Upload ZIP ini ke branch transfer GitHub root. Di Codespaces ambil ZIP via git show, extract ke /tmp, lalu jalankan `APPLY_LEGACY_CUP_01B_R2_ONESHOT.sh`. Script memakai branch/worktree R2 baru sehingga failed R1 worktree tidak perlu disentuh.
