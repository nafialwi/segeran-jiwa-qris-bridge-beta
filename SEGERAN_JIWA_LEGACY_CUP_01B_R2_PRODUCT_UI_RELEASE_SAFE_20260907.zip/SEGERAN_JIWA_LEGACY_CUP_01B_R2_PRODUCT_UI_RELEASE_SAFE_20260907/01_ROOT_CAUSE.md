# Root Cause R1

R1 berhasil membuat mapping/UI tetapi full gate berhenti pada release-contract assertion yang mengharapkan literal build tail:
`${S10A_CLASSIC_ENTRY}\n${QRIS_MANUAL_ENTRY}\n${ENTRY}`.

R1 menyisipkan `${PRODUCT_CUP_UI_ENTRY}` di tengah QRIS_MANUAL_ENTRY dan ENTRY. R2 menaruh product UI entry sebelum frozen suffix, sehingga perilaku baru tetap tersedia tanpa mengubah kontrak release QRIS/R6.
