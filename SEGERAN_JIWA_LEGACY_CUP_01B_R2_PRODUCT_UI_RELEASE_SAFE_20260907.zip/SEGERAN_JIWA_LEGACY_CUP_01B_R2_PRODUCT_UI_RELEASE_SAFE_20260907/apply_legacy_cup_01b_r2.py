from pathlib import Path

root=Path('.')
build=root/'scripts'/'build-ref01.mjs'
text=build.read_text(encoding='utf-8')

anchor="const QRIS_MANUAL_ENTRY='<script src=\"./src/compat/rc01-qris-manual-bypass.js\" data-sj-rc01-qris-manual=\"true\"></script>';\nconst ENTRY='<script type=\"module\" src=\"./src/ref01-entry.js\" data-sj-ref01-entry=\"true\"></script>';"
replacement="const QRIS_MANUAL_ENTRY='<script src=\"./src/compat/rc01-qris-manual-bypass.js\" data-sj-rc01-qris-manual=\"true\"></script>';\nconst PRODUCT_CUP_UI_ENTRY='<script src=\"./src/compat/legacy-cup-01b-product-cup-ui.js\" data-sj-legacy-cup-01b-product-ui=\"true\"></script>';\nconst ENTRY='<script type=\"module\" src=\"./src/ref01-entry.js\" data-sj-ref01-entry=\"true\"></script>';"
if text.count(anchor)!=1:
    raise SystemExit(f'HARD STOP: product cup entry anchor count={text.count(anchor)}')
text=text.replace(anchor,replacement)

func_anchor="function sleep(ms){Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,ms)}"
product_func=r'''const PRODUCT_CUP_SELECT_OPTIONS='<option value="">Per produk / tanpa cup</option><option value="c10">Cup 10 Oz</option><option value="c10p">Cup Paper 10 Oz</option><option value="c16">Cup 16 Oz</option><option value="c22p">Cup 22 Oz Datar Polos</option><option value="c22d">Cup 22 Oz Datar</option><option value="c22o">Cup 22 Oz Oval</option>';
function patchLegacyProductCupSelects(legacy){
  let count=0;
  const patched=legacy.replace(/(<select id="(?:new-cp|edit-m-cp)"[^>]*>)[\s\S]*?(<\/select>)/g,(full,start,end)=>{count++;return `${start}\n${PRODUCT_CUP_SELECT_OPTIONS}\n${end}`});
  if(count!==2)throw new Error(`LEGACY_CUP_01B_PRODUCT_SELECT_ANCHOR_DRIFT:${count}`);
  return patched;
}
'''
if text.count(func_anchor)!=1:
    raise SystemExit(f'HARD STOP: function insertion anchor count={text.count(func_anchor)}')
text=text.replace(func_anchor,product_func+func_anchor)

# Release-safe rule: keep the frozen S10A -> Manual QRIS -> REF01 entry sequence byte-for-byte contiguous.
pipe_anchor="const withSync=injectS10CSyncAuthority(notificationSafe);\n    const candidate=withSync.replace(/<\\/body>/i,`${R6D_SALES_RECURSION_ENTRY}\\n${CLASSIC_ENTRY}\\n${S10A_CLASSIC_ENTRY}\\n${QRIS_MANUAL_ENTRY}\\n${ENTRY}\\n</body>`);"
pipe_replacement="const withSync=injectS10CSyncAuthority(notificationSafe);\n    const withProductCup=patchLegacyProductCupSelects(withSync);\n    const candidate=withProductCup.replace(/<\\/body>/i,`${PRODUCT_CUP_UI_ENTRY}\\n${R6D_SALES_RECURSION_ENTRY}\\n${CLASSIC_ENTRY}\\n${S10A_CLASSIC_ENTRY}\\n${QRIS_MANUAL_ENTRY}\\n${ENTRY}\\n</body>`);"
if text.count(pipe_anchor)!=1:
    raise SystemExit(f'HARD STOP: build pipeline anchor count={text.count(pipe_anchor)}')
text=text.replace(pipe_anchor,pipe_replacement)
build.write_text(text,encoding='utf-8')

src=root/'src'/'compat'/'legacy-cup-01b-product-cup-ui.js'
if src.exists():
    raise SystemExit('HARD STOP: product cup UI source already exists')
package_src=Path(__file__).resolve().parent/'src-legacy-cup-01b-product-cup-ui.js'
src.write_text(package_src.read_text(encoding='utf-8'),encoding='utf-8')
print('LEGACY-CUP-01B R2 transformer applied')
