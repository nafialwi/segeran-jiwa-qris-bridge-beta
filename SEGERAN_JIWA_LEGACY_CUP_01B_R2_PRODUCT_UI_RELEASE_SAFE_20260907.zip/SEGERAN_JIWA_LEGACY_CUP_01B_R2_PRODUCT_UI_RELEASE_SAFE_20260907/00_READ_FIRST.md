# LEGACY-CUP-01B R2 — Product Mapping UI Release-Safe

Correction untuk R1 yang gagal full regression karena script build menyisipkan PRODUCT_CUP_UI_ENTRY di antara QRIS_MANUAL_ENTRY dan ENTRY, sementara release contract mengunci urutan S10A_CLASSIC_ENTRY -> QRIS_MANUAL_ENTRY -> ENTRY agar tetap contiguous.

R2 memindahkan PRODUCT_CUP_UI_ENTRY ke depan suffix authority sehingga kontrak frozen tetap utuh. Tidak mengubah Manual QRIS, deferred QRIS compat, sync authority, ref01-entry, Firebase schema, writer, atau database.
