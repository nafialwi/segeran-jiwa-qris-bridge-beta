# Verification

Automated script wajib membuktikan RED pada baseline 01A, lalu GREEN setelah R2. Targeted suite juga memasukkan `p0-bw01-manual-bridge-off.test.mjs`, dan full `npm run verify`, `verify:ref01`, serta `verify:rc01:s10c-r6d` wajib PASS sebelum commit/push.
