#!/usr/bin/env bash
set -euo pipefail
BASE_SHA='70660e63ea1e480a761beccbc051c7e12274c0fc'
BASE_REF='origin/legacy-cup-01a-paper10'
BRANCH='legacy-cup-01b-product-ui'
WT='/workspaces/legacy-cup-01b-product-ui'
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
fail(){ echo; echo "HARD STOP: $*" >&2; echo 'Jangan commit/push/merge.' >&2; exit 1; }
command -v git >/dev/null || fail 'git tidak tersedia'
command -v node >/dev/null || fail 'node tidak tersedia'
command -v python3 >/dev/null || fail 'python3 tidak tersedia'
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || fail 'jalankan dari dalam repository Segeran Jiwa POS'
cd "$ROOT"
git fetch origin
ACTUAL="$(git rev-parse "${BASE_REF}^{commit}" 2>/dev/null || true)"
[[ "$ACTUAL" == "$BASE_SHA" ]] || fail "baseline ${BASE_REF} drift: ${ACTUAL:-missing}; expected $BASE_SHA"
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then fail "branch lokal $BRANCH sudah ada"; fi
if git ls-remote --exit-code --heads origin "$BRANCH" >/dev/null 2>&1; then fail "branch remote $BRANCH sudah ada"; fi
if [[ -e "$WT" ]]; then fail "worktree path sudah ada: $WT"; fi
git worktree add -b "$BRANCH" "$WT" "$BASE_SHA"
cd "$WT"
cp "$PKG_DIR/legacy-cup-01b-product-cup-ui.test.mjs" tests/legacy-cup-01b-product-cup-ui.test.mjs

echo '=== TDD RED: test baru harus gagal pada LEGACY-CUP-01A ==='
set +e
node --test tests/legacy-cup-01b-product-cup-ui.test.mjs > /tmp/legacy-cup-01b-red.log 2>&1
RED_RC=$?
set -e
cat /tmp/legacy-cup-01b-red.log
[[ $RED_RC -ne 0 ]] || fail 'TDD RED unexpectedly PASS; test tidak membuktikan perubahan baru'

echo '=== APPLY PRODUCTION CHANGE ==='
python3 "$PKG_DIR/apply_legacy_cup_01b.py"
node --check src/compat/legacy-cup-01b-product-cup-ui.js
npm run build:ref01

echo '=== TDD GREEN / TARGETED ==='
node --test \
 tests/legacy-cup-01a-paper10.test.mjs \
 tests/legacy-cup-01b-product-cup-ui.test.mjs \
 tests/v34-p5-batch2-cup-packaging.test.mjs \
 tests/v34-p5-batch2-cup-product-costing.test.mjs

echo '=== FULL GATES ==='
npm run verify
npm run verify:ref01
npm run verify:rc01:s10c-r6d

# Restore generated verification/build output. Source authority remains the only commit scope.
for p in audit dist dist-sc03 dist-sc04 dist-ref01 dist-rc01; do
  git restore --source="$BASE_SHA" -- "$p" 2>/dev/null || true
  git clean -fd -- "$p" >/dev/null 2>&1 || true
done

git diff --check
# R6 and other frozen/runtime authorities must remain byte-for-byte unchanged.
git diff --exit-code "$BASE_SHA" -- \
 baseline/legacy-v1.0.40.html \
 src/compat/rc01-qris-deferred-settlement-compat.js \
 src/compat/rc01-qris-manual-bypass.js \
 src/compat/rc01-sync-authority.js \
 src/ref01-entry.js >/dev/null || fail 'P0-BW01 R6/frozen authority drift terdeteksi'

ACTUAL_SCOPE="$(git status --porcelain -uall | awk '{print $2}' | sort)"
EXPECTED_SCOPE="$(printf '%s\n' scripts/build-ref01.mjs src/compat/legacy-cup-01b-product-cup-ui.js tests/legacy-cup-01b-product-cup-ui.test.mjs | sort)"
[[ "$ACTUAL_SCOPE" == "$EXPECTED_SCOPE" ]] || { echo 'Actual scope:'; git status --short; fail 'final worktree scope bukan tepat 3 file LEGACY-CUP-01B'; }

git add scripts/build-ref01.mjs src/compat/legacy-cup-01b-product-cup-ui.js tests/legacy-cup-01b-product-cup-ui.test.mjs
git commit -m 'feat: add Cup Paper 10 Oz product mapping UI'
git push -u origin "$BRANCH"

echo
echo '============================================================'
echo 'LEGACY-CUP-01B ONESHOT PASS'
echo "Branch: $BRANCH"
echo "Baseline: $BASE_SHA (LEGACY-CUP-01A Preview)"
echo 'Cup Paper 10 Oz: AVAILABLE in create/edit product mapping'
echo 'Product cup selector: MODERN CARD/LIST UI'
echo 'Existing five product cup mappings: PRESERVED'
echo 'Category-level Paper 10 Oz default mapping: STILL DISABLED'
echo 'Cup Paper inventory/opening/closing/opname from 01A: PRESERVED'
echo 'P0-BW01 R6 QRIS/manual + sync authority: UNCHANGED'
echo 'Full verify + REF01 + R6D: PASS'
echo 'Branch sudah dipush; tunggu Cloudflare Preview.'
echo 'Production/main: BELUM DISENTUH'
echo '============================================================'
