# TDD & Verification
Script one-shot melakukan:
1. checkout exact baseline 70660e6 di worktree terisolasi;
2. copy test baru dan wajib melihat RED;
3. apply transformer;
4. build REF01;
5. targeted GREEN;
6. `npm run verify`;
7. `npm run verify:ref01`;
8. `npm run verify:rc01:s10c-r6d`;
9. restore generated artifacts;
10. scope guard tiga file;
11. guard file QRIS R6/sync/frozen authority;
12. commit + push hanya bila seluruh gate PASS.
