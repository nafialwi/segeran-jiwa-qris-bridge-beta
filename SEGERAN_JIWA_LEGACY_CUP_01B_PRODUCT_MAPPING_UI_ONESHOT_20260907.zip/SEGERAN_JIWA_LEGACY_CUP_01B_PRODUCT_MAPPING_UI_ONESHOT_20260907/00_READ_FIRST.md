# LEGACY-CUP-01B — ONE-SHOT
Baseline: commit `70660e63ea1e480a761beccbc051c7e12274c0fc` (`legacy-cup-01a-paper10`).

Tujuan:
- Cup Paper 10 Oz dapat dipilih saat membuat/edit produk.
- Selector cup produk diganti dari native popup lama menjadi card/list modern.
- Field `cp` lama tetap menjadi authority; tidak ada schema/writer baru.
- 5 mapping cup lama tetap ada.
- Category-level default mapping untuk Cup Paper tetap OFF; perubahan ini khusus per-produk.
- Inventory/opening/closing/opname Cup Paper dari 01A tetap ada.
- QRIS R6 / sync authority tidak disentuh.

Jalankan hanya `APPLY_LEGACY_CUP_01B_ONESHOT.sh` melalui workflow GitHub-root upload yang diberikan di chat.
