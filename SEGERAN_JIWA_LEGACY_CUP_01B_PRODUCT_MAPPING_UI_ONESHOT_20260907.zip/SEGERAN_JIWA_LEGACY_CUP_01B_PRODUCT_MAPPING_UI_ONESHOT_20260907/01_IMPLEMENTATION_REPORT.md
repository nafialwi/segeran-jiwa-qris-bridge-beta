# Implementation Report
Perubahan dibatasi ke tiga source-authority paths:
1. `scripts/build-ref01.mjs` — patch dua select legacy (`new-cp`, `edit-m-cp`) dan injeksi satu compat UI.
2. `src/compat/legacy-cup-01b-product-cup-ui.js` — modern card/list selector yang tetap menulis ke select lama sehingga `saveMenu` / `saveEditMaster` dan field `cp` tidak berubah.
3. `tests/legacy-cup-01b-product-cup-ui.test.mjs` — regression baru.

UI menambahkan label Kategori Produk, Nama Produk, Harga Jual, dan panel Kemasan/Jenis Cup tanpa memindahkan writer atau schema.
