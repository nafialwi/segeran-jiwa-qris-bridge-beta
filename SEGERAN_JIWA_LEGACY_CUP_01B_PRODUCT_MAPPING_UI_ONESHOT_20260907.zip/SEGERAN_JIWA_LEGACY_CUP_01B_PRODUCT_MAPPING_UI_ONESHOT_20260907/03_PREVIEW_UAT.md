# Preview UAT — singkat
1. Owner → Tambah Produk: selector Kemasan/Jenis Cup tampil sebagai card/list modern.
2. Pastikan opsi: Tanpa cup, Cup 10 Oz, Cup Paper 10 Oz, Cup 16 Oz, Cup 22 Oz Datar Polos, Cup 22 Oz Datar, Cup 22 Oz Oval.
3. Buat produk test dengan Cup Paper 10 Oz, simpan, lalu Edit Produk: pilihan Cup Paper 10 Oz harus tetap terpilih.
4. Pastikan produk lama dengan 5 cup existing tetap menunjukkan pilihan yang benar saat diedit.
5. Bahan & Gudang tetap menampilkan 6 cup dan tidak ada perubahan QRIS/shift.
