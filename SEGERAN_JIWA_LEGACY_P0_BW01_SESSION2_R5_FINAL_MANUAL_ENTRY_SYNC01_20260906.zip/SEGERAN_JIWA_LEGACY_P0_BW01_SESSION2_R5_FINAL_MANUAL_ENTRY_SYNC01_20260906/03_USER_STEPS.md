# User Steps — GitHub root upload -> existing Codespace

1. From GitHub `main`, create transfer branch `transfer/p0-bw01-r5-upload`.
2. Upload this ZIP to repository ROOT and commit only to that transfer branch.
3. In Codespace use the existing isolated worktree: `/workspaces/p0-bw01-transfer`.
4. Fetch the transfer branch, extract ZIP to `/tmp`, run `APPLY_R5_FINAL_MANUAL_ENTRY_SYNC01.sh`.
5. If `HARD STOP` or any red test appears: do not commit/push; send screenshot.
6. Only if the script prints `SESSION 2 R5 LOCAL GATE PASS`, commit the exact 5-file delta and push `p0-bw01-firebase-bandwidth` for Preview.
7. Preview UAT: Diagnostics Critical Pending 0 for device heartbeat, Manual QRIS only, Tutup Shift works.
8. Do not merge/promote Production until Preview UAT passes.
