# R4 -> R5 Root Cause

Observed R4 full regression: 552 tests, 548 pass, 4 fail.

The failures were all old QRIS runtime contracts:
- `tests/rc01-s10a-qris-runtime.test.mjs` (3 failures)
- `tests/rc01-s10c-r3-late-quarantine-convergence.test.mjs` (1 failure)

R4 returned `null`/`[]` from every exported QRIS runtime read API. That broke unit-level compatibility even though the actual business target is to disable automatic QRIS behavior in the deployed app.

R5 does not weaken those old tests. Instead, the installer now supports an explicit `manualOnly` option and `src/ref01-entry.js` selects it only for the deployed REF01/RC01 runtime. Default installer behavior remains unchanged from R3.

Therefore:
- deployed app: manual-only, zero deferred QRIS background Firebase reads/listeners;
- legacy unit compatibility: preserved;
- frozen manual bypass: preserved;
- shift heartbeat correction: retained.
