#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH='p0-bw01-firebase-bandwidth'
R3_BOOTSTRAP_SHA='9aaa068a38a4644df11d2aa15132f7363c16c205e082f91b77a9eada208e0496'
R3_TEST_SHA='b87be1bdd7a7ded4c06414db606f28bce89e8239273ce0f6d78fdc31db939aa0'
REF01_ENTRY_BASE_SHA='22572c210c5f5c31d570709a023ef36c6983035427aa8a264b88e35098c39f7b'
SYNC_BASE_SHA='a5283642e0a7fcf2679845a60783628d1121340ef8c9bd94d0b10d3200474050'
FROZEN_COMPAT_SHA='d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355'
FROZEN_MANUAL_SHA='80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$SCRIPT_DIR/P0_BW01_R5_FINAL_MANUAL_ENTRY_SYNC01.patch"
QRIS_SOURCE='src/app/qris-deferred-settlement-bootstrap.js'
ENTRY_SOURCE='src/ref01-entry.js'
SYNC_SOURCE='src/compat/rc01-sync-authority.js'
R3_TEST='tests/p0-bw01-runtime-event-cache.test.mjs'
MANUAL_ENTRY_TEST='tests/p0-bw01-manual-only-entry.test.mjs'
SYNC_TEST='tests/p0-sync01-device-presence.test.mjs'
R4_OLD_MANUAL_TEST='tests/p0-bw01-manual-only.test.mjs'
COMPAT_FILE='src/compat/rc01-qris-deferred-settlement-compat.js'
MANUAL_FILE='src/compat/rc01-qris-manual-bypass.js'

stop(){ echo "HARD STOP: $*" >&2; echo 'Jangan commit/push/merge.' >&2; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || stop 'Bukan Git repository.'
cd "$ROOT"
BRANCH="$(git branch --show-current)"
[[ "$BRANCH" == "$EXPECTED_BRANCH" ]] || stop "Branch harus $EXPECTED_BRANCH (sekarang: $BRANCH)."
[[ -z "$(git diff --cached --name-only)" ]] || stop 'Ada staged changes. Unstage/cek dulu; script tidak akan menyentuh staged work.'

# R4 sebelumnya memang gagal full-regression dan dapat meninggalkan hanya delta R4 + generated dist.
# Terima hanya state yang diketahui; semua yang lain fail-closed.
mapfile -t TRACKED < <(git diff --name-only)
for p in "${TRACKED[@]}"; do
  case "$p" in
    "$QRIS_SOURCE"|"$SYNC_SOURCE"|"$R3_TEST") ;;
    *) stop "Tracked change tidak dikenal dari recovery R4: $p" ;;
  esac
done
mapfile -t UNTRACKED < <(git ls-files --others --exclude-standard)
for p in "${UNTRACKED[@]}"; do
  case "$p" in
    "$R4_OLD_MANUAL_TEST"|"$SYNC_TEST"|dist-rc01/*|dist-ref01/*|dist-sc03/*|dist-sc04/*) ;;
    *) stop "Untracked file tidak dikenal dari recovery R4: $p" ;;
  esac
done

EVIDENCE_DIR="/tmp/p0bw01-r5-recovery-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$EVIDENCE_DIR"
git status --short > "$EVIDENCE_DIR/status-before.txt"
git diff > "$EVIDENCE_DIR/r4-failed-diff.patch" || true

# Restore ONLY the isolated R4 paths to current HEAD (= committed R3 Preview), never main workspace.
git restore --source=HEAD --worktree -- "$QRIS_SOURCE" "$SYNC_SOURCE" "$R3_TEST"
rm -f "$R4_OLD_MANUAL_TEST" "$SYNC_TEST"
git clean -fd -- dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true
[[ -z "$(git status --short)" ]] || { git status --short; stop 'Recovery R4 belum menghasilkan clean R3 worktree.'; }

[[ -f "$QRIS_SOURCE" && "$(sha "$QRIS_SOURCE")" == "$R3_BOOTSTRAP_SHA" ]] || stop 'R3 QRIS bootstrap hash tidak cocok.'
[[ -f "$R3_TEST" && "$(sha "$R3_TEST")" == "$R3_TEST_SHA" ]] || stop 'R3 event-cache test hash tidak cocok.'
[[ -f "$ENTRY_SOURCE" && "$(sha "$ENTRY_SOURCE")" == "$REF01_ENTRY_BASE_SHA" ]] || stop 'ref01-entry baseline hash tidak cocok.'
[[ -f "$SYNC_SOURCE" && "$(sha "$SYNC_SOURCE")" == "$SYNC_BASE_SHA" ]] || stop 'S10C sync-authority baseline hash tidak cocok.'
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat hash tidak cocok.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS hash tidak cocok.'

git apply --check "$PATCH" || stop 'R5 patch tidak clean pada committed R3 state.'
git apply "$PATCH"
git diff --check || stop 'git diff --check gagal.'

EXPECTED_PATHS="$(printf '%s\n' "$QRIS_SOURCE" "$ENTRY_SOURCE" "$SYNC_SOURCE" "$MANUAL_ENTRY_TEST" "$SYNC_TEST" | sort)"
ACTUAL_PATHS="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$ACTUAL_PATHS" == "$EXPECTED_PATHS" ]] || { git status --short; stop 'Scope R5 bukan tepat 5 file.'; }

# Fast R5 gates: production is manual-only while default installer compatibility remains intact.
node --check "$QRIS_SOURCE"
node --check "$ENTRY_SOURCE"
node --check "$SYNC_SOURCE"
node --test "$R3_TEST" "$MANUAL_ENTRY_TEST" "$SYNC_TEST"

grep -Fq "installQrisDeferredSettlementRuntime(globalThis,{p4,manualOnly:true})" "$ENTRY_SOURCE" || stop 'Production ref01 entry belum mengaktifkan manualOnly.'

# Re-run the exact legacy contracts that R4 broke. They MUST pass unchanged.
node --test tests/rc01-s10a-qris-runtime.test.mjs tests/rc01-s10c-r3-late-quarantine-convergence.test.mjs

# Frozen/manual and sync authority regressions.
node --test tests/rc01-qris-manual-bypass.test.mjs
node --test tests/rc01-s10c-sync-authority.test.mjs

# Architecture gates first.
node scripts/build-sc03.mjs
node scripts/verify-sc03.mjs
node scripts/build-sc04.mjs
node scripts/verify-sc04.mjs

# Full repository gates. No PASS claim without these.
npm run build
npm run verify
npm run verify:rc01:s10c-r6d

[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah setelah full gates.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah setelah full gates.'

# Preserve only intentional R5 delta after build/audit generated files.
TMP="$(mktemp -d)"
cp "$QRIS_SOURCE" "$TMP/qris.js"
cp "$ENTRY_SOURCE" "$TMP/ref01-entry.js"
cp "$SYNC_SOURCE" "$TMP/sync.js"
cp "$MANUAL_ENTRY_TEST" "$TMP/manual-entry.test.mjs"
cp "$SYNC_TEST" "$TMP/sync.test.mjs"
git reset --hard HEAD >/dev/null
cp "$TMP/qris.js" "$QRIS_SOURCE"
cp "$TMP/ref01-entry.js" "$ENTRY_SOURCE"
cp "$TMP/sync.js" "$SYNC_SOURCE"
cp "$TMP/manual-entry.test.mjs" "$MANUAL_ENTRY_TEST"
cp "$TMP/sync.test.mjs" "$SYNC_TEST"
rm -rf "$TMP"
git clean -fd -- dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true

git diff --check || stop 'Final diff check gagal.'
node --test "$R3_TEST" "$MANUAL_ENTRY_TEST" "$SYNC_TEST"
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah saat cleanup.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah saat cleanup.'
FINAL_PATHS="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$FINAL_PATHS" == "$EXPECTED_PATHS" ]] || { git status --short; stop 'Final R5 scope bukan tepat 5 file.'; }

echo
echo 'SESSION 2 R5 LOCAL GATE PASS'
echo "Branch: $BRANCH"
echo 'QRIS Production runtime: MANUAL VERIFICATION ONLY'
echo 'QRIS background Firebase reads/listeners through deferred runtime: OFF'
echo 'Legacy default runtime contracts: PRESERVED (regression compatibility)'
echo 'Device presence/register heartbeat: ADVISORY'
echo 'Revoke/security/business writes: tetap CRITICAL'
echo 'Frozen QRIS compat/manual: PRESERVED'
echo 'Production: BELUM DISENTUH'
echo "Recovery evidence: $EVIDENCE_DIR"
echo 'NEXT: commit 5-file R5 delta, push Preview, UAT Manual QRIS + Tutup Shift.'
