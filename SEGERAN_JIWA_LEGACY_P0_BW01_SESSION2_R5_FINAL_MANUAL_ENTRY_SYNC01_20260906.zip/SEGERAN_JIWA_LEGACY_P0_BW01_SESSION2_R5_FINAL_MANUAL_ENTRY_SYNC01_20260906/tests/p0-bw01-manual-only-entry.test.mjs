import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';

const SOURCE='src/app/qris-deferred-settlement-bootstrap.js';
const ENTRY='src/ref01-entry.js';
const sha=path=>createHash('sha256').update(readFileSync(path)).digest('hex');

function loadInstaller(){
  let source=readFileSync(SOURCE,'utf8');
  source=source.replace(/^import .*;\s*$/gm,'').replace('export function installQrisDeferredSettlementRuntime','function installQrisDeferredSettlementRuntime');
  const context={
    console,Promise,Object,Array,String,Number,Boolean,Math,JSON,Error,TypeError,Set,
    POS_ROOT:'toko_segeranjiwa_v58',QRIS_ROOT:'toko_segeranjiwa_qris_beta_v1',
    qrisPath:(section,id)=>['toko_segeranjiwa_qris_beta_v1',section,id].filter(Boolean).join('/'),
    createQrisDeferredSettlementWriter:()=>({attachSnapshotAndPark(){},quarantineLateSignal(){}}),
    policy:{
      isUnresolvedParkedPending:row=>['WAITING_QRIS','MATCHED','FINALIZING','MANUAL_FALLBACK'].includes(String(row?.status||'')),
      isLateQuarantineStatus:s=>['LATE_AFTER_CANCEL','LATE_OR_NEW_AMBIGUOUS'].includes(String(s||'')),
      classifyLateSignalConflict:()=>({status:'LATE_AFTER_CANCEL'}),
      combinedQrisFingerprint:()=>''
    }
  };
  context.globalThis=context;
  vm.createContext(context);
  vm.runInContext(`${source}\nthis.__install=installQrisDeferredSettlementRuntime;`,context,{filename:SOURCE});
  return context.__install;
}

test('P0-BW01 production entry explicitly selects MANUAL_ONLY runtime',()=>{
  const entry=readFileSync(ENTRY,'utf8');
  assert.match(entry,/installQrisDeferredSettlementRuntime\(globalThis,\{p4,manualOnly:true\}\)/);
});

test('P0-BW01 MANUAL_ONLY mode performs zero Firebase reads/listeners even when frozen compat refresh APIs are called',async()=>{
  let refCalls=0;
  const db={ref(){refCalls++;throw new Error('QRIS_FIREBASE_ACCESS_FORBIDDEN_IN_MANUAL_ONLY')}};
  const api=loadInstaller()({}, {db,manualOnly:true});
  assert.equal(api.mode,'MANUAL_ONLY');
  assert.equal(api.automaticFirebaseReads,false);
  assert.equal(api.automaticSettlement,false);
  for(let i=0;i<100;i++){
    assert.equal(JSON.stringify(await api.findOwnedUnresolvedParked('kasir01')),'[]');
    assert.equal(JSON.stringify(await api.findLateReviewSignals('kasir01')),'[]');
  }
  assert.equal(await api.readPending('P1'),null);
  assert.equal(JSON.stringify(await api.readPendingRows()),'{}');
  assert.equal(await api.readSignal('S1'),null);
  assert.equal(JSON.stringify(await api.readSignalRows()),'{}');
  assert.equal(refCalls,0);
});

test('P0-BW01 default installer keeps legacy read-only compatibility contract for regression safety',async()=>{
  const rows={A:{pendingId:'A',cashierId:'kasir-a',status:'WAITING_QRIS',parkedAt:1}};
  const db={ref(path){return{once:async()=>({val:()=>path.endsWith('/A')?rows.A:rows}),orderByChild(){return this},equalTo(){return this},on(_event,cb){queueMicrotask(()=>cb({val:()=>rows}));return cb}}}};
  const api=loadInstaller()({}, {db,writer:{attachSnapshotAndPark(){},quarantineLateSignal(){}}});
  assert.notEqual(api.mode,'MANUAL_ONLY');
  assert.equal((await api.readPending('A')).pendingId,'A');
});

test('P0-BW01 preserves frozen compat/manual modules byte-for-byte',()=>{
  assert.equal(sha('src/compat/rc01-qris-deferred-settlement-compat.js'),'d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355');
  assert.equal(sha('src/compat/rc01-qris-manual-bypass.js'),'80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156');
});
