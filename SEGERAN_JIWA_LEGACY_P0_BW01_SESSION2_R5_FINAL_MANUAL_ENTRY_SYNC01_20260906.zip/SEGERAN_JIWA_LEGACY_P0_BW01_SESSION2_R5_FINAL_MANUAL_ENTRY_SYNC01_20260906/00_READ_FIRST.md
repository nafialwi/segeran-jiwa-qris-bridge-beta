# P0-BW01 Session 2 R5 FINAL — Manual Entry + SYNC01

R5 is the final correction after R4 exposed 4 legacy-regression failures.

## Root cause of R4 failure
R4 changed the exported QRIS runtime itself into manual-only mode. Four old regression tests intentionally exercise that exported runtime's read-only compatibility API, so they failed even though the new business decision was valid.

## R5 design
R5 separates **production mode** from **compatibility contract**:

1. `src/ref01-entry.js` explicitly starts the QRIS deferred runtime with `manualOnly:true` in Production/Preview.
2. In `manualOnly:true`, repeated frozen compat refresh calls return local empty evidence and perform **zero Firebase reads/listeners** and zero automatic settlement writes.
3. The default installer behavior remains the R3 compatibility behavior, so the four legacy tests keep passing unchanged.
4. Manual QRIS bypass remains frozen byte-for-byte and continues to save sales only after cashier manual confirmation.
5. Device registration/presence heartbeat is classified ADVISORY so it cannot block shift close; revoke/security/unknown/business writes remain CRITICAL.

This avoids changing or deleting the old safety regression tests merely to obtain a green suite.
