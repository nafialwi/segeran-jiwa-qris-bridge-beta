#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_SLUG="${S10A2_EXPECTED_REPO_SLUG:-nafialwi/segeran-jiwa-qris-bridge-beta}"
EXPECTED_MAIN="${S10A2_EXPECTED_MAIN:-0d396829ad2ebb4ba0688e4c9b4aa2eccd2b8fb1}"
EXPECTED_PARENT_PREFIX="${S10A2_EXPECTED_PARENT_PREFIX:-7270fe8}"
BRANCH="${S10A2_BRANCH:-rc01-v3.4-release-candidate}"
EXPECTED_INDEX="296feef99052aa35409c93513239c72ae1ad728f2082116cd53b97284d1b7c57"
EXPECTED_SHIELD="7da40dfe73e36de2df70c1e1efd75efcfaf60fda53325a60a509435368ee7221"
EXPECTED_WRITER="cac56daf9cc8495041dcff1a861edeb9a3caf5723e329ef6445653525948b8a8"
EXPECTED_TESTS=469
EXPECTED_FILE_COUNT=1365
EXPECTED_BASE_FILE_COUNT=1360
CALLER_PWD="$PWD"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
TREE_MANIFEST="$HERE/checksums/S10A2_EXPECTED_TREE_SHA256.txt"
PAYLOAD_MANIFEST="$HERE/checksums/S10A2_PAYLOAD_SHA256.txt"
BASE_MANIFEST="$HERE/checksums/S10A1_BASE_TREE_SHA256.txt"

stop(){ echo; echo "STOP: $*" >&2; exit 20; }
pass(){ echo "PASS: $*"; }

for c in git node npm sha256sum tar; do command -v "$c" >/dev/null || stop "$c is not available"; done
[[ -d "$PAYLOAD" && -f "$TREE_MANIFEST" && -f "$PAYLOAD_MANIFEST" && -f "$BASE_MANIFEST" ]] || stop "gate payload/checksum files missing"

cd "$PAYLOAD"
sha256sum -c "$PAYLOAD_MANIFEST" >/tmp/s10a2-payload-check.log || { tail -n 100 /tmp/s10a2-payload-check.log; stop "package payload checksum mismatch"; }
pass "S10A.2 package payload checksums"

REPO="$(git -C "$CALLER_PWD" rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO" && -n "${CODESPACE_NAME:-}" && -d /workspaces ]]; then
  REPO="$(find /workspaces -mindepth 1 -maxdepth 2 -type d -name .git -printf '%h\n' 2>/dev/null | head -n1 || true)"
fi
[[ -n "$REPO" && -d "$REPO/.git" ]] || stop "cannot locate Codespace git repository; cd to repo root and rerun"
cd "$REPO"

echo "Repository: $REPO"
REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
case "$REMOTE_URL" in *"$EXPECTED_SLUG"*) ;; *) stop "origin is not expected repository: $REMOTE_URL" ;; esac
[[ "$(git branch --show-current)" == "$BRANCH" ]] || stop "open Codespace on branch '$BRANCH'"
[[ -z "$(git status --porcelain)" ]] || { git status --short; stop "working tree is not clean"; }
pass "expected repository/branch and initially clean tree"

git fetch --quiet origin main "$BRANCH"
REMOTE_MAIN="$(git rev-parse origin/main)"
LOCAL_HEAD="$(git rev-parse HEAD)"
REMOTE_RC="$(git rev-parse "origin/$BRANCH")"
[[ "$REMOTE_MAIN" == "$EXPECTED_MAIN" ]] || stop "origin/main changed: expected $EXPECTED_MAIN but found $REMOTE_MAIN"
[[ "$LOCAL_HEAD" == "$REMOTE_RC" ]] || stop "local RC branch is not synchronized with origin/$BRANCH"

PARENT="$(git rev-parse HEAD^)"
[[ "${PARENT:0:${#EXPECTED_PARENT_PREFIX}}" == "$EXPECTED_PARENT_PREFIX" ]] || stop "helper parent is not expected S10A.1 Preview commit prefix $EXPECTED_PARENT_PREFIX; found $PARENT"
[[ "$(git merge-base origin/main "$PARENT")" == "$EXPECTED_MAIN" ]] || stop "S10A.1 Preview parent no longer descends from expected main authority"

BASE_TMP="$(mktemp -d)"
git archive "$PARENT" | tar -xf - -C "$BASE_TMP"
BASE_COUNT="$(find "$BASE_TMP" -type f | wc -l | tr -d ' ')"
[[ "$BASE_COUNT" == "$EXPECTED_BASE_FILE_COUNT" ]] || { rm -rf "$BASE_TMP"; stop "S10A.1 parent file count $BASE_COUNT != $EXPECTED_BASE_FILE_COUNT"; }
(cd "$BASE_TMP" && sha256sum -c "$BASE_MANIFEST") >/tmp/s10a2-base-check.log || { tail -n 100 /tmp/s10a2-base-check.log; rm -rf "$BASE_TMP"; stop "remote S10A.1 parent tree differs from verified S10A.1 authority"; }
rm -rf "$BASE_TMP"
pass "remote parent $PARENT is exact verified S10A.1 tree"

mapfile -t DIFF_LINES < <(git diff --name-status "$PARENT"..HEAD)
[[ "${#DIFF_LINES[@]}" -eq 1 ]] || { printf '%s\n' "${DIFF_LINES[@]}"; stop "web-upload bootstrap must contain exactly one helper ZIP change"; }
STATUS="${DIFF_LINES[0]%%$'\t'*}"; UPLOAD_FILE="${DIFF_LINES[0]#*$'\t'}"
[[ "$STATUS" == "A" ]] || stop "helper change must be added ZIP; found '$STATUS'"
case "$UPLOAD_FILE" in
  SEGERAN_JIWA_POS_v3.4_RC01_S10A2_QRIS_MATCH_STATE_WEBUPLOAD_GATE*.zip|RC01_S10A2_WEBUPLOAD_GATE*.zip) ;;
  *) stop "unexpected helper file '$UPLOAD_FILE'" ;;
esac
[[ -f "$UPLOAD_FILE" ]] || stop "uploaded helper ZIP not present in repo root"
pass "isolated helper commit contains only $UPLOAD_FILE"

rm -f -- "$UPLOAD_FILE"
cp -a "$PAYLOAD"/. "$REPO"/
pass "helper removed; exact S10A.2 payload overlaid"

echo
echo "=== FRESH S10A.2 VERIFICATION ==="
npm run verify:rc01:s10a2 | tee /tmp/s10a2-verify.log
grep -Eq "(^|[^0-9])pass[[:space:]]+$EXPECTED_TESTS([^0-9]|$)" /tmp/s10a2-verify.log || stop "fresh full test count is not $EXPECTED_TESTS PASS"
grep -Eq "(^|[^0-9])fail[[:space:]]+0([^0-9]|$)" /tmp/s10a2-verify.log || stop "fresh full suite contains failures"
grep -q "RC-01 release contract PASS" /tmp/s10a2-verify.log || stop "RC01 verifier did not PASS"
grep -q "RC01-S10A verification PASS" /tmp/s10a2-verify.log || stop "S10A verifier did not PASS"
grep -q "RC01-S10A.1 verification PASS" /tmp/s10a2-verify.log || stop "S10A.1 verifier did not PASS"
grep -q "RC01-S10A.2 verification PASS" /tmp/s10a2-verify.log || stop "S10A.2 verifier did not PASS"
pass "fresh verify:rc01:s10a2 = $EXPECTED_TESTS/$EXPECTED_TESTS + all contracts PASS"

echo
echo "=== CLOUDFLARE BUILD REHEARSAL ==="
npm run build:ref01 | tee /tmp/s10a2-cloudflare-build.log
REF_SHA="$(sha256sum dist-ref01/index.html | awk '{print $1}')"
RC_SHA="$(sha256sum dist-rc01/index.html | awk '{print $1}')"
SHIELD_SHA="$(sha256sum src/compat/rc01-qris-event-sync-shield.js | awk '{print $1}')"
WRITER_SHA="$(sha256sum src/data/writers/qris-deferred-settlement-writer.js | awk '{print $1}')"
[[ "$REF_SHA" == "$EXPECTED_INDEX" && "$RC_SHA" == "$EXPECTED_INDEX" ]] || stop "HTML shell hash mismatch ref=$REF_SHA rc=$RC_SHA"
[[ "$SHIELD_SHA" == "$EXPECTED_SHIELD" ]] || stop "S10A.2 shield hash mismatch $SHIELD_SHA"
[[ "$WRITER_SHA" == "$EXPECTED_WRITER" ]] || stop "S10A.2 writer hash mismatch $WRITER_SHA"
pass "Cloudflare assets match exact S10A.2 authority"

# Verifiers regenerate audit files; restore packaged authority before final tree proof.
cp -a "$PAYLOAD"/. "$REPO"/
TMP_EXPECT="$(mktemp)"; TMP_ACTUAL="$(mktemp)"
awk '{sub(/^\.\//,"",$2); print $2}' "$TREE_MANIFEST" | sort > "$TMP_EXPECT"
find . -path './.git' -prune -o -type f -printf '%P\n' | sort > "$TMP_ACTUAL"
ACTUAL_COUNT="$(wc -l < "$TMP_ACTUAL" | tr -d ' ')"
[[ "$ACTUAL_COUNT" == "$EXPECTED_FILE_COUNT" ]] || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "unexpected file count $ACTUAL_COUNT; expected $EXPECTED_FILE_COUNT"; }
cmp -s "$TMP_EXPECT" "$TMP_ACTUAL" || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "repository file set differs from S10A.2 source authority"; }
(cd "$REPO" && sha256sum -c "$TREE_MANIFEST") >/tmp/s10a2-tree-check.log || { tail -n 100 /tmp/s10a2-tree-check.log; stop "S10A.2 full-tree checksum mismatch"; }
rm -f "$TMP_EXPECT" "$TMP_ACTUAL"
pass "exact $EXPECTED_FILE_COUNT-file S10A.2 source tree checksums"

git diff --check || stop "git diff --check failed"
git add -A
[[ -n "$(git status --porcelain)" ]] || stop "no S10A.2 changes detected"
if ! git config user.name >/dev/null || ! git config user.email >/dev/null; then stop "git identity is not configured"; fi
git commit -m "fix(qris): isolate quarantined match state" >/tmp/s10a2-commit.log
cat /tmp/s10a2-commit.log
COMMIT="$(git rev-parse HEAD)"
[[ "$(git rev-parse origin/main)" == "$EXPECTED_MAIN" ]] || stop "origin/main moved unexpectedly"
[[ "$(git branch --show-current)" == "$BRANCH" && -z "$(git status --porcelain)" ]] || stop "RC branch not clean after local S10A.2 commit"

echo
echo "============================================================"
echo "RC01-S10A.2 WEB-UPLOAD CODESPACE PREPARE: PASS"
echo "branch=$BRANCH"
echo "main=$EXPECTED_MAIN"
echo "s10a1_preview_parent=$PARENT"
echo "helper_remote_commit=$REMOTE_RC"
echo "s10a2_commit=$COMMIT"
echo "tests=$EXPECTED_TESTS/$EXPECTED_TESTS PASS"
echo "rc_verifier=PASS"
echo "s10a_verifier=PASS"
echo "s10a1_verifier=PASS"
echo "s10a2_verifier=PASS"
echo "html_shell_sha256=$EXPECTED_INDEX"
echo "shield_sha256=$EXPECTED_SHIELD"
echo "writer_sha256=$EXPECTED_WRITER"
echo "mutation_allowlist=4/4"
echo "main_pushed=NO"
echo "s10a2_final_push=NO"
echo "cloudflare_production_mutated=NO"
echo "firebase_rules_root_mutated=NO"
echo "appmint_webview=DEFERRED_NA_WEB_RELEASE"
echo "NEXT=STOP and send this summary to ChatGPT before final RC branch push"
echo "============================================================"
