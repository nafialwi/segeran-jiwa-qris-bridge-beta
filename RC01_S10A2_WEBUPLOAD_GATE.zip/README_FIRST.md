# RC01-S10A.2 GitHub Web-Upload Gate

Purpose: move the locally verified S10A.2 quarantined-signal match-state isolation correction into the existing GitHub RC branch using the established GitHub-web-upload + Codespaces workflow while keeping `main` and Cloudflare Production untouched.

Expected branch: `rc01-v3.4-release-candidate`
Expected remote S10A.1 Preview parent: commit prefix `7270fe8` AND exact 1360-file S10A.1 base-tree checksum manifest.
Expected main authority: `0d396829ad2ebb4ba0688e4c9b4aa2eccd2b8fb1`
Expected tests: 469/469 PASS.
Expected HTML shell SHA256: `296feef99052aa35409c93513239c72ae1ad728f2082116cd53b97284d1b7c57`.
Expected S10A.2 shield SHA256: `7da40dfe73e36de2df70c1e1efd75efcfaf60fda53325a60a509435368ee7221`.
Expected S10A.2 quarantine writer SHA256: `cac56daf9cc8495041dcff1a861edeb9a3caf5723e329ef6445653525948b8a8`.

The preparation script removes this helper ZIP from the final tree, verifies the exact S10A.1 parent tree, overlays the exact verified S10A.2 payload, runs full verification, proves the exact 1365-file tree, creates one local RC-branch commit, and STOPS before push.

Do not upload this package to `main`.
