# EMG-D1-P1 — READ FIRST

Ini adalah **Prompt Besar 1 dari 2** untuk business-continuity Segeran Jiwa POS lama.

Tujuan: menambah Cloudflare Worker + D1 sebagai **standby emergency backend**, sementara Firebase tetap Production authority normal.

## Yang TIDAK dilakukan
- Tidak memigrasikan Firebase.
- Tidak auto-failover.
- Tidak mengubah normal `processTransaction()`.
- Tidak menghidupkan automatic QRIS bridge/polling.
- Tidak melakukan reconciliation D1 -> Firebase (itu Prompt Besar 2).
- Tidak merge ke `main`.

## Yang dilakukan one-shot
1. membuat isolated worktree dari `origin/main` terbaru;
2. baseline test + R6D gate;
3. TDD RED;
4. menambah D1 schema, Worker API, emergency client, docs/tests;
5. pre-provision regression gate;
6. login Wrangler bila diperlukan;
7. create/reuse D1 + apply schema + deploy Worker + secrets;
8. remote health/auth/D1 drill;
9. fresh full verify + REF01 + R6D;
10. exact frozen/scope guard;
11. commit + push branch `emg-d1-p1-foundation` untuk Preview.

## Penting
Saat script berjalan pertama kali, Wrangler dapat membuka/mencetak URL login Cloudflare. Selesaikan login tersebut lalu kembali ke terminal yang sama. Script akan melanjutkan.

Pada akhir script akan dicetak **OWNER KEY** seperti `SJ-EMG-XXXXXXXXXXXX`. Simpan key ini. Secret signing tidak pernah masuk Git.

Jika ada `HARD STOP`, jangan reset/clean/force apa pun. Kirim screenshot terminal.
