# EMG-D1-P1 TDD / Verification Gates

The one-shot script requires:
- clean canonical `origin/main` baseline in a new worktree;
- baseline `npm test` PASS;
- baseline R6D PASS;
- TDD RED presence test fails for missing emergency feature;
- TDD GREEN core/contract/presence tests PASS;
- Worker/core/client syntax PASS;
- pre-provision R6D gate PASS;
- Cloudflare remote health/auth/D1 drill PASS;
- final targeted tests PASS on actual Worker URL;
- `npm run verify` PASS;
- `npm run verify:ref01` PASS;
- `npm run verify:rc01:s10c-r6d` PASS;
- `git diff --check` PASS;
- frozen hashes for QRIS deferred/manual/ref01/sync authority unchanged;
- exact final scope only P1 files;
- only then commit/push Preview.

The package cannot claim the repository full suite is passing before it runs in the real Codespace; the script is fail-closed and will not push when any gate fails.

## Final package hardening (2026-09-07)
- duplicate product lines are aggregated before transaction/inventory statements;
- provisioning requires `openssl` and declares required Worker secrets;
- OWNER KEY backup is recreated on every safe rerun from the private secret file;
- package checks its own SHA256 manifest before touching the repository;
- local synthetic integration gate: 15/15 PASS (core + contract + presence);
- Cloudflare Wrangler command shapes were cross-checked against current D1/Workers documentation.

Full repository verification is still intentionally deferred to the one-shot run in the real Codespace. The script will not commit/push if `npm run verify`, REF01, or R6D fails.
