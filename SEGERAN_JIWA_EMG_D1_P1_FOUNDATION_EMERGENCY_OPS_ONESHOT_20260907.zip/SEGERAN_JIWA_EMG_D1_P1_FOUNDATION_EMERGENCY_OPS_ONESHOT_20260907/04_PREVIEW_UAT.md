# EMG-D1-P1 Preview UAT

Run ONLY on Cloudflare hashed Preview branch `emg-d1-p1-foundation`. Do not merge to Production yet.

1. Open normal Preview and confirm normal Firebase POS still works normally.
2. Tap `MODE DARURAT D1`.
3. Enter the Owner Key printed by the one-shot script.
4. In Status, run `Cek D1` -> must show ONLINE/schema 1.
5. While Firebase is healthy, press `Perbarui Snapshot dari POS Normal`.
6. Press `Aktifkan Operasional Darurat`.
7. Open an emergency shift. Hashed Preview must be marked `PREVIEW / DRILL`.
8. Create one Tunai transaction.
9. Create one Transfer transaction and manually confirm it.
10. Create one QRIS transaction: QRIS/manual merchant check -> confirm. There must be no automatic bridge/polling/waiting settlement.
11. Record one emergency expense.
12. Close emergency shift; confirm expected/actual/variance is returned.
13. Close the emergency overlay and verify the ordinary POS is still Firebase-default.
14. Do NOT merge to main before reporting `EMG-D1-P1 Preview PASS`.

If any step fails, stop. Do not edit D1 manually and do not merge Production.
