#!/usr/bin/env python3
from pathlib import Path

path = Path('scripts/build-ref01.mjs')
s = path.read_text()
if 'EMG_D1_P1_ENTRY' in s:
    raise SystemExit('EMG-D1 P1 already applied')
needle = "const ENTRY='<script type=\"module\" src=\"./src/ref01-entry.js\" data-sj-ref01-entry=\"true\"></script>';"
if s.count(needle) != 1:
    raise SystemExit('HARD STOP: REF01 ENTRY anchor not unique')
insert = "const EMG_D1_P1_CONFIG_ENTRY='<script src=\"./src/compat/emg-d1-p1-config.js\" data-sj-emg-d1-p1-config=\"true\"></script>';\nconst EMG_D1_P1_ENTRY='<script src=\"./src/compat/emg-d1-p1-emergency.js\" data-sj-emg-d1-p1=\"true\"></script>';\n" + needle
s = s.replace(needle, insert, 1)
needle2 = '${ENTRY}\\n</body>`);'
if s.count(needle2) != 1:
    raise SystemExit('HARD STOP: build tail anchor not unique')
s = s.replace(needle2, '${ENTRY}\\n${EMG_D1_P1_CONFIG_ENTRY}\\n${EMG_D1_P1_ENTRY}\\n</body>`);', 1)
path.write_text(s)
print('EMG-D1 P1 build-ref01 transform applied')
