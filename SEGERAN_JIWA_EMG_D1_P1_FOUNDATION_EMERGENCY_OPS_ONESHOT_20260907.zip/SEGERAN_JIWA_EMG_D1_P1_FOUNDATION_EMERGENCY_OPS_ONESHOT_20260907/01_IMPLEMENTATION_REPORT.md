# EMG-D1-P1 Implementation Report

## Architecture
- Normal: POS -> Firebase RTDB (unchanged).
- Emergency: dedicated UI -> Cloudflare Worker -> D1.
- Owner activation only; no silent failover.
- Worker endpoint is cross-origin but restricted to canonical Segeran Jiwa Pages host and hashed Preview children.

## Emergency capabilities P1
- health/status;
- sanitized master snapshot;
- emergency Owner auth with HMAC token and auth lock;
- open/close D1 shift;
- Tunai / Transfer / QRIS manual sales;
- server-side price calculation from D1 snapshot;
- product stock balance + inventory/cup usage events;
- expense/cash events;
- audit trail;
- idempotent operation IDs;
- Preview data tagged as drill.

## Explicitly deferred to P2
- D1 -> Firebase replay/reconciliation;
- failback button;
- partial reconciliation recovery;
- unreconciled owner review page;
- end-to-end failover/failback production drill.
