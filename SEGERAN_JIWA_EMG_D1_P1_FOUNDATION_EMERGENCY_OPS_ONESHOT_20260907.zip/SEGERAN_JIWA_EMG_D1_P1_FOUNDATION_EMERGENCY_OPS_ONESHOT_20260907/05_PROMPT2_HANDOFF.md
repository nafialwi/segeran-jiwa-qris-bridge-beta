# Prompt Besar 2 Handoff

After P1 Preview is locked, P2 will implement:
- owner view of non-drill, unreconciled D1 operations;
- reconciliation preview and explicit Owner approval;
- idempotent replay to Firebase authorities for transactions/payment/cash/shift/expense/inventory;
- anti-double omzet/stock/cash;
- per-operation reconciliation state and partial failure retry;
- audit evidence;
- controlled return to Firebase primary;
- simulated Firebase unavailable -> D1 operations -> Firebase recovery -> reconciliation -> failback;
- full regression, Preview UAT, Production deployment and final lock.

P2 must never reconcile rows with `is_drill=1`.
