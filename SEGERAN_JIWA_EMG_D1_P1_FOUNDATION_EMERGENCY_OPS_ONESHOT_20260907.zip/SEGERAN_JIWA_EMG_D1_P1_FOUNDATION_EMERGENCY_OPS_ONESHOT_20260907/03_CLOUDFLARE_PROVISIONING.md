# Cloudflare provisioning notes

Resources created/reused by P1:
- D1: `segeran-jiwa-emergency-db` (location hint APAC)
- Worker: `segeran-jiwa-emergency`
- D1 binding: `SJ_EMERGENCY_DB`
- Secrets: `SJ_EMERGENCY_OWNER_KEY`, `SJ_EMERGENCY_SIGNING_KEY`

Secrets are written only to Cloudflare and a private Codespace path outside the Git repository. `emergency-d1/wrangler.toml` contains the D1 UUID, which is not a secret.

The Worker `workers.dev` URL is generated into `src/compat/emg-d1-p1-config.js`. The emergency client never contains the Owner key or signing key.

If Wrangler is not logged in, the one-shot script invokes `wrangler login`. No Cloudflare billing upgrade is requested by this package.
