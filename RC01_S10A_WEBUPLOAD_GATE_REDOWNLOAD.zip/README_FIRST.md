# RC01-S10A Web Upload Gate

Purpose: move the locally verified RC01-S10A correction pack into the existing GitHub RC branch using the user's established GitHub-web-upload + Codespaces workflow, while keeping `main` and Cloudflare Production untouched.

Expected branch: `rc01-v3.4-release-candidate`.
Expected tested RC base: `e4b8a8a321032ca52053435f41d86e7e4650fc06`.
Expected main authority: `0d396829ad2ebb4ba0688e4c9b4aa2eccd2b8fb1`.
Expected S10A runtime SHA256: `b2f5295945d610c0a451be5db13172dbd6791616e4c927315219ff63c824d58c`.
Expected full tests: 459/459 PASS.

The preparation script removes this helper ZIP from the final tree, overlays the exact verified S10A payload, runs full verification, proves the exact tree, makes one LOCAL RC-branch commit, and STOPS before push.

Do not upload this package to `main`.
