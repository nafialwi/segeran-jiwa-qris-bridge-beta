#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_SLUG="${S10A_EXPECTED_REPO_SLUG:-nafialwi/segeran-jiwa-qris-bridge-beta}"
EXPECTED_MAIN="${S10A_EXPECTED_MAIN:-0d396829ad2ebb4ba0688e4c9b4aa2eccd2b8fb1}"
EXPECTED_RC_BASE="${S10A_EXPECTED_RC_BASE:-e4b8a8a321032ca52053435f41d86e7e4650fc06}"
BRANCH="${S10A_BRANCH:-rc01-v3.4-release-candidate}"
EXPECTED_INDEX="b2f5295945d610c0a451be5db13172dbd6791616e4c927315219ff63c824d58c"
EXPECTED_TESTS=459
EXPECTED_FILE_COUNT=1349
CALLER_PWD="$PWD"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
TREE_MANIFEST="$HERE/checksums/S10A_EXPECTED_TREE_SHA256.txt"
PAYLOAD_MANIFEST="$HERE/checksums/S10A_PAYLOAD_SHA256.txt"

stop(){ echo; echo "STOP: $*" >&2; exit 20; }
pass(){ echo "PASS: $*"; }

for c in git node npm sha256sum; do command -v "$c" >/dev/null || stop "$c is not available"; done
[[ -d "$PAYLOAD" ]] || stop "payload directory missing"
[[ -f "$TREE_MANIFEST" ]] || stop "tree checksum manifest missing"
[[ -f "$PAYLOAD_MANIFEST" ]] || stop "payload checksum manifest missing"

cd "$PAYLOAD"
sha256sum -c "$PAYLOAD_MANIFEST" >/tmp/s10a-payload-check.log || { tail -n 100 /tmp/s10a-payload-check.log; stop "package payload checksum mismatch"; }
pass "S10A package payload checksums"

REPO="$(git -C "$CALLER_PWD" rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO" && -n "${CODESPACE_NAME:-}" && -d /workspaces ]]; then
  REPO="$(find /workspaces -mindepth 1 -maxdepth 2 -type d -name .git -printf '%h\n' 2>/dev/null | head -n1 || true)"
fi
[[ -n "$REPO" && -d "$REPO/.git" ]] || stop "cannot locate Codespace git repository; cd to repo root and rerun"
cd "$REPO"

echo "Repository: $REPO"
REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
[[ -n "$REMOTE_URL" ]] || stop "origin remote missing"
case "$REMOTE_URL" in *"$EXPECTED_SLUG"*) ;; *) stop "origin is not expected repository: $REMOTE_URL" ;; esac
pass "expected existing GitHub repository"

CURRENT_BRANCH="$(git branch --show-current)"
[[ "$CURRENT_BRANCH" == "$BRANCH" ]] || stop "open Codespace on branch '$BRANCH'; current branch is '$CURRENT_BRANCH'"
[[ -z "$(git status --porcelain)" ]] || { git status --short; stop "working tree is not clean"; }
pass "RC branch working tree initially clean"

git fetch --quiet origin main "$BRANCH"
REMOTE_MAIN="$(git rev-parse origin/main)"
LOCAL_HEAD="$(git rev-parse HEAD)"
REMOTE_RC="$(git rev-parse "origin/$BRANCH" 2>/dev/null || true)"
[[ "$REMOTE_MAIN" == "$EXPECTED_MAIN" ]] || stop "origin/main changed: expected $EXPECTED_MAIN but found $REMOTE_MAIN. Return this message to ChatGPT."
[[ -n "$REMOTE_RC" && "$LOCAL_HEAD" == "$REMOTE_RC" ]] || stop "local RC branch is not synchronized with origin/$BRANCH"

# Web upload must be exactly one helper commit on top of the tested RC-01 base.
PARENT="$(git rev-parse HEAD^)"
[[ "$PARENT" == "$EXPECTED_RC_BASE" ]] || stop "uploaded helper commit is not directly on tested RC base. expected parent $EXPECTED_RC_BASE but found $PARENT"
[[ "$(git merge-base origin/main "$EXPECTED_RC_BASE")" == "$EXPECTED_MAIN" ]] || stop "tested RC base no longer descends from expected main authority"
pass "tested RC base $EXPECTED_RC_BASE and main authority $EXPECTED_MAIN confirmed"

mapfile -t DIFF_LINES < <(git diff --name-status "$EXPECTED_RC_BASE"..HEAD)
[[ "${#DIFF_LINES[@]}" -eq 1 ]] || { printf '%s\n' "${DIFF_LINES[@]}"; stop "web-upload bootstrap must contain exactly one helper ZIP change"; }
STATUS="${DIFF_LINES[0]%%$'\t'*}"
UPLOAD_FILE="${DIFF_LINES[0]#*$'\t'}"
[[ "$STATUS" == "A" ]] || stop "the helper change must be an added ZIP, found '$STATUS'"
case "$UPLOAD_FILE" in
  SEGERAN_JIWA_POS_v3.4_RC01_S10A_QRIS_HARDENING_WEBUPLOAD_GATE*.zip) ;;
  *) stop "unexpected helper file '$UPLOAD_FILE'" ;;
esac
[[ -f "$UPLOAD_FILE" ]] || stop "uploaded helper ZIP not present in repository root"
pass "isolated web-upload helper commit contains only $UPLOAD_FILE"

rm -f -- "$UPLOAD_FILE"
cp -a "$PAYLOAD"/. "$REPO"/
pass "helper ZIP removed from final tree; exact S10A payload overlaid"

echo
echo "=== FRESH S10A VERIFICATION ==="
npm run verify:rc01:s10a | tee /tmp/s10a-verify.log

grep -Eq "(^|[^0-9])pass[[:space:]]+$EXPECTED_TESTS([^0-9]|$)" /tmp/s10a-verify.log || stop "fresh full test count is not $EXPECTED_TESTS PASS"
grep -Eq "(^|[^0-9])fail[[:space:]]+0([^0-9]|$)" /tmp/s10a-verify.log || stop "fresh full suite contains failures"
grep -q "RC-01 release contract PASS" /tmp/s10a-verify.log || stop "RC01 release verifier did not PASS"
grep -q "RC01-S10A verification PASS" /tmp/s10a-verify.log || stop "S10A verifier did not PASS"
pass "fresh verify:rc01:s10a = $EXPECTED_TESTS/$EXPECTED_TESTS + RC/S10A contracts PASS"

echo
echo "=== CLOUDFLARE CURRENT BUILD COMMAND REHEARSAL ==="
npm run build:ref01 | tee /tmp/s10a-cloudflare-build.log
REF_SHA="$(sha256sum dist-ref01/index.html | awk '{print $1}')"
RC_SHA="$(sha256sum dist-rc01/index.html | awk '{print $1}')"
[[ "$REF_SHA" == "$EXPECTED_INDEX" ]] || stop "dist-ref01 runtime hash mismatch: $REF_SHA"
[[ "$RC_SHA" == "$EXPECTED_INDEX" ]] || stop "dist-rc01 runtime hash mismatch: $RC_SHA"
[[ "$REF_SHA" == "$RC_SHA" ]] || stop "Cloudflare REF01 output is not identical to S10A RC runtime"
pass "Cloudflare build:ref01 runtime == S10A runtime ($EXPECTED_INDEX)"

# Verifiers rewrite audit/generated files; restore exact packaged authority before final tree proof.
cp -a "$PAYLOAD"/. "$REPO"/

TMP_EXPECT="$(mktemp)"; TMP_ACTUAL="$(mktemp)"
awk '{sub(/^\.\//,"",$2); print $2}' "$TREE_MANIFEST" | sort > "$TMP_EXPECT"
find . -path './.git' -prune -o -type f -printf '%P\n' | sort > "$TMP_ACTUAL"
ACTUAL_COUNT="$(wc -l < "$TMP_ACTUAL" | tr -d ' ')"
[[ "$ACTUAL_COUNT" == "$EXPECTED_FILE_COUNT" ]] || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "unexpected file count $ACTUAL_COUNT; expected $EXPECTED_FILE_COUNT"; }
cmp -s "$TMP_EXPECT" "$TMP_ACTUAL" || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "repository file set does not exactly match S10A source authority"; }
(cd "$REPO" && sha256sum -c "$TREE_MANIFEST") >/tmp/s10a-tree-check.log || { tail -n 100 /tmp/s10a-tree-check.log; stop "S10A full-tree checksum mismatch"; }
rm -f "$TMP_EXPECT" "$TMP_ACTUAL"
pass "exact $EXPECTED_FILE_COUNT-file S10A source tree checksums"

git add -A
[[ -n "$(git status --porcelain)" ]] || stop "no S10A changes detected"

if ! git config user.name >/dev/null || ! git config user.email >/dev/null; then
  stop "git identity is not configured. No commit was made. Send this STOP message to ChatGPT."
fi

git commit -m "fix(qris): harden deferred settlement recovery" >/tmp/s10a-commit.log
cat /tmp/s10a-commit.log
COMMIT="$(git rev-parse HEAD)"

[[ "$(git rev-parse origin/main)" == "$EXPECTED_MAIN" ]] || stop "origin/main moved unexpectedly"
[[ "$(git branch --show-current)" == "$BRANCH" ]] || stop "not on RC branch after commit"
[[ -z "$(git status --porcelain)" ]] || stop "working tree not clean after local S10A commit"
pass "local S10A commit created on RC preview branch; main unchanged"

echo
echo "============================================================"
echo "RC01-S10A WEB-UPLOAD CODESPACE PREPARE: PASS"
echo "branch=$BRANCH"
echo "main=$EXPECTED_MAIN"
echo "tested_rc_base=$EXPECTED_RC_BASE"
echo "helper_remote_commit=$REMOTE_RC"
echo "s10a_commit=$COMMIT"
echo "tests=$EXPECTED_TESTS/$EXPECTED_TESTS PASS"
echo "rc_verifier=PASS"
echo "s10a_verifier=PASS"
echo "runtime_sha256=$EXPECTED_INDEX"
echo "main_pushed=NO"
echo "s10a_final_push=NO"
echo "cloudflare_production_mutated=NO"
echo "firebase_rules_root_mutated=NO"
echo "appmint_webview=DEFERRED_NA_WEB_RELEASE"
echo "NEXT=STOP and send this summary to ChatGPT before final RC branch push"
echo "============================================================"
