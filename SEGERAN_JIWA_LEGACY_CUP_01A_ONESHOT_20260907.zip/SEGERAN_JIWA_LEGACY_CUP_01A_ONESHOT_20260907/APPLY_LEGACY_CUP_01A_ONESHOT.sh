#!/usr/bin/env bash
set -euo pipefail

BASE_SHORT='d1f714e'
FEATURE='legacy-cup-01a-paper10'
WORKTREE='/workspaces/legacy-cup-01a-paper10'
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TRANSFORM="$SELF_DIR/APPLY_LEGACY_CUP_01A.py"
TEST_FILE="$SELF_DIR/tests/legacy-cup-01a-paper10.test.mjs"

stop(){ echo; echo "HARD STOP: $*" >&2; echo "main/Production tidak disentuh." >&2; exit 1; }
command -v git >/dev/null || stop 'git tidak tersedia'
command -v node >/dev/null || stop 'node tidak tersedia'
command -v npm >/dev/null || stop 'npm tidak tersedia'
command -v python3 >/dev/null || stop 'python3 tidak tersedia'
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[[ -n "$ROOT" ]] || stop 'jalankan dari dalam repository Segeran Jiwa POS'
cd "$ROOT"

echo '=== Preflight ==='
git fetch origin
REMOTE_SHORT="$(git rev-parse --short origin/main)"
[[ "$REMOTE_SHORT" == "$BASE_SHORT" ]] || stop "origin/main berubah: expected $BASE_SHORT, actual $REMOTE_SHORT"
if git ls-remote --exit-code --heads origin "$FEATURE" >/dev/null 2>&1; then stop "branch remote $FEATURE sudah ada; tidak overwrite otomatis"; fi
if git worktree list --porcelain | grep -Fqx "worktree $WORKTREE"; then stop "worktree $WORKTREE sudah ada; tidak menghapus otomatis"; fi
if git show-ref --verify --quiet "refs/heads/$FEATURE"; then stop "branch lokal $FEATURE sudah ada; tidak menghapus otomatis"; fi

# Never touch the user's current (possibly dirty) Codespace checkout.
git worktree add -b "$FEATURE" "$WORKTREE" origin/main
cd "$WORKTREE"
[[ -z "$(git status --porcelain -uall)" ]] || stop 'worktree baru tidak bersih'
if [[ -d "$ROOT/node_modules" && ! -e "$WORKTREE/node_modules" ]]; then ln -s "$ROOT/node_modules" "$WORKTREE/node_modules"; fi

mkdir -p tests
cp "$TEST_FILE" tests/legacy-cup-01a-paper10.test.mjs

echo '=== TDD RED: Cup Paper 10 Oz belum ada di baseline ==='
set +e
node --test tests/legacy-cup-01a-paper10.test.mjs >/tmp/legacy-cup-01a-red.log 2>&1
RED_RC=$?
set -e
cat /tmp/legacy-cup-01a-red.log
[[ $RED_RC -ne 0 ]] || stop 'TDD RED tidak gagal; baseline tidak sesuai ekspektasi'

echo '=== Exact production transform + existing regression expectation updates ==='
python3 "$TRANSFORM" "$WORKTREE"
git diff --check

echo '=== TDD GREEN: targeted Cup engine ==='
node --test tests/legacy-cup-01a-paper10.test.mjs tests/v34-p5-batch2-*.test.mjs

echo '=== Full repository verification ==='
npm run verify

echo '=== SC04 chain ==='
npm run verify:sc04

echo '=== REF01 chain ==='
npm run verify:ref01

echo '=== R6D production guard ==='
npm run verify:rc01:s10c-r6d

# Verification can regenerate tracked/untracked audit/dist outputs. Restore only generated surfaces.
git restore --source=HEAD -- audit dist dist-sc03 dist-sc04 dist-ref01 dist-rc01 2>/dev/null || true
git clean -fd -- dist dist-sc03 dist-sc04 dist-ref01 dist-rc01 >/dev/null 2>&1 || true

git diff --check
EXPECTED=$(cat <<'EOF'
src/domain/packaging-cup-v34.js
src/ui/cup-product-costing-v34.js
src/ui/cup-shift-control-v34.js
src/ui/inventory-workspace-v32.js
tests/legacy-cup-01a-paper10.test.mjs
tests/v34-p5-batch2-cup-inventory-ui.test.mjs
tests/v34-p5-batch2-cup-packaging.test.mjs
tests/v34-p5-batch2-cup-product-costing.test.mjs
tests/v34-p5-batch2-cup-shift.test.mjs
tests/v34-p5-batch2-final-qa-hardening.test.mjs
EOF
)
ACTUAL="$(git status --porcelain -uall | sed -E 's/^.. //' | sort)"
[[ "$ACTUAL" == "$(printf '%s\n' "$EXPECTED" | sort)" ]] || { echo 'Final scope tidak sesuai:'; git status --short; stop 'scope guard'; }

# Preserve P0-BW01 R6 production authority byte-for-byte.
for f in scripts/build-ref01.mjs src/compat/rc01-sync-authority.js src/compat/rc01-qris-manual-bypass.js src/compat/rc01-qris-deferred-settlement-compat.js src/ref01-entry.js; do
  git diff --exit-code origin/main -- "$f" >/dev/null || stop "R6/frozen authority drift: $f"
done

git add \
  src/domain/packaging-cup-v34.js \
  src/ui/cup-product-costing-v34.js \
  src/ui/cup-shift-control-v34.js \
  src/ui/inventory-workspace-v32.js \
  tests/legacy-cup-01a-paper10.test.mjs \
  tests/v34-p5-batch2-cup-inventory-ui.test.mjs \
  tests/v34-p5-batch2-cup-packaging.test.mjs \
  tests/v34-p5-batch2-cup-product-costing.test.mjs \
  tests/v34-p5-batch2-cup-shift.test.mjs \
  tests/v34-p5-batch2-final-qa-hardening.test.mjs

git commit -m 'feat: add unmapped Cup Paper 10 Oz inventory control'
git push -u origin "$FEATURE"

echo
echo '============================================================'
echo 'LEGACY-CUP-01A ONESHOT PASS'
echo "Branch: $FEATURE"
echo "Baseline main: $BASE_SHORT"
echo 'Cup Paper 10 Oz: STOCK/INITIAL/OPENING/CLOSING/OPNAME ENABLED'
echo 'Cup Paper 10 Oz sale/product/category mapping: DISABLED'
echo 'Existing five sale cup mappings: PRESERVED'
echo 'P0-BW01 R6 QRIS/manual + sync authority files: UNCHANGED'
echo 'Full verify + SC04 + REF01 + R6D: PASS'
echo 'Branch sudah dipush; tunggu Cloudflare Preview.'
echo 'Production/main: BELUM DISENTUH'
echo '============================================================'
