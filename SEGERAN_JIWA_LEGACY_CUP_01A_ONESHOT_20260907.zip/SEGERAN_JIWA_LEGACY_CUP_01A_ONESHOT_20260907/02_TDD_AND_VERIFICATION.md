# TDD & Verification Strategy

One-shot script menjalankan TDD nyata di Codespaces:
1. membuat linked worktree bersih dari `origin/main` (`d1f714e`) sehingga Codespace/main user yang mungkin kotor tidak disentuh;
2. menyalin test LEGACY-CUP-01A lalu menjalankannya **sebelum** perubahan source dan mewajibkan RED;
3. menjalankan exact-string transformer yang fail-closed bila baseline source tidak cocok;
4. menjalankan targeted LEGACY-CUP-01A + seluruh `v34-p5-batch2-*` GREEN;
5. `npm run verify`;
6. `npm run verify:sc04`;
7. `npm run verify:ref01`;
8. `npm run verify:rc01:s10c-r6d`;
9. membersihkan hanya generated audit/dist, lalu final 10-file scope guard;
10. memastikan authority P0-BW01 R6 tidak berubah;
11. commit dan push `legacy-cup-01a-paper10` hanya bila seluruh gate PASS.

Tidak ada merge ke `main`/Production dalam script.

Package validation lokal sebelum diberikan ke user:
- Python transformer compile;
- shell syntax;
- Node syntax test baru;
- synthetic exact-transform test untuk semua target replacement;
- ZIP integrity + SHA256 manifest.

Full repository regression hanya dianggap PASS bila script benar-benar menjalankannya di Codespaces repo asli.
