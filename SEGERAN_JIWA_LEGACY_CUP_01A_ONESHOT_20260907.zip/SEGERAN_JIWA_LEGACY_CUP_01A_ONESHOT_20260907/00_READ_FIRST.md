# LEGACY-CUP-01A — One-shot GitHub-root package

Tujuan: menambah **Cup Paper 10 Oz** sebagai cup ke-6 pada Segeran Jiwa POS legacy.

Keputusan terkunci:
- code: `c10p`
- name: `Cup Paper 10 Oz`
- unit: `pcs`
- Inventory V2 / Bahan & Gudang: YA
- initial setup / Gudang / Gerai / WAC: YA
- opening physical count: YA
- closing physical count + variance + opname draft: YA
- mapping produk/kategori: **TIDAK** (ditunda)
- writer/schema baru: TIDAK
- zero-cost: tetap
- P0-BW01 R6 QRIS/manual/sync authority: tidak disentuh

Workflow user: **upload ZIP ke root GitHub transfer branch → buka Codespaces existing → satu command → isolated coding/TDD/full verification/commit/push Preview otomatis**.

Script tidak switch/reset/clean workspace utama user. Implementasi dilakukan di linked worktree `/workspaces/legacy-cup-01a-paper10`.
