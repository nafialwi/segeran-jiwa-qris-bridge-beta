# LEGACY-CUP-01A Implementation Report

Baseline Production target: `main` merge commit `d1f714e`.

Perubahan source:
1. `src/domain/packaging-cup-v34.js`
   - tambah `c10p` / `Cup Paper 10 Oz` / `pcs`;
   - alias Inventory V2;
   - `saleMapping:false` karena mapping produk belum disetujui.
2. `src/ui/cup-product-costing-v34.js`
   - dropdown mapping hanya memuat cup dengan `saleMapping !== false`, sehingga c10p tidak bisa termapping tanpa CR berikutnya.
3. `src/ui/cup-shift-control-v34.js`
   - opening/closing mengikuti ukuran catalog 6;
   - readiness dan pesan validasi tidak lagi hardcoded 5.
4. `src/ui/inventory-workspace-v32.js`
   - all-ready label dan teks initial setup mengikuti ukuran catalog 6.

Existing P5 Batch-2 regression yang secara sah mengunci jumlah 5 diperbarui menjadi 6. Test baru memastikan c10p masuk Inventory/initial/opening/closing tetapi tetap tidak masuk sale mapping.

Tidak ada writer/schema/database baru. P0-BW01 R6 QRIS/manual/sync authority tidak disentuh.
