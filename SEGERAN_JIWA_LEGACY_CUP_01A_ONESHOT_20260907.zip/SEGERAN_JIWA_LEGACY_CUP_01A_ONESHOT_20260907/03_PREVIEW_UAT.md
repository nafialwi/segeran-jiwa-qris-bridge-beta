# Preview UAT — singkat

Setelah branch `legacy-cup-01a-paper10` Cloudflare Preview hijau:

1. Owner → Operasional → Bahan & Gudang → Kemasan & Cup
   - ada **Cup Paper 10 Oz** sebagai baris ke-6;
   - bila belum dibuat: `Belum terdaftar` / setup master existing.
2. Initial setup
   - Cup Paper 10 Oz punya Gudang awal, Gerai awal, WAC awal.
3. Buka Shift
   - Hitung Cup Awal memuat Cup Paper 10 Oz.
4. Tutup Shift
   - Hitung Cup Akhir memuat Cup Paper 10 Oz dan variance/opname draft berjalan.
5. Mapping Cup per Kategori / Edit Produk
   - **Cup Paper 10 Oz tidak boleh muncul** sebagai opsi mapping.
6. Smoke R6
   - QRIS tetap manual; tidak ada bridge otomatis.
