#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path


def fail(message: str) -> None:
    raise SystemExit(f"HARD STOP: {message}")


def replace_exact(root: Path, rel: str, old: str, new: str, expected: int = 1) -> None:
    path = root / rel
    if not path.is_file():
        fail(f"file target tidak ditemukan: {rel}")
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != expected:
        fail(f"precondition {rel}: expected {expected} occurrence, actual {count}: {old[:100]!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")
    print(f"PATCHED {rel}: {count} replacement")


def require(root: Path, rel: str, needle: str, expected: int | None = None) -> None:
    path = root / rel
    text = path.read_text(encoding="utf-8")
    count = text.count(needle)
    if expected is not None and count != expected:
        fail(f"postcondition {rel}: expected {expected} occurrence, actual {count}: {needle!r}")
    if expected is None and count < 1:
        fail(f"postcondition {rel}: marker hilang: {needle!r}")


def forbid(root: Path, rel: str, needle: str) -> None:
    path = root / rel
    if needle in path.read_text(encoding="utf-8"):
        fail(f"postcondition {rel}: marker lama masih ada: {needle!r}")


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: APPLY_LEGACY_CUP_01A.py <repo-root>")
    root = Path(sys.argv[1]).resolve()
    if not (root / "src/domain/packaging-cup-v34.js").is_file():
        fail(f"bukan root repo Segeran Jiwa yang sesuai: {root}")

    # --- Production source changes ---
    replace_exact(
        root,
        "src/domain/packaging-cup-v34.js",
        "  Object.freeze({code:'c10',name:'Cup 10 Oz',unit:'pcs',aliases:Object.freeze(['CUP 10 OZ','GELAS 10 OZ','CUP 10OZ','GELAS 10OZ'])}),\n",
        "  Object.freeze({code:'c10',name:'Cup 10 Oz',unit:'pcs',aliases:Object.freeze(['CUP 10 OZ','GELAS 10 OZ','CUP 10OZ','GELAS 10OZ'])}),\n"
        "  Object.freeze({code:'c10p',name:'Cup Paper 10 Oz',unit:'pcs',saleMapping:false,aliases:Object.freeze(['CUP PAPER 10 OZ','PAPER CUP 10 OZ','GELAS PAPER 10 OZ','CUP PAPER 10OZ','PAPER CUP 10OZ','GELAS PAPER 10OZ'])}),\n",
    )

    replace_exact(
        root,
        "src/ui/cup-product-costing-v34.js",
        "function options(selected=''){\n  return `<option value=\"\">Per produk / tanpa cup</option>${CUP_CATALOG_V34.map(x=>`<option value=\"${x.code}\" ${selected===x.code?'selected':''}>${esc(x.name)}</option>`).join('')}`;\n}",
        "function options(selected=''){\n  const mapped=CUP_CATALOG_V34.filter(x=>x.saleMapping!==false);\n  return `<option value=\"\">Per produk / tanpa cup</option>${mapped.map(x=>`<option value=\"${x.code}\" ${selected===x.code?'selected':''}>${esc(x.name)}</option>`).join('')}`;\n}",
    )

    replace_exact(
        root,
        "src/ui/cup-shift-control-v34.js",
        "Cup Control belum lengkap (${registered}/5 master).",
        "Cup Control belum lengkap (${registered}/${CUP_CATALOG_V34.length} master).",
    )
    replace_exact(
        root,
        "src/ui/cup-shift-control-v34.js",
        "const ready=()=>cupRows.filter(x=>x.registered).length===5;",
        "const ready=()=>cupRows.filter(x=>x.registered).length===CUP_CATALOG_V34.length;",
    )
    replace_exact(
        root,
        "src/ui/cup-shift-control-v34.js",
        "e.code==='CUP_COUNT_REQUIRED'?'Hitung semua 5 jenis cup sebelum membuka shift.'",
        "e.code==='CUP_COUNT_REQUIRED'?`Hitung semua ${CUP_CATALOG_V34.length} jenis cup sebelum membuka shift.`",
    )
    replace_exact(
        root,
        "src/ui/cup-shift-control-v34.js",
        "e.code==='CUP_COUNT_REQUIRED'?'Hitung semua 5 jenis cup sebelum menutup shift.'",
        "e.code==='CUP_COUNT_REQUIRED'?`Hitung semua ${CUP_CATALOG_V34.length} jenis cup sebelum menutup shift.`",
    )

    replace_exact(
        root,
        "src/ui/inventory-workspace-v32.js",
        "'<span class=\"sj-v32-inv-ok\">5 master cup siap</span>'",
        "`<span class=\"sj-v32-inv-ok\">${CUP_CATALOG_V34.length} master cup siap</span>`",
    )
    replace_exact(
        root,
        "src/ui/inventory-workspace-v32.js",
        "untuk lima jenis cup.",
        "untuk ${CUP_CATALOG_V34.length} jenis cup.",
    )

    # --- Existing P5 regression expectations legitimately updated from 5 -> 6 ---
    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-packaging.test.mjs",
        "test('P5 Batch-2 defines exactly five Segeran Jiwa cup types using existing product cp codes',()=>{\n  assert.deepEqual(CUP_CATALOG_V34.map(x=>x.code),['c10','c16','c22p','c22d','c22o']);\n  assert.equal(cupSpecByCodeV34('c22p').name,'Cup 22 Oz Datar Polos');",
        "test('LEGACY-CUP-01A defines six stock-controlled cup types while Paper 10 Oz stays unmapped',()=>{\n  assert.deepEqual(CUP_CATALOG_V34.map(x=>x.code),['c10','c10p','c16','c22p','c22d','c22o']);\n  assert.equal(cupSpecByCodeV34('c10p').name,'Cup Paper 10 Oz');\n  assert.equal(cupSpecByCodeV34('c10p').saleMapping,false);\n  assert.equal(cupSpecByCodeV34('c22p').name,'Cup 22 Oz Datar Polos');",
    )
    replace_exact(root, "tests/v34-p5-batch2-cup-packaging.test.mjs", "  assert.equal(rows.length,5);", "  assert.equal(rows.length,6);")
    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-packaging.test.mjs",
        "  assert.equal(out.c16,2);assert.equal(out.c22d,1);assert.equal(out.c22o,3);assert.equal(out.c10,0);",
        "  assert.equal(out.c16,2);assert.equal(out.c22d,1);assert.equal(out.c22o,3);assert.equal(out.c10,0);assert.equal(out.c10p,0);",
    )

    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-inventory-ui.test.mjs",
        "test('P5 Batch-2 Inventory V3 renders all five Cup/Kemasan rows separately from Bahan Baku',()=>{",
        "test('LEGACY-CUP-01A Inventory V3 renders all six Cup/Kemasan rows separately from Bahan Baku',()=>{",
    )
    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-inventory-ui.test.mjs",
        "  assert.match(html,/Cup 10 Oz/);\n  assert.match(html,/Cup 16 Oz/);",
        "  assert.match(html,/Cup 10 Oz/);\n  assert.match(html,/Cup Paper 10 Oz/);\n  assert.match(html,/Cup 16 Oz/);",
    )

    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-product-costing.test.mjs",
        "  assert.match(html,/Mapping Cup per Kategori/);assert.match(html,/Cup 10 Oz/);assert.match(html,/Cup 22 Oz Datar Polos/);\n  assert.match(html,/data-v34-cup-category=\"ES TEH\"/);",
        "  assert.match(html,/Mapping Cup per Kategori/);assert.match(html,/Cup 10 Oz/);assert.match(html,/Cup 22 Oz Datar Polos/);\n  assert.doesNotMatch(html,/Cup Paper 10 Oz/,'Cup Paper 10 Oz must stay outside sale mapping until explicitly mapped later');\n  assert.doesNotMatch(html,/value=\"c10p\"/);\n  assert.match(html,/data-v34-cup-category=\"ES TEH\"/);",
    )

    replace_exact(
        root,
        "tests/v34-p5-batch2-cup-shift.test.mjs",
        "  assert.throws(()=>collectCupCountValuesV34({c10:'',c16:1,c22p:1,c22d:1,c22o:1}),/CUP_COUNT_REQUIRED/);\n  assert.throws(()=>collectCupCountValuesV34({c10:-1,c16:1,c22p:1,c22d:1,c22o:1}),/CUP_COUNT_INVALID/);\n  const out=collectCupCountValuesV34({c10:1,c16:2,c22p:3,c22d:4,c22o:5});assert.equal(out.c22o,5);",
        "  assert.throws(()=>collectCupCountValuesV34({c10:'',c10p:1,c16:1,c22p:1,c22d:1,c22o:1}),/CUP_COUNT_REQUIRED/);\n  assert.throws(()=>collectCupCountValuesV34({c10:-1,c10p:1,c16:1,c22p:1,c22d:1,c22o:1}),/CUP_COUNT_INVALID/);\n  const out=collectCupCountValuesV34({c10:1,c10p:6,c16:2,c22p:3,c22d:4,c22o:5});assert.equal(out.c22o,5);assert.equal(out.c10p,6);",
    )

    replace_exact(
        root,
        "tests/v34-p5-batch2-final-qa-hardening.test.mjs",
        "test('P5 Batch-2 Final QA validates five-cup initial setup and requires WAC when opening stock exists',()=>{",
        "test('LEGACY-CUP-01A Final QA validates six-cup initial setup and requires WAC when opening stock exists',()=>{",
    )
    replace_exact(root, "tests/v34-p5-batch2-final-qa-hardening.test.mjs", "  assert.equal(Object.keys(out).length,5);", "  assert.equal(Object.keys(out).length,6);")
    replace_exact(root, "tests/v34-p5-batch2-final-qa-hardening.test.mjs", "  assert.equal(rows.length,5);", "  assert.equal(rows.length,6);")
    replace_exact(root, "tests/v34-p5-batch2-final-qa-hardening.test.mjs", "  assert.equal(plan.rows.length,5);", "  assert.equal(plan.rows.length,6);")

    # --- Postconditions: fail closed if intended contract was not achieved ---
    require(root, "src/domain/packaging-cup-v34.js", "code:'c10p'", 1)
    require(root, "src/domain/packaging-cup-v34.js", "name:'Cup Paper 10 Oz'", 1)
    require(root, "src/domain/packaging-cup-v34.js", "saleMapping:false", 1)
    require(root, "src/ui/cup-product-costing-v34.js", "filter(x=>x.saleMapping!==false)", 1)
    require(root, "src/ui/cup-shift-control-v34.js", "CUP_CATALOG_V34.length")
    require(root, "src/ui/inventory-workspace-v32.js", "${CUP_CATALOG_V34.length} master cup siap", 1)
    require(root, "src/ui/inventory-workspace-v32.js", "untuk ${CUP_CATALOG_V34.length} jenis cup.", 1)
    forbid(root, "src/ui/cup-shift-control-v34.js", "Hitung semua 5 jenis cup")
    forbid(root, "src/ui/cup-shift-control-v34.js", "/5 master")
    forbid(root, "src/ui/inventory-workspace-v32.js", "5 master cup siap")
    forbid(root, "src/ui/inventory-workspace-v32.js", "untuk lima jenis cup.")

    print("LEGACY-CUP-01A exact transform: PASS")


if __name__ == "__main__":
    main()
