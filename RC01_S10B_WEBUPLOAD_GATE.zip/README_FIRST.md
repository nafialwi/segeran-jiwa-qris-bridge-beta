# RC01-S10B Web Upload Gate

Purpose: move the locally verified RC01-S10B Firebase pending-write traceability correction into the existing GitHub RC branch using the established GitHub-web-upload + Codespaces workflow, while keeping `main`, Cloudflare Production, Firebase Rules, and production v2.9 untouched.

Expected branch: `rc01-v3.4-release-candidate`
Expected parent authority: exact S10A.2 Git tree `0b30cc94b2b6f9e1a3c51487ed2aa1251d10230d` (1365 files), deployed in Cloudflare Preview under commit prefix `12c8ef4`.
Expected final S10B tree: `2ac58c3e325a86f8d2e5869f3544b760c1f3f0cc` (1377 files).
Expected tests: 477/477 PASS.
Expected runtime HTML SHA256: `986329e5cba5faf56bd54deebbec99bbd5f876b93e4bc62749140b0068b2fb4a`.
Expected S10B tracer SHA256: `ebc385587a8a5c77d03fededd1bdb75b478dc2522e01c6b872d6d3f9f16a1ba2`.

Upload this package only to `rc01-v3.4-release-candidate`, never to `main`.
After upload commit, extract this gate outside the repository (for example `/tmp/rc01-s10b-gate`) and run `01_PREPARE_S10B_FROM_WEBUPLOAD.sh`.
The preparation script verifies the helper commit, parent tree, package checksum, runs full S10B verification, restores the exact locally verified source tree, creates one local RC commit, and STOPS before push.
