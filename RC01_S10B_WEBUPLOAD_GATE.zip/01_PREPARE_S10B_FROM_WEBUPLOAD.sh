#!/usr/bin/env bash
set -euo pipefail
stop(){ echo "STOP: $*" >&2; exit 1; }
EXPECTED_BRANCH='rc01-v3.4-release-candidate'
EXPECTED_PARENT_TREE='0b30cc94b2b6f9e1a3c51487ed2aa1251d10230d'
EXPECTED_FINAL_TREE='2ac58c3e325a86f8d2e5869f3544b760c1f3f0cc'
EXPECTED_FINAL_FILES='1377'
EXPECTED_RUNTIME='986329e5cba5faf56bd54deebbec99bbd5f876b93e4bc62749140b0068b2fb4a'
EXPECTED_TRACE='ebc385587a8a5c77d03fededd1bdb75b478dc2522e01c6b872d6d3f9f16a1ba2'
HELPER='RC01_S10B_WEBUPLOAD_GATE.zip'
GATE_DIR="$(cd "$(dirname "$0")" && pwd -P)"
REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || stop 'not inside Git repository'
cd "$REPO"
[[ "$(git branch --show-current)" == "$EXPECTED_BRANCH" ]] || stop "wrong branch: $(git branch --show-current)"
REMOTE="$(git remote get-url origin 2>/dev/null || true)"
[[ "$REMOTE" == *'nafialwi/segeran-jiwa-qris-bridge-beta'* ]] || stop "unexpected origin: $REMOTE"
[[ -z "$(git status --porcelain)" ]] || stop 'working tree must be clean before prepare'
HEAD_SHA="$(git rev-parse HEAD)"
PARENT_SHA="$(git rev-parse HEAD^)"
PARENT_TREE="$(git rev-parse "${PARENT_SHA}^{tree}")"
[[ "$PARENT_TREE" == "$EXPECTED_PARENT_TREE" ]] || stop "parent tree drift: $PARENT_TREE"
DIFF="$(git diff --name-status "$PARENT_SHA" "$HEAD_SHA")"
[[ "$DIFF" == $'A\t'"$HELPER" ]] || stop "helper upload commit must contain exactly one added file; got: $DIFF"
[[ -f "$HELPER" ]] || stop "helper package missing from repository root: $HELPER"
(
  cd "$GATE_DIR"
  sha256sum -c checksums/PACKAGE_SHA256SUMS.txt
) || stop 'gate package checksum failure'
TMP="$(mktemp -d /tmp/rc01-s10b-XXXXXX)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/source"
unzip -q "$GATE_DIR/payload/RC01_S10B_SOURCE.zip" -d "$TMP/source"
COUNT="$(find "$TMP/source" -type f | wc -l | tr -d ' ')"
[[ "$COUNT" == "$EXPECTED_FINAL_FILES" ]] || stop "source file count drift: $COUNT"
[[ "$(sha256sum "$TMP/source/src/compat/rc01-firebase-pending-write-trace.js" | awk '{print $1}')" == "$EXPECTED_TRACE" ]] || stop 'S10B tracer hash drift in payload'

# Replace helper-commit tree with exact locally verified source payload.
find . -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$TMP/source"/. .

echo '=== RC01-S10B FULL VERIFICATION ==='
npm run verify:rc01:s10b | tee "$TMP/verify.log"
grep -q '# tests 477' "$TMP/verify.log" || stop 'expected 477 tests not observed'
grep -q '# pass 477' "$TMP/verify.log" || stop 'expected 477 passing tests not observed'
grep -q '# fail 0' "$TMP/verify.log" || stop 'test failure detected'
grep -q 'RC01-S10B verification PASS' "$TMP/verify.log" || stop 'S10B verifier PASS missing'
[[ "$(sha256sum dist-rc01/index.html | awk '{print $1}')" == "$EXPECTED_RUNTIME" ]] || stop 'runtime hash mismatch after verification'

# Verification regenerates timestamped audit evidence. Restore the exact verified payload
# so the local commit has the same source tree as the reviewed S10B authority.
find . -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$TMP/source"/. .
git add -A
TREE="$(git write-tree)"
[[ "$TREE" == "$EXPECTED_FINAL_TREE" ]] || stop "final staged tree drift: $TREE"
git commit -m 'chore(sync): trace pending firebase writes'
[[ -z "$(git status --porcelain)" ]] || stop 'working tree not clean after local S10B commit'
FINAL_COMMIT="$(git rev-parse HEAD)"

cat <<SUMMARY
============================================================
RC01-S10B WEB-UPLOAD CODESPACE PREPARE: PASS
branch=$EXPECTED_BRANCH
parent_tree=$PARENT_TREE
s10b_commit=$FINAL_COMMIT
final_tree=$TREE
files=$EXPECTED_FINAL_FILES
tests=477/477 PASS
rc_verifier=PASS
s10a_verifier=PASS
s10a1_verifier=PASS
s10a2_verifier=PASS
s10b_verifier=PASS
runtime_sha256=$EXPECTED_RUNTIME
trace_sha256=$EXPECTED_TRACE
mutation_allowlist=4/4
main_pushed=NO
s10b_final_push=NO
cloudflare_production_mutated=NO
firebase_rules_root_mutated=NO
NEXT=STOP and send this summary to ChatGPT before push
============================================================
SUMMARY
