# RC01-S10A.1 GitHub Web-Upload Gate

Purpose: move the locally verified S10A.1 QRIS late-event/sync correction into the existing GitHub RC branch using the established GitHub-web-upload + Codespaces workflow while keeping `main` and Cloudflare Production untouched.

Expected branch: `rc01-v3.4-release-candidate`
Expected remote S10A Preview parent: commit prefix `6203a8c` AND exact S10A base-tree checksum manifest.
Expected main authority: `0d396829ad2ebb4ba0688e4c9b4aa2eccd2b8fb1`
Expected tests: 464/464 PASS.
Expected S10A.1 runtime SHA256: `296feef99052aa35409c93513239c72ae1ad728f2082116cd53b97284d1b7c57`.

The preparation script removes this helper ZIP from the final tree, verifies the exact S10A parent tree, overlays the exact verified S10A.1 payload, runs full verification, proves the exact tree, creates one local RC-branch commit, and STOPS before push.

Do not upload this package to `main`.
