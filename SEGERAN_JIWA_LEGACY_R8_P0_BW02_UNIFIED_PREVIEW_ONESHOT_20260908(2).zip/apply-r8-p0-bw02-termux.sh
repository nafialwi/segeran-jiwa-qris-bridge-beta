#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "$0")" && pwd -P)"
REPO="${1:-$PWD}"
BASE_BRANCH="main"
TARGET_BRANCH="r8-p0-bw02-preview"
LOG="$HOME/.sj-r8-p0-bw02-apply-verify.log"
MANIFEST="$PKG_DIR/manifest.tsv"

fail(){ echo; echo "HARD STOP: $*" >&2; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }

[ -d "$REPO" ] || fail "folder repo tidak ditemukan: $REPO"
git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || fail "bukan Git repo: $REPO"
cd "$REPO"
[ -z "$(git status --porcelain)" ] || fail "worktree tidak bersih; commit/stash perubahan dahulu"
[ -n "$(git config user.name || true)" ] || fail "git user.name belum disetel"
[ -n "$(git config user.email || true)" ] || fail "git user.email belum disetel"
[ -f "$MANIFEST" ] || fail "manifest.tsv tidak ditemukan"

if [ "${SJ_BW02_PACKAGE_QA:-0}" != "1" ]; then
  echo "=== SYNC MAIN ==="
  git switch "$BASE_BRANCH"
  git fetch origin "$BASE_BRANCH"
  git pull --ff-only origin "$BASE_BRANCH"
else
  git switch "$BASE_BRANCH"
fi

[ "$(git branch --show-current)" = "$BASE_BRANCH" ] || fail "harus mulai dari branch main"
[ -z "$(git status --porcelain)" ] || fail "main tidak bersih setelah sync"

BASE_COMMIT="$(git rev-parse HEAD)"
echo "=== R8 + P0-BW02 PREFLIGHT ==="
echo "Repo : $REPO"
echo "HEAD : $(git rev-parse --short HEAD)"
echo "Base : R7 FINAL source-hash guarded"

[ "$(sha baseline/legacy-v1.0.40.html)" = "877dd5d80ad3cfbae9c8ded35ea37c426bf795392240adb96c38e62fc556154f" ] || fail "frozen baseline HTML mismatch"
while IFS=$'\t' read -r action path base_sha final_sha; do
  [ -n "$path" ] || continue
  case "$action" in
    M)
      [ -f "$path" ] || fail "baseline file hilang: $path"
      [ "$(sha "$path")" = "$base_sha" ] || fail "R7 base hash mismatch: $path"
      ;;
    A)
      [ ! -e "$path" ] || fail "payload path sudah ada sebelum apply: $path"
      ;;
    *) fail "manifest action tidak didukung: $action $path" ;;
  esac
done < "$MANIFEST"
echo "BASELINE HASH GUARD PASS"

declare -A FROZEN=(
  ["src/app/rc01-runtime-loading-hardening.js"]="a6ee7844e884276a1f2f21a0792a3d4dd9784b18ac47fb5ce5807e6ece3a7f44"
  ["src/app/qris-deferred-settlement-bootstrap.js"]="9aaa068a38a4644df11d2aa15132f7363c16c205e082f91b77a9eada208e0496"
  ["src/compat/rc01-qris-deferred-settlement-compat.js"]="d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355"
  ["src/compat/rc01-qris-manual-bypass.js"]="80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156"
  ["src/compat/rc01-qris-evaluation-convergence.js"]="925f03e19db85327a1faf0b9c7473101ea045dcc85d2080e3afb6ba82b2848db"
  ["src/compat/rc01-sync-authority.js"]="a6c43e32f06f49ccce3bcabb74b710c116fde96ebf47b5db8cf0bcb1ab7d96d4"
  ["src/compat/rc01-sales-render-recursion-hardening.js"]="3b04b236d393b967f774b937cfb5c9207ca69045d2b596f7fa46c409d210cbad"
  ["emergency-d1/schema.sql"]="627a5daa62c593ec5de29c50b50dd43538acc260f77e494ea45e177fb01fc44b"
  ["emergency-d1/src/core.js"]="8523f65e64ec371c4aaaf1321c6decadc60cdca7e02c5d2750d682e3044c56ad"
  ["emergency-d1/src/worker.js"]="2ad8f41b6910b8fb37d284fea656dc7e8a359630a6f9c865c0ce9321920ef917"
)
for path in "${!FROZEN[@]}"; do
  [ -f "$path" ] || fail "frozen authority hilang: $path"
  [ "$(sha "$path")" = "${FROZEN[$path]}" ] || fail "frozen authority berubah sebelum apply: $path"
done
echo "FROZEN AUTHORITY PRE-GUARD PASS"

if git show-ref --verify --quiet "refs/heads/$TARGET_BRANCH"; then
  fail "branch lokal $TARGET_BRANCH sudah ada; jangan overwrite otomatis"
fi
git switch -c "$TARGET_BRANCH"

echo "=== APPLY R8 + P0-BW02 PAYLOAD ==="
python3 - "$PKG_DIR" "$REPO" <<'PY'
from pathlib import Path
import sys,shutil,hashlib
pkg=Path(sys.argv[1]); repo=Path(sys.argv[2])
for line in (pkg/'manifest.tsv').read_text().splitlines():
    if not line.strip(): continue
    action,path,base_sha,final_sha=line.split('\t')
    src=pkg/'payload'/path; dst=repo/path
    if not src.is_file(): raise SystemExit(f'payload missing: {path}')
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    if hashlib.sha256(dst.read_bytes()).hexdigest()!=final_sha:
        raise SystemExit(f'payload hash mismatch after copy: {path}')
print('PAYLOAD COPY PASS')
PY

git diff --check

echo "=== FULL VERIFICATION ==="
: > "$LOG"
{
  echo "R8 + P0-BW02 verify started $(date -u +%FT%TZ)"
  npm run audit
  npm run build
  npm run build:sc03
  npm run build:sc04
  rm -f dist-ref01/.ref01-build-fingerprint
  npm run build:ref01
  npm run build:rc01
  node scripts/verify-inline-scripts.mjs
  npm run contracts
  node scripts/verify-sc02.mjs
  node scripts/verify-sc03.mjs
  node scripts/verify-sc04.mjs
  node scripts/verify-ref01.mjs
  node scripts/verify-rc01-s10c-r6d.mjs
  node --test --test-concurrency=1 tests/*.test.mjs
  git diff --check

  echo "=== D1 SHADOW SQLITE SANITY ==="
  node - <<'NODE'
import {buildShadowArtifacts} from './migration/cloudflare-d1/import-firebase-backup.mjs';
const image='data:image/png;base64,aGVsbG8=';
await buildShadowArtifacts({global:{menu:[{id:'p1',n:'TEST',p:1000,img:image}]},'2026-09-08-S1':{tx:{'SJ-QA':{id:'SJ-QA',total:1000,cartData:[{id:'p1',n:'TEST',q:1,p:1000,img:image}]}}}},{outputDir:'/tmp/sj-bw02-package-shadow',sourceName:'package-qa'});
NODE
  python3 - <<'PY'
import sqlite3
from pathlib import Path
conn=sqlite3.connect(':memory:')
conn.executescript(Path('migration/cloudflare-d1/schema_v1.sql').read_text())
conn.executescript(Path('/tmp/sj-bw02-package-shadow/shadow_import.sql').read_text())
assert conn.execute('select count(*) from sj_transactions').fetchone()[0] == 1
assert conn.execute('select count(*) from sj_media_objects').fetchone()[0] == 1
print('D1 SHADOW SQLITE PASS')
PY
} 2>&1 | tee -a "$LOG"

# Build/audit outputs are verifier artifacts, not source payload.
git restore -- audit dist dist-rc01 dist-ref01 dist-sc03 dist-sc04 2>/dev/null || true
git clean -fd -- audit dist dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true

while IFS=$'\t' read -r action path base_sha final_sha; do
  [ -n "$path" ] || continue
  [ -f "$path" ] || fail "final payload file hilang: $path"
  [ "$(sha "$path")" = "$final_sha" ] || fail "final payload hash mismatch: $path"
done < "$MANIFEST"
for path in "${!FROZEN[@]}"; do
  [ "$(sha "$path")" = "${FROZEN[$path]}" ] || fail "frozen authority berubah setelah verify: $path"
done
[ "$(sha baseline/legacy-v1.0.40.html)" = "877dd5d80ad3cfbae9c8ded35ea37c426bf795392240adb96c38e62fc556154f" ] || fail "baseline HTML berubah setelah verify"
echo "FINAL PAYLOAD + FROZEN HASH PASS"

git add -- $(cut -f2 "$MANIFEST")
git diff --cached --check
if git diff --cached --name-only | grep -E 'OWNER_KEY|TOKEN\.txt|auth-response\.json|\.dev\.vars|(^|/)\.env$'; then
  fail "private/secret file ter-stage"
fi
if git diff --cached | grep -Eq 'SJ-EMG-[A-F0-9]{12,}'; then
  fail "Owner Key-like secret terdeteksi di staged diff"
fi
echo "SECRET GUARD PASS"

git commit -m "perf: apply R8 and P0 BW02 bandwidth hardening"

if [ "${SJ_BW02_SKIP_PUSH:-0}" = "1" ]; then
  echo "=== PUSH SKIPPED ==="
else
  echo "=== PUSH PREVIEW BRANCH ==="
  if ! git push -u origin "$TARGET_BRANCH"; then
    echo
    echo "PUSH GAGAL, tetapi commit lokal aman. Jangan ulang apply dari awal."
    echo "Branch: $(git branch --show-current)"
    echo "Commit: $(git rev-parse --short HEAD)"
    exit 2
  fi
fi

# Ensure base branch pointer itself was never changed locally.
[ "$(git rev-parse "$BASE_BRANCH")" = "$BASE_COMMIT" ] || fail "pointer main berubah selama installer"

echo
echo "============================================================"
echo "R8 + P0-BW02 APPLY/VERIFY PASS"
echo "Branch : $(git branch --show-current)"
echo "Commit : $(git rev-parse --short HEAD)"
echo "Tests  : 611/611 serial PASS"
echo "SC02/SC03/SC04/REF01/R6D: PASS"
echo "D1 shadow SQLite sanity: PASS"
echo "Frozen authority: PASS"
echo "main/Production: BELUM DISENTUH"
echo "Log    : $LOG"
echo "NEXT   : Preview UAT + Firebase profiler; D1 remains shadow-only"
echo "============================================================"
