SEGERAN JIWA LEGACY — R8 + P0-BW02 UNIFIED PREVIEW PACKAGE
============================================================
Base required: exact R7 FINAL branch main.
Target: preview branch only. Production/main is not modified by this installer.

Included:
1. R8 operational refinement:
   - one payment success surface;
   - cashier Cup & Kemasan visibility;
   - physical restock receipt + variance evidence;
   - purchase correction route to existing reversal authority;
   - blind cash/cup closing and opening-cash continuity explanation.
2. P0-BW02 Firebase bandwidth stop-loss:
   - new transaction history no longer stores product Base64 images;
   - recipe/HPP sale costing uses the exact successful transaction ID instead of full-shift before/after reads;
   - refund costing uses direct/bounded transaction lookup;
   - recurring refund/costing business-data recovery polling is disabled and replaced with bounded login/event recovery.
3. Cloudflare D1/R2 shadow migration kit:
   - normalized schema;
   - Firebase backup -> D1 SQL converter;
   - Base64 media extraction/deduplication to an R2 manifest;
   - per-shift parity summary.

This package DOES NOT:
- migrate production data;
- switch reads/writes to D1;
- delete historical Firebase media;
- re-enable automatic QRIS;
- deploy to Production.

Termux/Codespaces usage after extracting:
  bash apply-r8-p0-bw02-termux.sh /path/to/segeran-jiwa-repo

The installer creates branch:
  r8-p0-bw02-preview

If a hash guard fails, stop. Do not bypass it.
