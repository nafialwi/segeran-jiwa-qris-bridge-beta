import { enhanceBottomNav } from '../ui/bottom-nav.js';
import { SCREEN_FAMILIES, IMPLICIT_CAPABILITIES } from '../ui/refinement-contract.js';
import { renderIcon } from '../ui/icons.js';
import { createMediaLifecycle } from '../ui/media-lifecycle.js';
import { createBrowserJsonStore } from '../data/local-store.js';
import { createStaleShiftAdapter, shiftPresentation } from '../ui/shift-refinement.js';
import { tagScreenContracts } from '../ui/screen-contracts.js';
import { renderSettingsMarkup } from '../ui/settings-refinement.js';
import { REFERENCE_MATRIX } from '../ui/refinement-visual-contract.js';
import { installRefinementIconAuthority } from '../ui/icon-authority.js';
import { installReportRefinement } from '../ui/report-refinement.js';
import { installNotificationRefinement } from '../ui/notification-refinement.js';
import { reconcileRoleNavigation } from '../ui/role-nav-refinement.js';
import { reconcileTransactionSurfaces } from '../ui/transaction-detail-refinement.js';
import { decorateCriticalOperationalSurfaces } from '../ui/critical-operational-refinement.js';
import { decorateStockReferenceSurface } from '../ui/stock-refinement.js';
import { installSalesShiftUxRefinement } from '../ui/sales-shift-ux-refinement.js';
import { installLegacyShiftCloseRecovery } from '../ui/legacy-shift-close-recovery.js';
import { installSalesHistoryRefinement } from '../ui/report-sales-history-refinement.js';
import { installFinishedGoodsWarehouseRefinement } from '../ui/finished-goods-warehouse-refinement.js';
import { installProductionSalesStability, installManualSyncControls } from '../ui/production-sales-stability.js';
import { createPresentationLifecycle } from '../ui/presentation-authority.js';
import { applyV31UxPolish } from '../ui/v31-ux-polish.js';
import { installOwnerDashboardHybrid } from '../ui/owner-dashboard-hybrid.js';
import { installInventoryWorkspaceV32 } from '../ui/inventory-workspace-v32.js';
import { installFinanceWorkspaceV33 } from '../ui/finance-v33-workspace.js';
import { installQrisCashOutUiV33 } from '../ui/qris-cash-out-ui.js';
import { installP5PackagingV34 } from './p5-packaging-bootstrap.js';
import { installR8DailyUxRefinement } from '../ui/r8-daily-ux-refinement.js';
import { installR8InventorySafetyRefinement } from '../ui/r8-inventory-safety-refinement.js';
import { installR8ShiftClosingIntegrity } from '../ui/r8-shift-closing-integrity.js';

const OWNER='ref01-ui-runtime';

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function notify(runtime,message,kind='info'){try{if(typeof runtime?.showToast==='function') return runtime.showToast(message,kind)}catch(_){}try{runtime?.console?.info?.(`[REF01/${kind}] ${message}`)}catch(_){} }
function getAuth(runtime){try{return runtime?.SJProductionArchitectureP3?.auth?.()??runtime?.firebase?.auth?.()??null}catch(_){return null}}
function getImageAuthority(runtime){return runtime?.SJProductionArchitectureP3??null}
function profileIdentity(runtime,sc04){
  try{const username=sc04?.session?.snapshot?.()?.envelope?.username;if(username)return String(username).trim().toLowerCase()}catch(_){}
  try{const uid=getAuth(runtime)?.currentUser?.uid;if(uid)return `uid-${String(uid)}`}catch(_){}
  return `name-${accountName(runtime).trim().toLowerCase()}`;
}
function profileAvatarStore(runtime,sc04){
  try{return createBrowserJsonStore({runtime,key:`segeran-jiwa.profile-avatar.v1.${encodeURIComponent(profileIdentity(runtime,sc04))}`})}catch(_){return null}
}

function installStyle(document){
  if(!document?.head||document.querySelector?.('link[data-sj-ref01-style="true"]')) return false;
  const link=document.createElement('link');link.rel='stylesheet';link.href='./src/ui/ref01.css';link.dataset.sjRef01Style='true';document.head.appendChild(link);return true;
}
function currentRoute(sc03){try{return sc03?.state?.snapshot?.().primary||'home'}catch(_){return'home'}}

function localQaEffectiveSettings(runtime,role){
  try{
    if(runtime?.__SJ_LOCAL_QA_READ_ONLY!==true)return null;
    const full=runtime?.__SJ_LOCAL_QA_UI_SETTINGS;if(!full||typeof full!=='object')return null;
    const key=role==='cashier'||role==='transaksi'?'transaksi':'manajemen';
    const scoped=full?.roleLayouts?.[key]||{};
    return Object.assign({},scoped,{
      managementColumns:full.managementColumns,
      productMasterColumns:full.productMasterColumns,
      longPressEdit:full.longPressEdit
    });
  }catch(_){return null}
}

export function reconcileLayoutPreferences(document,runtime,{role=null}={}){
  const root=document?.documentElement;if(!root)return Object.freeze({});
  let settings={};
  try{
    settings=localQaEffectiveSettings(runtime,role)
      ||runtime?.SJMobileProfessionalP1?.effective?.()
      ||runtime?.SJAppMintBaseV5963?.settings?.()
      ||runtime?.SJMobileUX?.settings?.()
      ||{};
  }catch(_){settings={}}
  const num=(value,allowed,fallback)=>allowed.includes(Number(value))?Number(value):fallback;
  const normalized=Object.freeze({
    productColumns:num(settings.productColumns,[2,3,4],3),
    operationColumns:num(settings.operationColumns,[1,2,3],2),
    reportColumns:num(settings.reportColumns,[1,2,3],2),
    managementColumns:num(settings.managementColumns,[1,2,3],2),
    productMasterColumns:num(settings.productMasterColumns,[2,3],2),
    compactCards:settings.compactCards===true
  });
  root.dataset.sjProductCols=String(normalized.productColumns);
  root.dataset.sjOperationCols=String(normalized.operationColumns);
  root.dataset.sjReportCols=String(normalized.reportColumns);
  root.dataset.sjManagementCols=String(normalized.managementColumns);
  root.dataset.sjMasterCols=String(normalized.productMasterColumns);
  root.dataset.sjCompact=normalized.compactCards?'1':'0';
  return normalized;
}
function currentRole(sc03){try{return sc03?.guard?.currentRole?.()||null}catch(_){return null}}

export function applyV31SurfaceGrammar(document){
  const root=document?.documentElement;if(!root)return Object.freeze({applied:false,surfaces:0,headers:0});
  root.dataset.sjV31='true';
  document?.body?.classList?.add?.('sj-v31-runtime');
  const surfaces=Array.from(document?.querySelectorAll?.('.sjvc01-sales,.sjvc02-page,.sjr01-settings-page,.sjv29-report-page,.sj-ref-report-semantic')||[]);
  for(const node of surfaces)try{node.dataset.sjV31Surface='true'}catch(_){}
  const headers=Array.from(document?.querySelectorAll?.('.sjvc01-saleshead,.sjvc02-head,.sjr01-settings-header,.sjv29-report-head')||[]);
  for(const node of headers)try{node.classList?.add?.('sj-v31-page-head')}catch(_){}
  return Object.freeze({applied:true,surfaces:surfaces.length,headers:headers.length});
}

const OPERATIONAL_AUTHORITY_MARK='__sjV30OperationalPresentationAuthority';
export function installOperationalPresentationAuthority(runtime=globalThis,{reconcile=()=>{}}={}){
  const target=runtime?.SJFinalRefinementVC02A;
  const originalRender=target?.renderOperations;
  const originals=[];
  const timer=typeof runtime?.setTimeout==='function'?runtime.setTimeout.bind(runtime):setTimeout;
  const post=reason=>timer(()=>{try{reconcile(reason)}catch(_){}},0);
  let installed=false;
  if(target&&typeof originalRender==='function'&&!originalRender?.[OPERATIONAL_AUTHORITY_MARK]){
    function wrappedRender(...args){const out=originalRender.apply(this,args);reconcile('late-operational-render');return out}
    try{Object.defineProperty(wrappedRender,OPERATIONAL_AUTHORITY_MARK,{value:true,enumerable:false})}catch(_){wrappedRender[OPERATIONAL_AUTHORITY_MARK]=true}
    target.renderOperations=wrappedRender;originals.push(['renderOperations',target,originalRender,wrappedRender]);installed=true;
  }else if(originalRender?.[OPERATIONAL_AUTHORITY_MARK])installed=true;
  const wrapRuntime=(name,reason,when=()=>true)=>{
    const original=runtime?.[name];if(typeof original!=='function'||original?.[OPERATIONAL_AUTHORITY_MARK])return false;
    function wrapped(...args){const out=original.apply(this,args);if(when(args))post(reason);return out}
    try{Object.defineProperty(wrapped,OPERATIONAL_AUTHORITY_MARK,{value:true,enumerable:false})}catch(_){wrapped[OPERATIONAL_AUTHORITY_MARK]=true}
    runtime[name]=wrapped;originals.push([name,runtime,original,wrapped]);return true;
  };
  installed=wrapRuntime('showView','post-operational-route',args=>Number(args?.[0])===2)||installed;
  installed=wrapRuntime('closeOpr','post-operational-close')||installed;
  post('operational-install');
  return Object.freeze({
    installed,
    stop(){for(const [name,host,original,wrapped] of originals.splice(0))try{if(host?.[name]===wrapped)host[name]=original}catch(_){}}
  });
}

const LOCAL_QA_LAYOUT_MARK='__sjV30LocalQaLayoutAuthority';
export function installLocalQaLayoutAuthority(runtime=globalThis,{role=()=>null,onChanged=()=>{}}={}){
  if(runtime?.__SJ_LOCAL_QA_READ_ONLY!==true)return Object.freeze({installed:false,stop(){}});
  const mobile=runtime?.SJMobileUX;const original=mobile?.saveSettings;
  if(!mobile||typeof original!=='function')return Object.freeze({installed:false,stop(){}});
  if(original?.[LOCAL_QA_LAYOUT_MARK])return Object.freeze({installed:true,stop(){}});
  async function wrapped(...args){
    try{const selected=mobile.collectSettings?.();if(selected&&typeof selected==='object')runtime.__SJ_LOCAL_QA_UI_SETTINGS=JSON.parse(JSON.stringify(selected))}catch(_){}
    const out=await original.apply(this,args);
    try{onChanged('local-qa-layout-save',role())}catch(_){}
    return out;
  }
  try{Object.defineProperty(wrapped,LOCAL_QA_LAYOUT_MARK,{value:true,enumerable:false})}catch(_){wrapped[LOCAL_QA_LAYOUT_MARK]=true}
  mobile.saveSettings=wrapped;
  return Object.freeze({installed:true,stop(){try{if(mobile.saveSettings===wrapped)mobile.saveSettings=original}catch(_){}}});
}


const SALES_GRID_AUTHORITY_MARK='__sjV30SalesGridPresentationAuthority';
export function applySalesGridLayout(document,columns){
  const n=[2,3,4].includes(Number(columns))?Number(columns):3;
  const gap=n===4?'5px':n===3?'8px':'9px';
  const grids=Array.from(document?.querySelectorAll?.('.sjvc01-grid,.sjui03a-grid')||[]);
  for(const grid of grids){
    if(!grid?.style)continue;
    grid.style.gridTemplateColumns=`repeat(${n},minmax(0,1fr))`;
    grid.style.gap=gap;
    if(grid.dataset)grid.dataset.sjEffectiveProductCols=String(n);
  }
  return grids.length;
}
export function installSalesGridPresentationAuthority(runtime=globalThis,{document=runtime?.document,getColumns=()=>Number(document?.documentElement?.dataset?.sjProductCols||3)}={}){
  const target=runtime?.SJRefinementSalesV100;
  const original=target?.renderSales;
  if(!target||typeof original!=='function')return Object.freeze({installed:false,apply:()=>applySalesGridLayout(document,getColumns()),stop(){}});
  if(original?.[SALES_GRID_AUTHORITY_MARK])return Object.freeze({installed:true,apply:()=>applySalesGridLayout(document,getColumns()),stop(){}});
  function wrapped(...args){
    const out=original.apply(this,args);
    applySalesGridLayout(document,getColumns());
    return out;
  }
  try{Object.defineProperty(wrapped,SALES_GRID_AUTHORITY_MARK,{value:true,enumerable:false})}catch(_){wrapped[SALES_GRID_AUTHORITY_MARK]=true}
  target.renderSales=wrapped;
  applySalesGridLayout(document,getColumns());
  return Object.freeze({
    installed:true,
    apply:()=>applySalesGridLayout(document,getColumns()),
    stop(){try{if(target.renderSales===wrapped)target.renderSales=original}catch(_){}}
  });
}

const SETTINGS_AUTHORITY_MARK='__sjV30SettingsPresentationAuthority';
export function installSettingsPresentationAuthority(runtime=globalThis,{reconcile=()=>{}}={}){
  const target=runtime?.SJRefinementPass3V5960;
  const original=target?.renderManagementMenu;
  if(!target||typeof original!=='function')return Object.freeze({installed:false,stop(){}});
  if(original?.[SETTINGS_AUTHORITY_MARK])return Object.freeze({installed:true,stop(){}});
  function wrapped(...args){
    const out=original.apply(this,args);
    reconcile('late-management-render');
    return out;
  }
  try{Object.defineProperty(wrapped,SETTINGS_AUTHORITY_MARK,{value:true,enumerable:false})}catch(_){wrapped[SETTINGS_AUTHORITY_MARK]=true}
  target.renderManagementMenu=wrapped;
  return Object.freeze({
    installed:true,
    stop(){try{if(target.renderManagementMenu===wrapped)target.renderManagementMenu=original}catch(_){}}
  });
}

function accountName(runtime){
  try{const value=runtime?.SJAccountV5964?.displayName?.();if(value)return String(value)}catch(_){}
  return String(getAuth(runtime)?.currentUser?.displayName||runtime?.currentUserName||'Owner Utama');
}
function syncLabel(runtime){
  try{if(runtime?.SJProductionArchitectureP3?.serverConnected===false||runtime?.navigator?.onLine===false)return 'Menunggu koneksi'}catch(_){}
  try{return new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'Asia/Jakarta'}).format(new Date())}catch(_){return 'Hari ini'}
}
function renderSettingsLanding(document,runtime,sc03,media,openFeature,{force=false}={}){
  const root=document?.getElementById?.('mst-menu-view');if(!root||currentRole(sc03)!=='owner') return false;
  if(root.dataset?.ref01Settings==='true'&&!force&&root.querySelector?.('.sjr01-settings-page')) return false;
  const photo=media.currentPhoto();
  const online=runtime?.navigator?.onLine!==false&&runtime?.SJProductionArchitectureP3?.serverConnected!==false;
  root.dataset.ref01Settings='true';
  root.innerHTML=renderSettingsMarkup({name:accountName(runtime),roleLabel:'Owner / Pemilik',photoURL:photo,synced:online,syncLabel:online?`Hari ini ${syncLabel(runtime)}`:'Menunggu koneksi'});
  if(root.dataset.ref01Events!=='true'){
    root.dataset.ref01Events='true';
    root.addEventListener?.('click',event=>{
      const photoTarget=event.target?.closest?.('[data-ref01-profile]');
      if(photoTarget){
        event.preventDefault?.();
        if(photoTarget.dataset?.ref01Profile==='remove'){
          media.removeProfilePhoto().then(()=>{renderSettingsLanding(document,runtime,sc03,media,openFeature,{force:true});enhanceProfileAvatars(document,runtime,media);notify(runtime,'Foto profil dihapus.','success')}).catch(e=>notify(runtime,e.message||'Gagal menghapus foto profil.','error'));
        }else document.getElementById('sj-ref-profile-file')?.click?.();
        return;
      }
      const featureTarget=event.target?.closest?.('[data-ref01-feature]');
      if(featureTarget){event.preventDefault?.();openFeature(featureTarget.dataset.ref01Feature)}
    });
  }
  const input=document.getElementById?.('sj-ref-profile-file');
  if(input&&input.dataset?.ref01Bound!=='true'){
    input.dataset.ref01Bound='true';
    input.addEventListener?.('change',async event=>{
      const file=event.target.files?.[0];if(!file)return;
      try{await media.saveProfilePhoto(file);renderSettingsLanding(document,runtime,sc03,media,openFeature,{force:true});enhanceProfileAvatars(document,runtime,media);notify(runtime,'Foto profil diperbarui.','success')}
      catch(e){notify(runtime,e.message||'Gagal memperbarui foto profil.','error')}
    });
  }
  return true;
}
function openAvatarActions(document,runtime,media,onChanged){
  let panel=document?.getElementById?.('sj-ref-avatar-actions');
  if(!panel){
    panel=document?.createElement?.('div');if(!panel)return false;
    panel.id='sj-ref-avatar-actions';panel.className='overlay';
    panel.innerHTML=`<div class="modal sj-ref-avatar-modal"><div class="modal-title">Foto Profil</div><p>Gunakan foto akun saat ini atau kembali ke inisial.</p><div class="sj-ref-media-actions"><button type="button" data-ref01-avatar-action="upload">Upload / Ganti Foto</button><button type="button" data-ref01-avatar-action="initials">Gunakan Inisial</button><button type="button" data-ref01-avatar-action="close">Batal</button></div><input id="sj-ref-avatar-file" type="file" accept="image/*" hidden></div>`;
    document.body?.appendChild?.(panel);
    const input=panel.querySelector?.('#sj-ref-avatar-file');
    panel.addEventListener?.('click',event=>{
      const action=event.target?.dataset?.ref01AvatarAction;
      if(action==='upload') input?.click?.();
      if(action==='initials') media.removeProfilePhoto().then(()=>{panel.style.display='none';onChanged?.();notify(runtime,'Foto profil dihapus. Inisial digunakan.','success')}).catch(e=>notify(runtime,e.message||'Gagal menghapus foto profil.','error'));
      if(action==='close'||event.target===panel) panel.style.display='none';
    });
    input?.addEventListener?.('change',async event=>{const file=event.target.files?.[0];if(!file)return;try{await media.saveProfilePhoto(file);panel.style.display='none';onChanged?.();notify(runtime,'Foto profil diperbarui.','success')}catch(e){notify(runtime,e.message||'Gagal memperbarui foto profil.','error')}finally{event.target.value=''}});
  }
  panel.style.display='flex';return true;
}
function enhanceProfileAvatars(document,runtime,media){
  const photo=media.currentPhoto();
  const nodes=Array.from(document?.querySelectorAll?.('.sjvc01-avatar,.sjui02-avatar,.sj5964-avatar')||[]);
  let changed=0;
  for(const node of nodes){
    if(!node)continue;
    if(photo&&node.dataset?.ref01Photo!==photo){node.dataset.ref01Photo=photo;node.innerHTML=`<img src="${esc(photo)}" alt="Foto profil ${esc(accountName(runtime))}">`;changed++}
    else if(!photo&&node.dataset?.ref01Photo){delete node.dataset.ref01Photo;node.innerHTML=esc(accountName(runtime).trim().split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase()||'U');changed++}
    if(node.dataset?.ref01AvatarBound!=='true'){
      node.dataset.ref01AvatarBound='true';node.setAttribute?.('role','button');node.setAttribute?.('tabindex','0');node.setAttribute?.('aria-label','Ubah foto profil');
      const open=e=>{e?.preventDefault?.();e?.stopPropagation?.();openAvatarActions(document,runtime,media,()=>enhanceProfileAvatars(document,runtime,media))};
      node.addEventListener?.('click',open);node.addEventListener?.('keydown',e=>{if(e?.key==='Enter'||e?.key===' '){e.preventDefault?.();open(e)}});changed++;
    }
  }
  const cashierProfiles=Array.from(document?.querySelectorAll?.('.sjvc01-cashier .sjvc01-profile,.sjui02-cashier .sjui02-profile')||[]);
  for(const profile of cashierProfiles){
    if(profile.dataset?.ref01Account==='true')continue;
    profile.dataset.ref01Account='true';profile.setAttribute?.('role','button');profile.setAttribute?.('tabindex','0');profile.setAttribute?.('aria-label','Akun Saya');
    const open=e=>{e?.preventDefault?.();runtime?.SJAccountV5964?.open?.()};
    profile.addEventListener?.('click',open);profile.addEventListener?.('keydown',e=>{if(e?.key==='Enter'||e?.key===' '){e.preventDefault?.();open(e)}});changed++;
  }
  return changed;
}
function renderInfoPanel(document,{title,message,rows=[],actions=[]}={}){
  let panel=document.getElementById?.('sj-ref-info-panel');if(!panel){panel=document.createElement?.('div');if(!panel)return false;panel.id='sj-ref-info-panel';panel.className='overlay';panel.innerHTML='<div class="modal"><div class="modal-title" id="sj-ref-info-title"></div><div id="sj-ref-info-body"></div><button type="button" class="btn-act" id="sj-ref-info-close">TUTUP</button></div>';document.body?.appendChild?.(panel);document.getElementById('sj-ref-info-close')?.addEventListener?.('click',()=>{panel.style.display='none'})}
  const t=document.getElementById('sj-ref-info-title'),body=document.getElementById('sj-ref-info-body');if(t)t.textContent=title||'Informasi';if(body){body.innerHTML=`<p style="font-size:11px;color:#66776d">${esc(message||'')}</p>${rows.map(r=>`<div style="padding:8px 0;border-bottom:1px solid #e5ebe7;font-size:10px"><b>${esc(r[0])}</b><span style="float:right">${esc(r[1])}</span></div>`).join('')}${actions.length?`<div class="sj-ref-media-actions">${actions.map((a,i)=>`<button type="button" data-ref01-info-action="${i}">${esc(a.label)}</button>`).join('')}</div>`:''}`;body.querySelectorAll?.('[data-ref01-info-action]')?.forEach?.(button=>button.addEventListener?.('click',()=>actions[Number(button.dataset.ref01InfoAction)]?.run?.()))}panel.style.display='flex';return true;
}
function installConnectivityBanner(document,runtime){
  const app=document?.getElementById?.('app-wrapper');if(!app)return false;let banner=document.getElementById?.('sj-ref-connectivity');if(!banner){banner=document.createElement('div');banner.id='sj-ref-connectivity';banner.className='sj-ref-connectivity';banner.innerHTML=`${renderIcon('activity',{size:17})}<span>Menghubungkan kembali… sesi Anda tetap tersimpan dan akan divalidasi saat Firebase kembali online.</span>`;app.insertBefore(banner,app.firstChild)}
  let disconnected=runtime?.navigator?.onLine===false;try{if(runtime?.SJProductionArchitectureP3&&runtime.SJProductionArchitectureP3.serverConnected===false)disconnected=true}catch(_){}banner.classList?.toggle?.('show',disconnected);return true;
}
function enhanceImageRemove(document){
  const targets=[['new-i','new-img-preview'],['edit-m-i','edit-img-preview'],['sjmux-q-img','sjmux-q-preview'],['set-logo-val','set-logo-preview'],['set-qris-val','set-qris-preview']];let count=0;
  for(const [hiddenId,previewId] of targets){const hidden=document?.getElementById?.(hiddenId);if(!hidden||hidden.dataset?.ref01Remove==='true')continue;hidden.dataset.ref01Remove='true';const preview=document.getElementById(previewId);const host=hidden.parentElement||preview?.parentElement;if(!host?.appendChild)continue;const wrap=document.createElement('div');wrap.className='sj-ref-media-actions';const button=document.createElement('button');button.type='button';button.textContent='Hapus foto';button.addEventListener('click',()=>{hidden.value='';if(preview){preview.src='';preview.style.display='none'}notify(globalThis,'Foto akan dihapus saat perubahan disimpan.','info')});wrap.appendChild(button);host.appendChild(wrap);count++}
  return count;
}
function enhanceScanner(document,sc03){
  const wrap=document?.querySelector?.('.sj-search-wrap');if(!wrap||document.getElementById?.('sj-ref-scan'))return false;const btn=document.createElement('button');btn.id='sj-ref-scan';btn.type='button';btn.className='sj-ref-scan-btn';btn.setAttribute('aria-label','Scan barcode atau SKU');btn.innerHTML=`${renderIcon('camera',{size:18})}<span>Scan</span>`;btn.addEventListener('click',()=>{const f=sc03?.features?.get?.('sales.barcode');if(f?.open)return f.open()});wrap.parentElement?.appendChild?.(btn);return true;
}
function enhanceTransferDraft(document){
  const modal=document?.querySelector?.('#modal-bayar .modal');if(!modal||document.getElementById?.('sj-ref-transfer-draft'))return false;const box=document.createElement('div');box.id='sj-ref-transfer-draft';box.className='sj-ref-transfer-draft';box.style.display='none';box.innerHTML=`<strong>Lampiran bukti transfer</strong><span>Opsional untuk pengecekan operator. REF-01 belum menyimpan lampiran ke transaksi sampai writer evidence existing tersedia.</span><div class="sj-ref-media-actions"><button type="button" data-ref01-transfer="choose">Pilih foto</button><button type="button" data-ref01-transfer="remove">Hapus</button></div><input id="sj-ref-transfer-file" type="file" accept="image/*" hidden><img id="sj-ref-transfer-preview" class="sj-ref-photo-draft-preview" alt="Preview bukti transfer">`;const payButton=modal.querySelector?.('.btn-pay[onclick="processTransaction()"]');modal.insertBefore?.(box,payButton||null);const input=box.querySelector?.('#sj-ref-transfer-file'),preview=box.querySelector?.('#sj-ref-transfer-preview');box.addEventListener?.('click',event=>{const action=event.target?.dataset?.ref01Transfer;if(action==='choose')input?.click?.();if(action==='remove'){if(input)input.value='';if(preview){preview.src='';preview.style.display='none'}}});input?.addEventListener?.('change',event=>{const file=event.target.files?.[0];if(!file||!String(file.type||'').startsWith('image/'))return;const reader=new FileReader();reader.onload=e=>{preview.src=String(e.target?.result||'');preview.style.display='block'};reader.readAsDataURL(file)});return true;
}
function syncTransferDraft(document){const box=document?.getElementById?.('sj-ref-transfer-draft'),tf=document?.getElementById?.('btn-tf');if(box)box.style.display=tf?.classList?.contains?.('active')?'block':'none'}
function tagSemanticScreens(document){
  tagScreenContracts(document);
  const report=document?.getElementById?.('view3');if(report){report.classList?.add?.('sj-ref-report-semantic');report.dataset.ref01Report='true'}
  const title=document?.getElementById?.('sjpro-page-title');if(title&&/manajemen/i.test(title.textContent||''))title.textContent='Pengaturan';
}
function addStaleShiftAction(document,shiftAdapter){
  const rows=Array.from(document?.querySelectorAll?.('[data-shift-key]')||[]);let changed=0;for(const row of rows){const key=row.dataset?.shiftKey;if(!key||row.querySelector?.('[data-ref01-stale]'))continue;const text=String(row.textContent||'').toLowerCase();if(!/aktif|open/.test(text))continue;let model=null;try{model=shiftPresentation({key,data:{shiftStatus:'ACTIVE'},now:new Date()})}catch(_){continue}if(!model.overdue)continue;const box=document.createElement('div');box.className='sj-ref-overdue';box.dataset.ref01Stale='true';box.innerHTML=`<b>Shift lama masih terbuka</b><span>${esc(key)} · Rekonsiliasi perlu diselesaikan Owner.</span><button type="button">Buka Closing</button>`;box.querySelector('button')?.addEventListener('click',event=>{event.stopPropagation?.();shiftAdapter.openClosing(key)});row.insertAdjacentElement?.('afterend',box);changed++}return changed;
}

export function installRef01Runtime(runtime=globalThis,{sc03=runtime?.__SJ_SC03_RUNTIME,sc04=runtime?.__SJ_SC04_RUNTIME,p4=runtime?.__SJ_P4_FINANCE_RUNTIME,observe=false}={}){
  if(runtime?.__SJ_REF01_RUNTIME) return runtime.__SJ_REF01_RUNTIME;
  if(!sc03) throw new Error('REF01_SC03_RUNTIME_REQUIRED');if(!sc04) throw new Error('REF01_SC04_RUNTIME_REQUIRED');
  const document=runtime?.document??null;installStyle(document);installRefinementIconAuthority(runtime);installReportRefinement(runtime);const notificationRefinement=installNotificationRefinement(runtime);
  const media=createMediaLifecycle({imageAuthority:getImageAuthority(runtime),auth:getAuth(runtime),avatarStore:profileAvatarStore(runtime,sc04)});const shift=createStaleShiftAdapter(runtime);const legacyShiftClose=installLegacyShiftCloseRecovery(runtime);const salesShiftUx=installSalesShiftUxRefinement(runtime,{shiftAdapter:shift});const ownerDashboardHybrid=installOwnerDashboardHybrid(runtime);const productionSales=installProductionSalesStability(runtime);const manualSync=installManualSyncControls(runtime);const salesHistory=installSalesHistoryRefinement(runtime);const finishedWarehouse=installFinishedGoodsWarehouseRefinement(runtime);let inventoryWorkspace=installInventoryWorkspaceV32(runtime);
  const p5Packaging=installP5PackagingV34(runtime,{inventoryWorkspace});
  const financeWorkspace=p4?installFinanceWorkspaceV33(runtime,{document,p4,readRole:()=>currentRole(sc03),notify:(message,kind)=>notify(runtime,message,kind)}):null;
  const qrisCashOutUi=p4?installQrisCashOutUiV33(runtime,{document,p4,readRole:()=>currentRole(sc03),notify:(message,kind)=>notify(runtime,message,kind)}):null;
  const r8DailyUx=installR8DailyUxRefinement(runtime,{readRole:()=>currentRole(sc03),readCupRows:()=>p5Packaging?.shiftControl?.cupRows?.()||[]});
  const r8InventorySafety=installR8InventorySafetyRefinement(runtime,{inventoryWorkspace,financeWorkspace,notify:(message,kind)=>notify(runtime,message,kind)});
  const r8ShiftClosing=installR8ShiftClosingIntegrity(runtime,{cupShiftControl:p5Packaging?.shiftControl});
  function ensureInventoryWorkspaceV32(){if(!inventoryWorkspace?.installed)inventoryWorkspace=installInventoryWorkspaceV32(runtime);return inventoryWorkspace}
  let salesGridPresentation=null;
  const backupActions=Object.freeze({
    backup:()=>typeof runtime?.backupDatabase==='function'?runtime.backupDatabase():notify(runtime,'Backup existing tidak tersedia pada runtime ini.','warning'),
    restore:()=>document?.getElementById?.('restore-file')?.click?.()??notify(runtime,'Restore existing tidak tersedia pada runtime ini.','warning')
  });
  function openFeature(key){
    if(key==='settings.materials-warehouse'){const v3=ensureInventoryWorkspaceV32();if(v3?.open)return v3.open?.('summary');return notify(runtime,'Bahan & Gudang V3 belum siap. Coba buka kembali sesaat lagi.','warning')}
    if(key==='ref01.appearance'){if(typeof runtime?.SJMobileUX?.openSettings==='function')return runtime.SJMobileUX.openSettings();return renderInfoPanel(document,{title:'Tampilan Aplikasi',message:'REF-01 mengikuti perangkat secara responsif. Kepadatan komponen menjaga target sentuh minimal 44px.',rows:[['Mobile','320 / 390 / 430'],['Tablet','≥ 768px'],['Desktop','≥ 1200px']]})}
    if(key==='ref01.security'){const s=sc04?.session?.snapshot?.()||{};return renderInfoPanel(document,{title:'Keamanan & Sinkronisasi',message:'Session Manager SC-04 adalah authority sesi.',rows:[['Session',s.envelope?'Tersimpan':'Tidak tersimpan'],['Koneksi',runtime?.navigator?.onLine===false?'Offline':'Online']]})}
    if(key==='ref01.backup') return renderInfoPanel(document,{title:'Backup & Restore',message:'Semua aksi memakai authority existing. Restore tetap membutuhkan guard Owner dan file backup terverifikasi.',rows:[['Backup','Unduh snapshot database existing'],['Restore','Pilih file JSON untuk restore existing']],actions:[{label:'Backup sekarang',run:backupActions.backup},{label:'Pilih file restore',run:backupActions.restore}]});
    if(key==='ref01.sensitive'){if(typeof runtime?.openModalHapusGranular==='function')return runtime.openModalHapusGranular();return notify(runtime,'Aksi data sensitif tidak tersedia pada runtime ini.','warning')}
    if(key==='ref01.logout'){if(typeof runtime?.SJAccountV5964?.logout==='function')return runtime.SJAccountV5964.logout();if(typeof runtime?.SJProductionArchitectureP3?.logout==='function')return runtime.SJProductionArchitectureP3.logout();return notify(runtime,'Logout existing tidak tersedia pada runtime ini.','warning')}
    const feature=sc03?.features?.get?.(key);if(feature?.open)return feature.open();return notify(runtime,'Fitur belum tersedia pada runtime ini.','warning');
  }
  function enhance(){
    if(!document)return false;ensureInventoryWorkspaceV32();const route=currentRoute(sc03),role=currentRole(sc03);const effectiveLayout=reconcileLayoutPreferences(document,runtime,{role});salesGridPresentation?.apply?.(effectiveLayout.productColumns);applyV31SurfaceGrammar(document);enhanceBottomNav(document,route);applyV31UxPolish(document,runtime,{role});reconcileRoleNavigation(document,runtime,role);tagSemanticScreens(document);installConnectivityBanner(document,runtime);renderSettingsLanding(document,runtime,sc03,media,openFeature);enhanceProfileAvatars(document,runtime,media);enhanceImageRemove(document);enhanceScanner(document,sc03);enhanceTransferDraft(document);syncTransferDraft(document);addStaleShiftAction(document,shift);salesShiftUx?.enhance?.();productionSales?.sortProducts?.([]);manualSync?.enhance?.();notificationRefinement?.reconcileAuthority?.();notificationRefinement?.syncUnreadBadge?.();salesHistory?.enhance?.();finishedWarehouse?.enhance?.();p5Packaging?.enhance?.();financeWorkspace?.enhance?.();qrisCashOutUi?.enhance?.();r8DailyUx?.enhance?.();r8InventorySafety?.enhance?.();r8ShiftClosing?.enhance?.();decorateCriticalOperationalSurfaces(document,runtime);decorateStockReferenceSurface(document);reconcileTransactionSurfaces(document);document.documentElement&&(document.documentElement.dataset.sjRef01='true');return true;
  }
  let enhanceScheduled=false;function scheduleEnhance(){if(enhanceScheduled)return;enhanceScheduled=true;const run=()=>{enhanceScheduled=false;try{enhance()}catch(_){}};if(typeof runtime?.requestAnimationFrame==='function')runtime.requestAnimationFrame(run);else setTimeout(run,0)}
  const presentationLifecycle=createPresentationLifecycle(runtime,{document,reconcile:()=>enhance()});presentationLifecycle.install();
  salesGridPresentation=installSalesGridPresentationAuthority(runtime,{document,getColumns:()=>Number(document?.documentElement?.dataset?.sjProductCols||3)});
  const localQaLayout=installLocalQaLayoutAuthority(runtime,{role:()=>currentRole(sc03),onChanged:()=>{reconcileLayoutPreferences(document,runtime,{role:currentRole(sc03)});presentationLifecycle.schedule('local-qa-layout-save')}});
  const operationalPresentation=installOperationalPresentationAuthority(runtime,{reconcile:()=>enhance()});
  const settingsPresentation=installSettingsPresentationAuthority(runtime,{reconcile:()=>{
    try{
      const container=document?.getElementById?.('mst-container-view');
      const onLanding=!container||container.style?.display==='none';
      if(currentRoute(sc03)==='settings'&&currentRole(sc03)==='owner'&&onLanding){
        renderSettingsLanding(document,runtime,sc03,media,openFeature,{force:true});
        enhanceProfileAvatars(document,runtime,media);
      }
    }catch(_){}
  }});
  const unsubscribeState=typeof sc03?.state?.subscribe==='function'?sc03.state.subscribe(snapshot=>presentationLifecycle.schedule(`state:${snapshot?.primary||'unknown'}`)):(()=>{});
  const api=Object.freeze({phase:'REF-01',owner:OWNER,sc03,sc04,media,shift,legacyShiftClose,salesShiftUx,ownerDashboardHybrid,productionSales,manualSync,salesHistory,finishedWarehouse,inventoryWorkspace,p5Packaging,financeWorkspace,qrisCashOutUi,r8DailyUx,r8InventorySafety,r8ShiftClosing,presentationLifecycle,salesGridPresentation,localQaLayout,operationalPresentation,settingsPresentation,backupActions,openFeature,enhance,scheduleEnhance,stop:()=>{unsubscribeState();localQaLayout.stop();salesGridPresentation?.stop?.();operationalPresentation.stop();settingsPresentation.stop();presentationLifecycle.stop()},snapshot:()=>Object.freeze({phase:'REF-01',owner:OWNER,familyCount:SCREEN_FAMILIES.length,families:SCREEN_FAMILIES,implicitCapabilities:IMPLICIT_CAPABILITIES,referenceCoverage:Object.keys(REFERENCE_MATRIX),route:currentRoute(sc03),presentation:presentationLifecycle.snapshot()})});
  Object.defineProperty(runtime,'__SJ_REF01_RUNTIME',{value:api,writable:false,configurable:false,enumerable:false});
  try{enhance()}catch(error){runtime?.console?.warn?.('[REF01] initial enhancement skipped',error)}
  return api;
}
