# R2 TDD evidence

The R2 behavior test was written against the exact Production bootstrap/frozen QRIS baselines.

RED on original Production bootstrap:
- 1/2 PASS
- 1/2 FAIL
- observed: 0 listeners, 2 full pending reads, 1 full signal read

GREEN after R2 bootstrap change:
- 2/2 PASS
- 0 FAIL
- observed first evidence load: 5 narrow listeners, 0 full pending reads, 0 full signal reads, 1 exact pending-id read for late-review ownership
- repeated evidence refresh: listener count unchanged at 5 and no additional full-subtree reads

The test also locks the frozen module hashes:
- deferred compat: d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355
- manual bypass: 80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156
