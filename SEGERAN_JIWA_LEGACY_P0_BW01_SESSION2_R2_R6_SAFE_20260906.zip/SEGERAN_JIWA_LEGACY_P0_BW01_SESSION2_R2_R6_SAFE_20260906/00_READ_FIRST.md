# P0-BW01 Session 2 R2 — R6-safe correction

This package replaces the first P0-BW01 attempt after fresh Codespaces regression found two release-gate failures.

## Why R1 stopped
The first patch edited `src/compat/rc01-qris-deferred-settlement-compat.js`.
R6B and R6D intentionally freeze that R6A authority at SHA256:

`d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355`

Codespaces full regression correctly stopped at 554/556 with exactly two failures.
No commit/push/Production action should be performed from R1.

## R2 correction
R2 leaves both frozen QRIS runtime modules byte-identical:
- `src/compat/rc01-qris-deferred-settlement-compat.js`
- `src/compat/rc01-qris-manual-bypass.js`

Instead, it changes only the deferred-settlement runtime bootstrap so the existing frozen 1.4 s refresh calls read an in-memory event cache. The cache is fed by five narrowly-scoped Firebase listeners:
- pending status = WAITING_QRIS
- pending status = MATCHED
- pending status = FINALIZING
- pending status = MANUAL_FALLBACK
- signals resolutionState = REVIEW_REQUIRED

Thus the frozen compatibility timer may still call the runtime every 1.4 s, but on production Firebase those calls no longer perform full `pending` + `signals` subtree reads.

## Files changed by R2
- `src/app/qris-deferred-settlement-bootstrap.js`
- `tests/p0-bw01-runtime-event-cache.test.mjs`

No schema migration. No new Firebase write. No Supabase. Zero-cost architecture preserved.
