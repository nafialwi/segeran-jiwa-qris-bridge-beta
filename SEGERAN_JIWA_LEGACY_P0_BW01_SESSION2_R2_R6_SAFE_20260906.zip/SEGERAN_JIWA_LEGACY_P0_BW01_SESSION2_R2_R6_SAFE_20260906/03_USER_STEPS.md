# User steps

1. Create GitHub branch `transfer/p0-bw01-r2-upload` from `main`.
2. Upload only the R2 ZIP at repository root and commit it on that transfer branch.
3. In the existing Codespace, remain in `/workspaces/p0-bw01-transfer` on `p0-bw01-firebase-bandwidth`.
4. `git fetch origin`
5. Export ZIP from remote transfer branch to `/tmp` with `git show` (no Codespaces upload).
6. Extract to `/tmp`.
7. Run `RECOVER_R1_AND_APPLY_R2.sh`.
8. Do not commit/push until the final output says `SESSION 2 R2 LOCAL GATE PASS` and ChatGPT audits the screenshot.
