# Root cause of R1 regression failure

Fresh Codespaces evidence:
- tests: 556
- pass: 554
- fail: 2

Failures:
1. R6B: `ref01 entry installs the loading hardening module without modifying R6A QRIS compat`
2. R6D: `package exposes dedicated gate without weakening R6A-R6C authorities`

Both compared the modified QRIS compat SHA with the frozen expected SHA `d2464646...`.
The R1 changed SHA was `12cb86ddaaa1778479bd69559a22b9507307b136be5f927913d7e11a927ac231`.

Conclusion: the bandwidth diagnosis remains valid, but the modification boundary was wrong. R2 moves the hardening below the frozen compatibility authority, into `qris-deferred-settlement-bootstrap.js`.
