#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH="p0-bw01-firebase-bandwidth"
EXPECTED_HEAD_SHORT="292bfc2"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/P0_BW01_R2_R6_SAFE_EVENT_CACHE.patch"

hard_stop(){
  echo >&2
  echo "HARD STOP: $*" >&2
  echo "Jangan commit/push/merge." >&2
  exit 1
}

[[ "$(git rev-parse --is-inside-work-tree 2>/dev/null || true)" == "true" ]] || hard_stop "Bukan repository Git."
cd "$(git rev-parse --show-toplevel)"
[[ "$(git branch --show-current)" == "$EXPECTED_BRANCH" ]] || hard_stop "Branch harus $EXPECTED_BRANCH."
[[ "$(git rev-parse --short=7 HEAD)" == "$EXPECTED_HEAD_SHORT" ]] || hard_stop "HEAD harus baseline $EXPECTED_HEAD_SHORT."

# This worktree was created specifically for P0-BW01. Preserve R1 evidence before discarding its failed uncommitted build/patch output.
BACKUP="/tmp/p0-bw01-r1-failed-$(date +%Y%m%d-%H%M%S).patch"
git diff --binary > "$BACKUP" || true
echo "R1 evidence backup: $BACKUP"

# Return only this isolated P0 worktree to its exact baseline. Never run this script on main.
git reset --hard HEAD
git clean -fd
[[ -z "$(git status --porcelain)" ]] || hard_stop "Worktree gagal kembali bersih."

sha_check(){
  local expected="$1" file="$2" actual
  [[ -f "$file" ]] || hard_stop "File baseline tidak ditemukan: $file"
  actual="$(sha256sum "$file" | awk '{print $1}')"
  [[ "$actual" == "$expected" ]] || hard_stop "Baseline hash berbeda: $file expected=$expected actual=$actual"
}

sha_check d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355 src/compat/rc01-qris-deferred-settlement-compat.js
sha_check 80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156 src/compat/rc01-qris-manual-bypass.js
sha_check be8380798923df1ce45edbf2bd6c36e08eaa076843db6b13bdacbed117fbead9 src/app/qris-deferred-settlement-bootstrap.js

git apply --check "$PATCH_FILE"
git apply "$PATCH_FILE"

echo
echo "[1/5] Targeted R2 test"
node --test tests/p0-bw01-runtime-event-cache.test.mjs

echo
echo "[2/5] Existing Manual QRIS regression"
node --test tests/rc01-qris-manual-bypass.test.mjs

echo
echo "[3/5] Build"
mkdir -p audit
npm run build

echo
echo "[4/5] Full regression"
npm run verify

echo
echo "[5/5] R6D release gate"
npm run verify:rc01:s10c-r6d

git diff --check -- src/app/qris-deferred-settlement-bootstrap.js tests/p0-bw01-runtime-event-cache.test.mjs

# Frozen authorities must still be byte-identical after build/verify.
sha_check d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355 src/compat/rc01-qris-deferred-settlement-compat.js
sha_check 80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156 src/compat/rc01-qris-manual-bypass.js

echo
echo "============================================================"
echo "SESSION 2 R2 LOCAL GATE PASS"
echo "Branch: $EXPECTED_BRANCH"
echo "Frozen R6A QRIS compat/manual: PRESERVED"
echo "Production: BELUM DISENTUH"
echo "============================================================"
echo
git status --short
