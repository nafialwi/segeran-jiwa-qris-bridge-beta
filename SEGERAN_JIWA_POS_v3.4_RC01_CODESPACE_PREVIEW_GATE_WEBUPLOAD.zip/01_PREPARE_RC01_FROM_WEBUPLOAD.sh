#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_SLUG="${RC01_EXPECTED_REPO_SLUG:-nafialwi/segeran-jiwa-qris-bridge-beta}"
EXPECTED_MAIN="${RC01_EXPECTED_MAIN:-98aee48cb6e9dbc6cc317022d66aef3643093370}"
BRANCH="${RC01_BRANCH:-rc01-v3.4-release-candidate}"
EXPECTED_INDEX="ae0db0fd429bbc7527cb34de4b452313c7f5ab2fe81bfe66afa5fb3f39da6fc4"
EXPECTED_FILE_COUNT=1318
CALLER_PWD="$PWD"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
TREE_MANIFEST="$HERE/checksums/RC01_EXPECTED_TREE_SHA256.txt"
PAYLOAD_MANIFEST="$HERE/checksums/RC01_PAYLOAD_SHA256.txt"

stop(){ echo; echo "STOP: $*" >&2; exit 20; }
pass(){ echo "PASS: $*"; }

for c in git node npm sha256sum; do command -v "$c" >/dev/null || stop "$c is not available"; done
[[ -d "$PAYLOAD" ]] || stop "payload directory missing"
[[ -f "$TREE_MANIFEST" ]] || stop "tree checksum manifest missing"
[[ -f "$PAYLOAD_MANIFEST" ]] || stop "payload checksum manifest missing"

cd "$HERE"
sha256sum -c "$PAYLOAD_MANIFEST" >/tmp/rc01-payload-check.log || { cat /tmp/rc01-payload-check.log; stop "package payload checksum mismatch"; }
pass "package payload checksums"

REPO="$(git -C "$CALLER_PWD" rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO" && -n "${CODESPACE_NAME:-}" && -d /workspaces ]]; then
  REPO="$(find /workspaces -mindepth 1 -maxdepth 2 -type d -name .git -printf '%h\n' 2>/dev/null | head -n1 || true)"
fi
[[ -n "$REPO" && -d "$REPO/.git" ]] || stop "cannot locate Codespace git repository; cd to repo root and rerun"
cd "$REPO"

echo "Repository: $REPO"
REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
[[ -n "$REMOTE_URL" ]] || stop "origin remote missing"
case "$REMOTE_URL" in *"$EXPECTED_SLUG"*) ;; *) stop "origin is not expected repository: $REMOTE_URL" ;; esac
pass "expected existing GitHub repository"

CURRENT_BRANCH="$(git branch --show-current)"
[[ "$CURRENT_BRANCH" == "$BRANCH" ]] || stop "open Codespace on branch '$BRANCH'; current branch is '$CURRENT_BRANCH'"
[[ -z "$(git status --porcelain)" ]] || { git status --short; stop "working tree is not clean; do not delete/commit anything blindly"; }
pass "RC branch working tree initially clean"

git fetch --quiet origin main "$BRANCH"
REMOTE_MAIN="$(git rev-parse origin/main)"
LOCAL_HEAD="$(git rev-parse HEAD)"
REMOTE_RC="$(git rev-parse "origin/$BRANCH" 2>/dev/null || true)"
[[ "$REMOTE_MAIN" == "$EXPECTED_MAIN" ]] || stop "origin/main changed: expected $EXPECTED_MAIN but found $REMOTE_MAIN. Return this message to ChatGPT."
[[ -n "$REMOTE_RC" && "$LOCAL_HEAD" == "$REMOTE_RC" ]] || stop "local RC branch is not synchronized with origin/$BRANCH"
[[ "$(git merge-base origin/main HEAD)" == "$EXPECTED_MAIN" ]] || stop "RC branch does not descend from expected main authority"
pass "main authority $EXPECTED_MAIN remains untouched"

# Web-upload bootstrap branch must differ from main by exactly one helper ZIP and nothing else.
mapfile -t DIFF_LINES < <(git diff --name-status origin/main...HEAD)
[[ "${#DIFF_LINES[@]}" -eq 1 ]] || { printf '%s\n' "${DIFF_LINES[@]}"; stop "RC bootstrap branch must contain exactly one uploaded helper ZIP before preparation"; }
STATUS="${DIFF_LINES[0]%%$'\t'*}"
UPLOAD_FILE="${DIFF_LINES[0]#*$'\t'}"
[[ "$STATUS" == "A" ]] || stop "the only bootstrap change must be an added ZIP, found status '$STATUS'"
case "$UPLOAD_FILE" in
  SEGERAN_JIWA_POS_v3.4_RC01_CODESPACE_PREVIEW_GATE_WEBUPLOAD*.zip) ;;
  *) stop "unexpected bootstrap file '$UPLOAD_FILE'; expected RC01 web-upload helper ZIP" ;;
esac
[[ -f "$UPLOAD_FILE" ]] || stop "uploaded helper ZIP not present in repository root"
pass "isolated web-upload bootstrap commit contains only $UPLOAD_FILE"

# Remove helper from the final RC tree, then overlay exact authority payload.
rm -f -- "$UPLOAD_FILE"
cp -a "$PAYLOAD"/. "$REPO"/
pass "helper ZIP removed from final tree; RC01 payload overlaid"

echo
echo "=== FRESH RC01 VERIFICATION ==="
npm run verify:rc01 | tee /tmp/rc01-verify.log

grep -q "# pass 439" /tmp/rc01-verify.log || stop "fresh test count is not 439 PASS"
grep -q "# fail 0" /tmp/rc01-verify.log || stop "fresh tests contain failures"
grep -q "RC-01 release contract PASS" /tmp/rc01-verify.log || stop "RC01 release verifier did not PASS"
pass "fresh verify:rc01 = 439/439 + release contract PASS"

echo
echo "=== CLOUDFLARE CURRENT BUILD COMMAND REHEARSAL ==="
npm run build:ref01 | tee /tmp/rc01-cloudflare-build.log
REF_SHA="$(sha256sum dist-ref01/index.html | awk '{print $1}')"
RC_SHA="$(sha256sum dist-rc01/index.html | awk '{print $1}')"
[[ "$REF_SHA" == "$EXPECTED_INDEX" ]] || stop "dist-ref01 runtime hash mismatch: $REF_SHA"
[[ "$RC_SHA" == "$EXPECTED_INDEX" ]] || stop "dist-rc01 runtime hash mismatch: $RC_SHA"
[[ "$REF_SHA" == "$RC_SHA" ]] || stop "Cloudflare REF01 output is not identical to RC01 runtime"
pass "Cloudflare build:ref01 runtime == RC01 runtime ($EXPECTED_INDEX)"

# Restore packaged authority after verifier-generated audit rewrites.
cp -a "$PAYLOAD"/. "$REPO"/

TMP_EXPECT="$(mktemp)"; TMP_ACTUAL="$(mktemp)"
awk '{sub(/^\.\//,"",$2); print $2}' "$TREE_MANIFEST" | sort > "$TMP_EXPECT"
find . -path './.git' -prune -o -type f -printf '%P\n' | sort > "$TMP_ACTUAL"
ACTUAL_COUNT="$(wc -l < "$TMP_ACTUAL" | tr -d ' ')"
[[ "$ACTUAL_COUNT" == "$EXPECTED_FILE_COUNT" ]] || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "unexpected file count $ACTUAL_COUNT; expected $EXPECTED_FILE_COUNT"; }
cmp -s "$TMP_EXPECT" "$TMP_ACTUAL" || { diff -u "$TMP_EXPECT" "$TMP_ACTUAL" || true; stop "repository file set does not exactly match RC01 source authority"; }
sha256sum -c "$TREE_MANIFEST" >/tmp/rc01-tree-check.log || { tail -n 80 /tmp/rc01-tree-check.log; stop "RC01 full-tree checksum mismatch"; }
rm -f "$TMP_EXPECT" "$TMP_ACTUAL"
pass "exact 1318-file RC01 source tree checksums"

git add -A
[[ -n "$(git status --porcelain)" ]] || stop "no RC01 changes detected"

if ! git config user.name >/dev/null || ! git config user.email >/dev/null; then
  stop "git identity is not configured. No commit was made. Send this STOP message to ChatGPT."
fi

git commit -m "release: stage v3.4 RC-01 preview candidate" >/tmp/rc01-commit.log
cat /tmp/rc01-commit.log
COMMIT="$(git rev-parse HEAD)"

[[ "$(git rev-parse origin/main)" == "$EXPECTED_MAIN" ]] || stop "origin/main moved unexpectedly"
[[ "$(git branch --show-current)" == "$BRANCH" ]] || stop "not on RC01 branch after commit"
[[ -z "$(git status --porcelain)" ]] || stop "working tree not clean after local commit"
pass "local RC01 candidate commit created on preview branch; main unchanged"

echo
echo "============================================================"
echo "RC01-S07 WEB-UPLOAD CODESPACE PREPARE: PASS"
echo "branch=$BRANCH"
echo "main=$EXPECTED_MAIN"
echo "bootstrap_remote_commit=$REMOTE_RC"
echo "rc_commit=$COMMIT"
echo "tests=439/439 PASS"
echo "rc_verifier=PASS"
echo "runtime_sha256=$EXPECTED_INDEX"
echo "main_pushed=NO"
echo "rc_final_push=NO"
echo "cloudflare_production_mutated=NO"
echo "firebase_mutated=NO"
echo "appmint_gate=CLOSED"
echo "NEXT=STOP and send this summary to ChatGPT before final RC branch push"
echo "============================================================"
