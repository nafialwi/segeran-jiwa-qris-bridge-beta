# SEGERAN JIWA POS v3.4 RC-01 — GitHub Web Upload → Codespace Preview Gate

Use this variant when uploading directly into Codespaces is difficult.

## Safety model

- Never upload this ZIP to `main`.
- Create branch `rc01-v3.4-release-candidate` FROM `main` in GitHub first.
- Upload exactly this ZIP as the only change on that RC branch and commit it there.
- Cloudflare may create an initial preview from that bootstrap commit; ignore it. It is a non-production preview only.
- Open Codespace on the RC branch, extract this ZIP to `/tmp`, and run the preparation script.
- The script verifies that the branch differs from immutable main only by this one helper ZIP, removes the helper ZIP from the final tree, overlays exact RC01 authority, runs 439/439 verification, verifies the runtime hash, commits locally, and STOPS before the final push.
- `main`, Firebase, Cloudflare Production, and AppMint are never mutated by the script.

## GitHub mobile/web steps

1. Open `nafialwi/segeran-jiwa-qris-bridge-beta`.
2. Open the branch selector currently showing `main`.
3. Create branch exactly: `rc01-v3.4-release-candidate` from `main`.
4. Confirm the branch selector now shows `rc01-v3.4-release-candidate`.
5. Use **Add file → Upload files** and upload this ZIP into repository root.
6. Commit the upload to **rc01-v3.4-release-candidate**, NOT `main`.
7. Create/open a Codespace for branch `rc01-v3.4-release-candidate`.

## Codespace terminal

From repository root, run:

```bash
rm -rf /tmp/rc01-gate
mkdir -p /tmp/rc01-gate
unzip -q SEGERAN_JIWA_POS_v3.4_RC01_CODESPACE_PREVIEW_GATE_WEBUPLOAD.zip -d /tmp/rc01-gate
bash /tmp/rc01-gate/01_PREPARE_RC01_FROM_WEBUPLOAD.sh
```

If your phone renamed the local download before GitHub upload, use the actual filename in the `unzip` command. The filename must still start with `SEGERAN_JIWA_POS_v3.4_RC01_CODESPACE_PREVIEW_GATE_WEBUPLOAD` and end in `.zip`.

STOP when the script finishes. Do not push yet. Send the final terminal summary/screenshot to ChatGPT.
