# SEGERAN JIWA POS v3.4 RC-01 — Codespace Preview Gate

Purpose: prepare the exact RC-01 candidate on a NON-PRODUCTION Git branch, verify it, commit it locally, and STOP before remote push.

Safety locks built into the script:
- expected repo: `nafialwi/segeran-jiwa-qris-bridge-beta`;
- expected current `origin/main`: `98aee48cb6e9dbc6cc317022d66aef3643093370`;
- new branch only: `rc01-v3.4-release-candidate`;
- refuses dirty working tree;
- refuses existing local/remote RC branch;
- runs fresh `npm run verify:rc01`;
- requires 439/439 test suite to pass indirectly through the verifier;
- requires RC01 release verifier PASS;
- requires Cloudflare's current `npm run build:ref01` runtime hash to equal RC01 runtime hash `ae0db0fd429bbc7527cb34de4b452313c7f5ab2fe81bfe66afa5fb3f39da6fc4`;
- restores generated audit files to the packaged authority after verification;
- verifies the complete 1318-file RC source tree checksum manifest;
- creates a LOCAL commit only;
- DOES NOT run `git push` and DOES NOT change Cloudflare/Firebase/AppMint/main.

## In GitHub Codespaces

1. Open a Codespace for repository `nafialwi/segeran-jiwa-qris-bridge-beta` on branch `main`.
2. Upload `SEGERAN_JIWA_POS_v3.4_RC01_CODESPACE_PREVIEW_GATE.zip` into the Codespace repository root.
3. In Terminal run exactly:

```bash
mv SEGERAN_JIWA_POS_v3.4_RC01_CODESPACE_PREVIEW_GATE.zip /tmp/rc01-gate.zip
rm -rf /tmp/rc01-gate
mkdir -p /tmp/rc01-gate
unzip -q /tmp/rc01-gate.zip -d /tmp/rc01-gate
bash /tmp/rc01-gate/01_PREPARE_RC01_BRANCH.sh
```

4. Do NOT run any push command yet. Send ChatGPT the final terminal summary/screenshot.

If the script prints `STOP`, do not improvise. Send the exact STOP message back to ChatGPT.
