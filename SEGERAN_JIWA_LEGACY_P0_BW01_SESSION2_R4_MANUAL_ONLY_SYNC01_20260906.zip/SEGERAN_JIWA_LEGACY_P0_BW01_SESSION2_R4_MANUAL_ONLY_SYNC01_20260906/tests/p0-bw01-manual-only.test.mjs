import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';

const SOURCE='src/app/qris-deferred-settlement-bootstrap.js';
const sha=path=>createHash('sha256').update(readFileSync(path)).digest('hex');

function loadInstaller(){
  let source=readFileSync(SOURCE,'utf8');
  source=source.replace(/^import .*;\s*$/gm,'').replace('export function installQrisDeferredSettlementRuntime','function installQrisDeferredSettlementRuntime');
  const context={
    console,Promise,Object,Array,String,Number,Boolean,Math,JSON,Error,TypeError,
    POS_ROOT:'toko_segeranjiwa_v58',QRIS_ROOT:'toko_segeranjiwa_qris_beta_v1',
    policy:{
      isUnresolvedParkedPending:()=>true,
      isLateQuarantineStatus:()=>true,
      classifyLateSignalConflict:()=>({status:'LATE_AFTER_CANCEL'})
    }
  };
  context.globalThis=context;
  vm.createContext(context);
  vm.runInContext(`${source}\nthis.__install=installQrisDeferredSettlementRuntime;`,context,{filename:SOURCE});
  return context.__install;
}

test('P0-BW01 manual-only preserves frozen QRIS compat/manual modules byte-for-byte',()=>{
  assert.equal(sha('src/compat/rc01-qris-deferred-settlement-compat.js'),'d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355');
  assert.equal(sha('src/compat/rc01-qris-manual-bypass.js'),'80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156');
});

test('P0-BW01 manual-only runtime performs zero automatic Firebase reads/listeners',async()=>{
  let refCalls=0;
  const db={ref(){refCalls++;throw new Error('AUTOMATIC_FIREBASE_ACCESS_FORBIDDEN')}};
  const install=loadInstaller();
  const runtime={};
  const api=install(runtime,{db,writer:{}});
  assert.equal(api.mode,'MANUAL_ONLY');
  assert.equal(api.automaticFirebaseReads,false);
  assert.equal(JSON.stringify(await api.findOwnedUnresolvedParked('kasir01')),'[]');
  assert.equal(JSON.stringify(await api.findLateReviewSignals('kasir01')),'[]');
  assert.equal(await api.readPending('P1'),null);
  assert.equal(JSON.stringify(await api.readPendingRows()),'{}');
  assert.equal(await api.readSignal('S1'),null);
  assert.equal(JSON.stringify(await api.readSignalRows()),'{}');
  assert.equal(refCalls,0);
});

test('P0-BW01 manual-only bootstrap contains no RTDB read/listener primitives',()=>{
  const source=readFileSync(SOURCE,'utf8');
  for(const token of ['.once(','.on(','.orderByChild(','.equalTo('])assert.equal(source.includes(token),false,`forbidden automatic QRIS token remains: ${token}`);
  assert.match(source,/mode:\s*'MANUAL_ONLY'/);
  assert.match(source,/automaticFirebaseReads:\s*false/);
});
