import { POS_ROOT, QRIS_ROOT } from '../data/firebase-client.js';
import * as policy from '../domain/qris-deferred-settlement-policy.js';

const manualOnlyError=()=>{
  const error=new Error('QRIS_MANUAL_ONLY_AUTOMATION_DISABLED');
  error.code='QRIS_MANUAL_ONLY_AUTOMATION_DISABLED';
  return error;
};

export function installQrisDeferredSettlementRuntime(runtime=globalThis,{p4=runtime?.__SJ_P4_FINANCE_RUNTIME,db=null}={}){
  if(runtime?.__SJ_QRIS_DEFERRED_SETTLEMENT_RUNTIME)return runtime.__SJ_QRIS_DEFERRED_SETTLEMENT_RUNTIME;
  const resolvedDb=db??p4?.db;
  if(!resolvedDb||typeof resolvedDb.ref!=='function')throw new Error('QRIS_S10A_DB_REQUIRED');

  const disabledWriter=Object.freeze({
    attachSnapshotAndPark:async()=>{throw manualOnlyError()},
    quarantineLateSignal:async()=>{throw manualOnlyError()},
    contract:Object.freeze({manualOnly:true,automaticSettlement:false})
  });
  const manualPolicy=Object.freeze({
    ...policy,
    isUnresolvedParkedPending:()=>false,
    isLateQuarantineStatus:()=>false,
    classifyLateSignalConflict:()=>null
  });
  async function readPending(){return null}
  async function readPendingRows(){return {}}
  async function readSignal(){return null}
  async function readSignalRows(){return {}}
  async function findOwnedUnresolvedParked(){return []}
  async function findLateReviewSignals(){return []}

  const api=Object.freeze({
    phase:'RC01-S10A',mode:'MANUAL_ONLY',automaticFirebaseReads:false,automaticSettlement:false,
    db:resolvedDb,writer:disabledWriter,policy:manualPolicy,
    readPending,readPendingRows,readSignal,readSignalRows,findOwnedUnresolvedParked,findLateReviewSignals,
    roots:Object.freeze({pos:POS_ROOT,qris:QRIS_ROOT})
  });
  Object.defineProperty(runtime,'__SJ_QRIS_DEFERRED_SETTLEMENT_RUNTIME',{value:api,writable:false,configurable:false,enumerable:false});
  return api;
}
