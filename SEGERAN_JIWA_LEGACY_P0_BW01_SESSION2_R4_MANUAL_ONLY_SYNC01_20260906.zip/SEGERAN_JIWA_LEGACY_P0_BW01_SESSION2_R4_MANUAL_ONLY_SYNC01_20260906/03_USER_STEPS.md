# Langkah user — model GitHub ROOT upload

1. Download ZIP R4.
2. Di GitHub buat branch transfer baru dari `main`: `transfer/p0-bw01-r4-upload`.
3. Upload ZIP R4 ke ROOT branch tersebut dan commit hanya ZIP.
4. Di Codespaces gunakan worktree `/workspaces/p0-bw01-transfer` dan branch `p0-bw01-firebase-bandwidth`.
5. `git fetch origin`
6. Ambil ZIP ke /tmp memakai `git show origin/transfer/p0-bw01-r4-upload:<ZIP> > /tmp/P0BW01_R4.zip`.
7. Extract ke `/tmp/p0bw01-r4`.
8. Jalankan `APPLY_R4_MANUAL_ONLY_SYNC01.sh`.
9. Jika `SESSION 2 R4 LOCAL GATE PASS`, commit 5-file delta dan push branch yang sama.
10. Tunggu Cloudflare Preview hijau. UAT: Manual QRIS + Tutup Shift. Jangan Production sebelum UAT PASS.
