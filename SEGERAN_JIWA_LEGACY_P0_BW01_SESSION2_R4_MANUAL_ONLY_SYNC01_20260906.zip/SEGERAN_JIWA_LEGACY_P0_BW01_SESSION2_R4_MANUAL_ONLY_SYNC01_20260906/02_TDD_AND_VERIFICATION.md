# TDD & verification

RED dilakukan terhadap R3/current sync authority:
- Manual-only mode belum ada.
- Automatic QRIS `.once()`/listeners masih ada.
- Full device registration payload masih diklasifikasikan CRITICAL.
- Result: 2 PASS / 3 FAIL.

GREEN setelah minimal R4:
- 5/5 targeted tests PASS.
- QRIS frozen compat SHA256 tetap `d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355`.
- Manual QRIS SHA256 tetap `80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156`.
- `node --check` untuk kedua source berubah PASS.
- `git diff --check` PASS.

Full repository regression/build/SC03/SC04/R6D harus dijalankan oleh `APPLY_R4_MANUAL_ONLY_SYNC01.sh` di Codespaces karena package lokal tidak membawa seluruh repository/dependencies.
