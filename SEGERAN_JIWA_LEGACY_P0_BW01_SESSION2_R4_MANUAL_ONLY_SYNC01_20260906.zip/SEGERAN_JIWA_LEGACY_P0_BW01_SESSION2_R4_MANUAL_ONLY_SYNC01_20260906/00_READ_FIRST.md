# P0-BW01 R4 — MANUAL-ONLY QRIS + SYNC01 SHIFT UNBLOCK

Tujuan emergency correction ini hanya dua:

1. **QRIS menjadi manual verification only.** Runtime deferred QRIS tidak lagi melakukan Firebase read/listener otomatis. Frozen Manual QRIS tetap byte-for-byte.
2. **Device presence/register write tidak lagi memblokir tutup shift.** Payload register/heartbeat yang hanya berisi presence/identity metadata diklasifikasikan ADVISORY. Revoke/security dan write bisnis tetap CRITICAL.

R4 diterapkan di branch existing `p0-bw01-firebase-bandwidth`, bukan `main`.

Jangan Promote Production sebelum Preview UAT: login, Manual QRIS, dan tutup shift.
