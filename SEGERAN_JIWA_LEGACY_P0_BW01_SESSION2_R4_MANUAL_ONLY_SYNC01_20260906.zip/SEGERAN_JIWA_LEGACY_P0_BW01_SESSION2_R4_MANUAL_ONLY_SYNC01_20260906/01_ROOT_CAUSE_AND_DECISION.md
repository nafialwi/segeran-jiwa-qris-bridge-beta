# Root cause & business decision

## Bandwidth QRIS
Root cause P0-BW01 adalah `refreshEvidence()` compatibility timer 1.4 detik yang sebelumnya berujung ke full pending/signals reads. R3 mengganti read menjadi event cache, tetapi keputusan bisnis terbaru adalah lebih sederhana: Segeran Jiwa POS legacy memakai **Manual QRIS Verification only**.

R4 mengubah deferred-settlement runtime menjadi manual-only no-network surface. Frozen compatibility module tetap ada untuk release-gate compatibility, tetapi periodic refresh yang masih dipanggil modul frozen hanya menerima empty local state; tidak ada RTDB `.once`, `.on`, query, atau settlement writer otomatis dari bootstrap.

## Shift blocker
Verified runtime menunjukkan initial device registration melakukan `update()` ke `/global/deviceSessions/<device>` dengan field presence + identity metadata termasuk `id`, `deviceName`, `userId`, `user`, `role`, `startedAt`, `startedTs`, `revoked:false`, dan `authUid`.

S10C lama hanya mengizinkan subset heartbeat kecil, sehingga initial register jatuh ke `DEFAULT_CRITICAL`. Jika write ini lambat/stuck, `criticalPending=1` memblokir tutup shift.

R4 mengklasifikasikan payload register/presence tersebut ADVISORY hanya bila seluruh key berada pada allowlist, terdapat heartbeat timestamp, dan `revoked` bila hadir harus `false`. `revoked:true`, `revokedAt`, `revokedBy`, permission/security field, unknown field, transaksi, inventory, dan closing tetap fail-closed CRITICAL.
