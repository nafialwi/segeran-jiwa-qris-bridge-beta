#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH='p0-bw01-firebase-bandwidth'
R3_BOOTSTRAP_SHA='9aaa068a38a4644df11d2aa15132f7363c16c205e082f91b77a9eada208e0496'
R3_TEST_SHA='b87be1bdd7a7ded4c06414db606f28bce89e8239273ce0f6d78fdc31db939aa0'
SYNC_BASE_SHA='a5283642e0a7fcf2679845a60783628d1121340ef8c9bd94d0b10d3200474050'
FROZEN_COMPAT_SHA='d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355'
FROZEN_MANUAL_SHA='80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$SCRIPT_DIR/P0_BW01_R4_MANUAL_ONLY_SYNC01.patch"
QRIS_SOURCE='src/app/qris-deferred-settlement-bootstrap.js'
SYNC_SOURCE='src/compat/rc01-sync-authority.js'
OLD_TEST='tests/p0-bw01-runtime-event-cache.test.mjs'
MANUAL_TEST='tests/p0-bw01-manual-only.test.mjs'
SYNC_TEST='tests/p0-sync01-device-presence.test.mjs'
COMPAT_FILE='src/compat/rc01-qris-deferred-settlement-compat.js'
MANUAL_FILE='src/compat/rc01-qris-manual-bypass.js'

stop(){ echo "HARD STOP: $*" >&2; echo 'Jangan commit/push/merge.' >&2; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || stop 'Bukan Git repository.'
cd "$ROOT"
BRANCH="$(git branch --show-current)"
[[ "$BRANCH" == "$EXPECTED_BRANCH" ]] || stop "Branch harus $EXPECTED_BRANCH (sekarang: $BRANCH)."

# Tolerate only known generated untracked build artifacts. Never discard tracked work.
if [[ -n "$(git diff --name-only)" || -n "$(git diff --cached --name-only)" ]]; then
  stop 'Ada tracked/staged change sebelum R4. Worktree harus clean dari source change.'
fi
mapfile -t UNTRACKED < <(git ls-files --others --exclude-standard)
for p in "${UNTRACKED[@]}"; do
  case "$p" in
    dist-rc01/*|dist-ref01/*|dist-sc03/*|dist-sc04/*) ;;
    *) stop "Untracked file di luar generated dist: $p";;
  esac
done
if ((${#UNTRACKED[@]})); then
  git clean -fd -- dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null
fi
[[ -z "$(git status --short)" ]] || stop 'Worktree belum clean setelah generated cleanup.'

[[ -f "$QRIS_SOURCE" && "$(sha "$QRIS_SOURCE")" == "$R3_BOOTSTRAP_SHA" ]] || stop 'R3 QRIS bootstrap hash tidak cocok.'
[[ -f "$OLD_TEST" && "$(sha "$OLD_TEST")" == "$R3_TEST_SHA" ]] || stop 'R3 event-cache test hash tidak cocok.'
[[ -f "$SYNC_SOURCE" && "$(sha "$SYNC_SOURCE")" == "$SYNC_BASE_SHA" ]] || stop 'S10C sync-authority baseline hash tidak cocok.'
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat hash tidak cocok.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS hash tidak cocok.'

git apply --check "$PATCH" || stop 'R4 patch tidak clean pada R3 branch.'
git apply "$PATCH"
git diff --check || stop 'git diff --check gagal.'

EXPECTED_PRE="$(printf '%s\n' "$QRIS_SOURCE" "$SYNC_SOURCE" "$OLD_TEST" "$MANUAL_TEST" "$SYNC_TEST" | sort)"
ACTUAL_PRE="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$ACTUAL_PRE" == "$EXPECTED_PRE" ]] || { echo "$ACTUAL_PRE" >&2; stop 'Scope R4 tidak tepat 5 file.'; }

# Fast gates first.
node --check "$QRIS_SOURCE"
node --check "$SYNC_SOURCE"
node --test "$MANUAL_TEST" "$SYNC_TEST"
if grep -nE '\.(once|on|orderByChild|equalTo)[[:space:]]*\(' "$QRIS_SOURCE"; then
  stop 'Automatic QRIS Firebase read/listener primitive masih ada.'
fi
if grep -nE '\.(set|update|transaction|remove)[[:space:]]*\(' "$QRIS_SOURCE"; then
  stop 'Direct Firebase mutation token muncul di QRIS bootstrap.'
fi

# Existing regressions for the exact frozen manual QRIS path and S10C authority.
node --test tests/rc01-qris-manual-bypass.test.mjs
node --test tests/rc01-s10c-sync-authority.test.mjs

# Architectural boundaries before full suite.
node scripts/build-sc03.mjs
node scripts/verify-sc03.mjs
node scripts/build-sc04.mjs
node scripts/verify-sc04.mjs

# Full repository gates.
npm run build
npm run verify
npm run verify:rc01:s10c-r6d

[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah setelah gate.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah setelah gate.'

# Preserve only the intentional R4 delta after generated build/audit outputs.
TMP="$(mktemp -d)"
cp "$QRIS_SOURCE" "$TMP/qris.js"
cp "$SYNC_SOURCE" "$TMP/sync.js"
cp "$MANUAL_TEST" "$TMP/manual.test.mjs"
cp "$SYNC_TEST" "$TMP/sync.test.mjs"
git reset --hard HEAD >/dev/null
rm -f "$OLD_TEST"
cp "$TMP/qris.js" "$QRIS_SOURCE"
cp "$TMP/sync.js" "$SYNC_SOURCE"
cp "$TMP/manual.test.mjs" "$MANUAL_TEST"
cp "$TMP/sync.test.mjs" "$SYNC_TEST"
rm -rf "$TMP"
git clean -fd -- dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true

git diff --check || stop 'Final diff check gagal.'
node --test "$MANUAL_TEST" "$SYNC_TEST"
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah saat cleanup.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah saat cleanup.'

FINAL_PATHS="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$FINAL_PATHS" == "$EXPECTED_PRE" ]] || { git status --short; stop 'Final R4 scope bukan tepat 5 file.'; }

echo
echo 'SESSION 2 R4 LOCAL GATE PASS'
echo "Branch: $BRANCH"
echo 'QRIS: MANUAL VERIFICATION ONLY'
echo 'Automatic QRIS Firebase reads/listeners: OFF'
echo 'Device presence/register heartbeat: ADVISORY'
echo 'Revoke/security/business writes: tetap CRITICAL'
echo 'Frozen QRIS compat/manual: PRESERVED'
echo 'Production: BELUM DISENTUH'
echo 'Jangan merge ke main sebelum Preview UAT.'
