# User steps

1. Upload this ZIP to a new GitHub transfer branch created from `main`:
   `transfer/p0-bw01-r3-upload`
2. In Codespaces, stay in the isolated worktree:
   `/workspaces/p0-bw01-transfer`
3. Fetch origin, extract this ZIP to `/tmp`, and run `RECOVER_R2_AND_APPLY_R3.sh`.
4. Do not commit or push until the script prints `SESSION 2 R3 LOCAL GATE PASS` and the result is reviewed.
