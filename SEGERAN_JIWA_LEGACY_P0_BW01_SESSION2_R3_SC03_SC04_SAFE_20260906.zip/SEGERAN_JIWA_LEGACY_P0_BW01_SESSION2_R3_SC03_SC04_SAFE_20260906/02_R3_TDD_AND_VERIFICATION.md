# R3 TDD and local verification

A regression test was added before the R3 production change:
- requirement: `src/app/qris-deferred-settlement-bootstrap.js` must contain none of `.set(`, `.update(`, `.transaction(`, `.remove(`.

RED against R2:
- 3 tests total
- 2 pass
- 1 fail
- failing assertion: SC03/SC04 no-direct-mutation boundary

GREEN after R3:
- 3/3 pass
- event-cache behavior remains the same
- frozen QRIS hashes remain locked
- no forbidden direct-mutation token remains in the modified bootstrap
- Node syntax check passes

Full repository regression and R6D must still run in the real Codespaces repository. `RECOVER_R2_AND_APPLY_R3.sh` performs those gates automatically and does not claim success unless they all pass.
