# Root cause — R2 failure

Fresh Codespaces evidence from 2026-09-06 showed failures in:
- SC03 direct-mutation boundary test/verifier
- SC04 mutation allowlist verifier

The reported offender was only:
`src/app/qris-deferred-settlement-bootstrap.js`

R2 contains no Firebase write in that bootstrap. The trigger was local cache code using `pendingOwnerCache.set(...)` on a JavaScript `Map`. The repository guard is intentionally lexical and matches `.set(` regardless of receiver type.

Therefore R3 does not weaken or edit the verifier. It removes the ambiguous `.set(` token from the application bootstrap while preserving runtime behavior.
