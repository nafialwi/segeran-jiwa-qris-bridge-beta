#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH='p0-bw01-firebase-bandwidth'
BASELINE_REF='292bfc2'
BASELINE_BOOTSTRAP_SHA='be8380798923df1ce45edbf2bd6c36e08eaa076843db6b13bdacbed117fbead9'
FROZEN_COMPAT_SHA='d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355'
FROZEN_MANUAL_SHA='80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$SCRIPT_DIR/P0_BW01_R3_SC03_SC04_SAFE_EVENT_CACHE.patch"
TEST_FILE='tests/p0-bw01-runtime-event-cache.test.mjs'
SOURCE_FILE='src/app/qris-deferred-settlement-bootstrap.js'
COMPAT_FILE='src/compat/rc01-qris-deferred-settlement-compat.js'
MANUAL_FILE='src/compat/rc01-qris-manual-bypass.js'

stop(){ echo "HARD STOP: $*" >&2; echo 'Jangan commit/push/merge.' >&2; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || stop 'Bukan Git repository.'
cd "$ROOT"
BRANCH="$(git branch --show-current)"
[[ "$BRANCH" == "$EXPECTED_BRANCH" ]] || stop "Branch harus $EXPECTED_BRANCH (sekarang: $BRANCH)."
HEAD_SHA="$(git rev-parse HEAD)"
BASELINE_SHA="$(git rev-parse "$BASELINE_REF^{commit}" 2>/dev/null)" || stop "Baseline $BASELINE_REF tidak ditemukan."
[[ "$HEAD_SHA" == "$BASELINE_SHA" ]] || stop "HEAD harus baseline $BASELINE_REF."

mkdir -p /tmp/p0bw01-r3-evidence
git status --short > /tmp/p0bw01-r3-evidence/status-before.txt || true
git diff > /tmp/p0bw01-r3-evidence/r2-failed.diff || true

# Recover only this isolated worktree from the failed, uncommitted R2 attempt.
git reset --hard HEAD >/dev/null
rm -f "$TEST_FILE"
[[ -z "$(git status --short)" ]] || stop 'Worktree tidak bersih setelah recovery R2; tidak melakukan git clean.'

[[ "$(sha "$SOURCE_FILE")" == "$BASELINE_BOOTSTRAP_SHA" ]] || stop 'Bootstrap baseline hash tidak cocok.'
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat hash tidak cocok.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS hash tidak cocok.'

# R3 patch must apply cleanly to the exact Production baseline.
git apply --check "$PATCH" || stop 'R3 patch tidak clean pada baseline.'
git apply "$PATCH"
git diff --check || stop 'git diff --check gagal.'

# Scope before generated build artifacts appear.
mapfile -t CHANGED < <(git status --short | sed -E 's/^.. //')
for p in "${CHANGED[@]}"; do
  [[ "$p" == "$SOURCE_FILE" || "$p" == "$TEST_FILE" ]] || stop "Unexpected pre-gate change: $p"
done

# Fast targeted gates first.
node --test "$TEST_FILE"
node --check "$SOURCE_FILE"
if grep -nE '\.(set|update|transaction|remove)[[:space:]]*\(' "$SOURCE_FILE"; then
  stop 'SC03/SC04 forbidden mutation token masih ada di bootstrap.'
fi

# Reproduce the exact architectural guards that failed R2 before spending time on full regression.
node scripts/build-sc03.mjs
node scripts/verify-sc03.mjs
node scripts/build-sc04.mjs
node scripts/verify-sc04.mjs

# QRIS-specific frozen authority regression.
node --test tests/rc01-qris-manual-bypass.test.mjs

# Full repository and final R6D gates.
npm run build
npm run verify
npm run verify:rc01:s10c-r6d

[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah setelah gates.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah setelah gates.'

# Verification commands generate tracked build/audit artifacts. Preserve only the intentional R3 source+test delta.
TMP_SOURCE="$(mktemp)"
TMP_TEST="$(mktemp)"
cp "$SOURCE_FILE" "$TMP_SOURCE"
cp "$TEST_FILE" "$TMP_TEST"
git reset --hard HEAD >/dev/null
rm -f "$TEST_FILE"
cp "$TMP_SOURCE" "$SOURCE_FILE"
mkdir -p "$(dirname "$TEST_FILE")"
cp "$TMP_TEST" "$TEST_FILE"
rm -f "$TMP_SOURCE" "$TMP_TEST"

git diff --check || stop 'Final diff check gagal.'
node --test "$TEST_FILE"
[[ "$(sha "$COMPAT_FILE")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen QRIS compat berubah saat cleanup.'
[[ "$(sha "$MANUAL_FILE")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Frozen Manual QRIS berubah saat cleanup.'

FINAL_STATUS="$(git status --short)"
echo "$FINAL_STATUS"
FINAL_PATHS="$(printf '%s\n' "$FINAL_STATUS" | sed -E 's/^.. //' | sort)"
EXPECTED_PATHS="$(printf '%s\n' "$SOURCE_FILE" "$TEST_FILE" | sort)"
[[ "$FINAL_PATHS" == "$EXPECTED_PATHS" ]] || stop 'Final worktree scope bukan tepat source+test R3.'

echo
echo 'SESSION 2 R3 LOCAL GATE PASS'
echo "Branch: $BRANCH"
echo "Baseline: $BASELINE_REF"
echo 'SC03/SC04 mutation boundary: PASS'
echo 'Frozen R6A QRIS compat/manual: PRESERVED'
echo 'Production: BELUM DISENTUH'
echo 'Jangan commit/push sebelum hasil ini direview.'
