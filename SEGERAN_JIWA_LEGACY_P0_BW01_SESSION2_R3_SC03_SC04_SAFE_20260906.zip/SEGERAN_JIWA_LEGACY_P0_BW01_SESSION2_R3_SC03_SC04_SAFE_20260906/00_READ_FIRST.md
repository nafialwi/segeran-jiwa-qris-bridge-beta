# P0-BW01 Session 2 R3 — SC03/SC04 Safe

R3 is a minimal correction to R2 after real Codespaces regression evidence.

## What R2 got right
- Frozen R6A QRIS compat/manual modules remained unchanged.
- Bandwidth hardening moved into the runtime bootstrap.
- Targeted event-cache behavior passed.

## Why R2 failed
The SC03/SC04 source guards use a broad static pattern that flags any `.set(...)`, `.update(...)`, `.transaction(...)`, or `.remove(...)` call in `src/app` as a direct RTDB mutation. R2 used JavaScript `Map#set(...)` only for an in-memory owner cache, but the verifier cannot distinguish that from Firebase `.set(...)`.

## R3 correction
R3 keeps the same event-cache design but replaces `Map#set/get/has` with a plain null-prototype object and bracket access. No Firebase writer or schema is changed.

Frozen modules stay byte-for-byte unchanged:
- deferred compat SHA256: d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355
- manual bypass SHA256: 80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156

Production remains untouched until Preview UAT and explicit approval.
