# EMG-D1-P1 R3 Implementation Report

## Correction
- Force fresh REF01 rebuild before baseline Cup-01B regression.
- Preserve all P1 R2 D1 emergency behavior.
- Preserve Fast Owner Dashboard cache-first/non-blocking design.
- Preserve frozen QRIS/manual/ref01/sync authority checks.
- Use isolated branch `emg-d1-p1-r3-dashboard-fast`.

## Why
`tests/legacy-cup-01b-product-cup-ui.test.mjs` reads `dist-ref01/index.html`. The committed generated artifact can lag behind current `scripts/build-ref01.mjs`, so testing before rebuilding creates a false-red baseline. R3 fixes the gate ordering, not the product feature.


## R4 SC04 boundary correction
- `src/compat/emg-d1-p1-dashboard-fast.js`: Map caches replaced with null-prototype object caches; TTL/coalescing behavior preserved.
- `src/compat/emg-d1-p1-emergency.js`: DOM `.remove()` replaced by `detach()`/`removeChild`; cart Map replaced by object map; emergency auth token and mode are memory-only.
- No Firebase writer was added. Existing SC04 writer allowlist is unchanged.
- Pre-provision gate now runs `verify-sc04.mjs`, `verify-sc03.mjs`, and R6D before provisioning D1/Worker.
