#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
PAYLOAD="$PACKAGE_DIR/payload"
[[ -f "$PACKAGE_DIR/SHA256SUMS.txt" ]] || { echo "HARD STOP: SHA256SUMS.txt package tidak ada" >&2; exit 1; }
(cd "$PACKAGE_DIR" && sha256sum -c SHA256SUMS.txt) || { echo "HARD STOP: checksum package tidak valid" >&2; exit 1; }
BRANCH="emg-d1-p1-r4-sc04-safe"
WT="/workspaces/emg-d1-p1-r4-sc04-safe"

say(){ printf '\n=== %s ===\n' "$*"; }
fail(){ printf '\nHARD STOP: %s\n' "$*" >&2; exit 1; }

REPO="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[[ -n "$REPO" ]] || fail "Jalankan dari dalam repository Segeran Jiwa POS lama"
cd "$REPO"
git remote get-url origin >/dev/null 2>&1 || fail "origin remote tidak ditemukan"

say "Fetch canonical GitHub main"
git fetch origin main --prune
BASE="$(git rev-parse origin/main)"
BASE_SHORT="$(git rev-parse --short origin/main)"
[[ -n "$BASE" ]] || fail "origin/main tidak tersedia"

# Never mutate caller checkout or previous failed P1 worktree.
if [[ -e "$WT" ]]; then fail "$WT sudah ada. Jangan hapus paksa; kirim screenshot/status untuk recovery."; fi
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then fail "Local branch $BRANCH sudah ada. Jangan overwrite otomatis."; fi

say "Create isolated R3 worktree from origin/main $BASE_SHORT"
git worktree add -b "$BRANCH" "$WT" "$BASE"
cd "$WT"

say "Baseline repair/gate: force fresh Cup-01B REF01 build + npm test"
[[ -f tests/legacy-cup-01b-product-cup-ui.test.mjs ]] || fail "Cup-01B test belum ada di main. Merge Cup-01B Production lebih dulu."
grep -q 'PRODUCT_CUP_UI_ENTRY' scripts/build-ref01.mjs || fail "Cup-01B build baseline belum ada di main"
# main contains the Cup-01B source/build authority, but the committed dist-ref01 artifact may be stale.
# Force a deterministic rebuild BEFORE any test that reads dist-ref01/index.html.
rm -f dist-ref01/.ref01-build-fingerprint
npm run build:ref01
node --test tests/legacy-cup-01b-product-cup-ui.test.mjs
npm test
say "Baseline R6D gate"
npm run verify:rc01:s10c-r6d

for p in \
  src/compat/rc01-qris-deferred-settlement-compat.js \
  src/compat/rc01-qris-manual-bypass.js \
  src/ref01-entry.js \
  src/compat/rc01-sync-authority.js; do
  [[ -f "$p" ]] || fail "Authority file missing: $p"
done
FROZEN_BEFORE="$(sha256sum src/compat/rc01-qris-deferred-settlement-compat.js src/compat/rc01-qris-manual-bypass.js src/ref01-entry.js src/compat/rc01-sync-authority.js)"
grep -q 'QRIS_MANUAL_ONLY_GUARD' scripts/build-ref01.mjs || fail "P0-BW01 R6 manual-only baseline tidak ditemukan"
! grep -q 'EMG_D1_P1_ENTRY\|DASHBOARD_FAST_P1_ENTRY' scripts/build-ref01.mjs || fail "EMG-D1 P1/R2 sudah ada di baseline"

say "TDD RED: P1 presence must fail before implementation"
mkdir -p tests
cp "$PAYLOAD/tests/emg-d1-p1-presence.test.mjs" tests/
set +e
node --test tests/emg-d1-p1-presence.test.mjs >/tmp/emg-d1-p1-r3-red.log 2>&1
RED_RC=$?
set -e
cat /tmp/emg-d1-p1-r3-red.log
[[ $RED_RC -ne 0 ]] || fail "TDD RED tidak merah; feature mungkin sudah ada atau test salah"
grep -q 'harus ada' /tmp/emg-d1-p1-r3-red.log || fail "TDD RED gagal bukan karena feature belum ada"

say "Install EMG-D1 P1 R4 SC04-safe + Dashboard Fast source/docs/tests"
mkdir -p emergency-d1/src src/compat docs/superpowers/specs docs/superpowers/plans scripts tests
cp "$PAYLOAD/emergency-d1/schema.sql" emergency-d1/schema.sql
cp "$PAYLOAD/emergency-d1/src/core.js" emergency-d1/src/core.js
cp "$PAYLOAD/emergency-d1/src/worker.js" emergency-d1/src/worker.js
cat > emergency-d1/.gitignore <<'GITIGNORE'
.wrangler/
.dev.vars
.env
.env.*
GITIGNORE
cp "$PAYLOAD/src/compat/emg-d1-p1-emergency.js" src/compat/emg-d1-p1-emergency.js
cp "$PAYLOAD/src/compat/emg-d1-p1-dashboard-fast.js" src/compat/emg-d1-p1-dashboard-fast.js
cp "$PAYLOAD/src/compat/emg-d1-p1-config.js.in" src/compat/emg-d1-p1-config.js.in
cp "$PAYLOAD/tests/emg-d1-p1-core.test.mjs" tests/
cp "$PAYLOAD/tests/emg-d1-p1-contract.test.mjs" tests/
cp "$PAYLOAD/tests/emg-d1-p1-dashboard-fast.test.mjs" tests/
cp "$PAYLOAD/tests/emg-d1-p1-sc04-boundary.test.mjs" tests/
cp "$PAYLOAD/docs/superpowers/specs/2026-09-07-emg-d1-p1-design.md" docs/superpowers/specs/
cp "$PAYLOAD/docs/superpowers/plans/2026-09-07-emg-d1-p1-implementation-plan.md" docs/superpowers/plans/
cp "$PAYLOAD/scripts/provision_emg_d1_p1.sh" scripts/emg-d1-p1-provision.sh
chmod +x scripts/emg-d1-p1-provision.sh

# Placeholder is valid only for pre-provision regression; replaced before final verification/commit.
sed 's|__SJ_EMERGENCY_API_BASE__|https://placeholder.workers.dev|g' src/compat/emg-d1-p1-config.js.in > src/compat/emg-d1-p1-config.js
python3 "$PAYLOAD/scripts/transform_build_ref01.py"

say "Force fresh REF01 build (fixes stale Cup-01B artifact risk)"
rm -f dist-ref01/.ref01-build-fingerprint
npm run build:ref01
node --test tests/legacy-cup-01b-product-cup-ui.test.mjs

say "TDD GREEN + Dashboard Fast + SC04 boundary contract before Cloudflare provisioning"
node --check emergency-d1/src/core.js
node --check emergency-d1/src/worker.js
node --check src/compat/emg-d1-p1-emergency.js
node --check src/compat/emg-d1-p1-dashboard-fast.js
node --test tests/emg-d1-p1-presence.test.mjs tests/emg-d1-p1-core.test.mjs tests/emg-d1-p1-contract.test.mjs tests/emg-d1-p1-dashboard-fast.test.mjs tests/emg-d1-p1-sc04-boundary.test.mjs

say "Pre-provision SC04/SC03 + release-boundary gate"
node scripts/verify-sc04.mjs
node scripts/verify-sc03.mjs
npm run verify:rc01:s10c-r6d

say "Provision/reuse Cloudflare Worker + D1 (may open Wrangler login once)"
bash scripts/emg-d1-p1-provision.sh
[[ -f src/compat/emg-d1-p1-config.js ]] || fail "Final emergency API config missing"
! grep -q '__SJ_EMERGENCY_API_BASE__\|placeholder.workers.dev' src/compat/emg-d1-p1-config.js || fail "Final config masih placeholder"
rm -f src/compat/emg-d1-p1-config.js.in
rm -rf .wrangler emergency-d1/.wrangler

say "Force exact final REF01 rebuild after Worker URL materialization"
rm -f dist-ref01/.ref01-build-fingerprint
npm run build:ref01
node --test tests/legacy-cup-01b-product-cup-ui.test.mjs tests/emg-d1-p1-dashboard-fast.test.mjs

say "Fresh FINAL verification on exact tree to be committed"
node --test tests/emg-d1-p1-presence.test.mjs tests/emg-d1-p1-core.test.mjs tests/emg-d1-p1-contract.test.mjs tests/emg-d1-p1-dashboard-fast.test.mjs tests/emg-d1-p1-sc04-boundary.test.mjs
npm run verify
npm run verify:ref01
npm run verify:rc01:s10c-r6d
git diff --check

say "Restore only generated audit/dist artifacts from verification"
if [[ -d audit ]]; then git restore --source=HEAD -- audit 2>/dev/null || true; fi
for d in dist-*; do
  [[ -e "$d" ]] || continue
  git restore --source=HEAD -- "$d" 2>/dev/null || true
  git clean -fd -- "$d" >/dev/null 2>&1 || true
done
rm -rf .wrangler emergency-d1/.wrangler

FROZEN_AFTER="$(sha256sum src/compat/rc01-qris-deferred-settlement-compat.js src/compat/rc01-qris-manual-bypass.js src/ref01-entry.js src/compat/rc01-sync-authority.js)"
[[ "$FROZEN_BEFORE" == "$FROZEN_AFTER" ]] || fail "Frozen QRIS/manual/ref01/sync authority berubah"

say "Exact final scope guard"
mapfile -t CHANGED < <(git status --porcelain -uall | sed -E 's/^.. //' | sort)
ALLOWED=(
  "docs/superpowers/plans/2026-09-07-emg-d1-p1-implementation-plan.md"
  "docs/superpowers/specs/2026-09-07-emg-d1-p1-design.md"
  "emergency-d1/.gitignore"
  "emergency-d1/schema.sql"
  "emergency-d1/src/core.js"
  "emergency-d1/src/worker.js"
  "emergency-d1/wrangler.toml"
  "scripts/build-ref01.mjs"
  "scripts/emg-d1-p1-provision.sh"
  "src/compat/emg-d1-p1-config.js"
  "src/compat/emg-d1-p1-dashboard-fast.js"
  "src/compat/emg-d1-p1-emergency.js"
  "tests/emg-d1-p1-contract.test.mjs"
  "tests/emg-d1-p1-core.test.mjs"
  "tests/emg-d1-p1-dashboard-fast.test.mjs"
  "tests/emg-d1-p1-presence.test.mjs"
  "tests/emg-d1-p1-sc04-boundary.test.mjs"
)
mapfile -t ALLOWED_SORTED < <(printf '%s\n' "${ALLOWED[@]}" | sort)
if [[ "$(printf '%s\n' "${CHANGED[@]}")" != "$(printf '%s\n' "${ALLOWED_SORTED[@]}")" ]]; then
  printf 'Expected scope:\n'; printf '  %s\n' "${ALLOWED_SORTED[@]}"
  printf 'Actual scope:\n'; printf '  %s\n' "${CHANGED[@]}"
  fail "Final worktree scope drift"
fi

say "Commit and push Preview branch"
git add -- "${ALLOWED[@]}"
git diff --cached --check
git commit -m "feat: add D1 emergency standby and fast owner dashboard"
git push -u origin "$BRANCH"
COMMIT="$(git rev-parse --short HEAD)"
API_BASE="$(python3 - <<'PY'
import re
s=open('src/compat/emg-d1-p1-config.js').read()
m=re.search(r"apiBase:'([^']+)'",s)
print(m.group(1) if m else '')
PY
)"
OWNER_FILE="/workspaces/.sj-emg-d1-private/OWNER_KEY.txt"
OWNER_KEY="$(cat "$OWNER_FILE" 2>/dev/null || true)"

cat <<RESULT

============================================================
EMG-D1-P1 R4 ONESHOT PASS
============================================================
Base main: $BASE_SHORT
Branch:    $BRANCH
Commit:    $COMMIT
Worker:    $API_BASE
D1:        segeran-jiwa-emergency-db
Owner Key: $OWNER_KEY
Owner Key backup: $OWNER_FILE

Firebase normal authority: UNCHANGED
Automatic failover: OFF
Emergency sales: Tunai / Transfer / QRIS MANUAL
Emergency shift/open-close + expense + inventory events: ENABLED
operationId idempotency + audit: ENABLED
Owner Beranda: CACHE-FIRST, non-blocking exact refresh in background
Owner dashboard exact refresh: <= 1 per 5 minutes per browser/date
Previous-day comparison refresh: <= 1 per 30 minutes per browser/date
Cup-01B product UI regression: PRESERVED
P0-BW01 R6 QRIS/manual + sync authority: PRESERVED
Full verify + SC04 + SC03 + REF01 + R6D: PASS
Branch sudah dipush untuk Cloudflare Pages Preview.
Production/main: BELUM DISENTUH

NEXT: tunggu Preview branch hijau, uji Beranda cepat + EMG D1 P1.
SIMPAN OWNER KEY sebelum menutup Codespace.
============================================================
RESULT
