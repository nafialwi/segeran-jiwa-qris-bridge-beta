# EMG-D1-P1 R2 Implementation Report

## Root cause of the previous P1 stop
The previous run stopped at the existing `legacy-cup-01b-product-cup-ui.test.mjs` gate. R2 treats REF01 output as generated state that must be rebuilt explicitly after build/source transforms, then verifies Cup-01B before any Cloudflare resource provisioning.

## Owner Beranda performance root cause
The current Owner Beranda path sets `Memuat Beranda...`, then awaits `SJX.dayModel()`; final refinement also awaits the prior-day `aggregateExact()` before returning the model. Those exact reads can delay the first paint while Firebase reconnects, even though `cloudData` already contains usable local/synchronized state.

## R2 design
- first paint: local `cloudData` only;
- background exact current-day refresh: max once per 5 minutes per date/browser session;
- previous-day comparison: max once per 30 minutes per date/browser session;
- no `setInterval`, no new `db.ref`, no automatic poller;
- reports are not changed;
- Product Cup 01B entry stays before the frozen R6 tail;
- D1 emergency config/runtime remain outside the frozen transaction/QRIS authorities.
