# EMG-D1-P1 R2 — READ FIRST

One-shot package for Segeran Jiwa POS legacy:

1. Cloudflare D1 + Worker emergency standby backend.
2. Emergency Tunai / Transfer / QRIS manual sales, shift, expense, inventory event, audit/idempotency.
3. Firebase remains the normal/default authority; no automatic failover.
4. R2 fixes Owner Beranda so it paints from local `cloudData` immediately instead of blocking on Firebase exact reads.
5. R2 forces fresh REF01 builds around Cup-01B regression to prevent stale generated-artifact failures.
6. QRIS R6/manual and sync authority files remain frozen.

Use the root-GitHub upload workflow. The script creates a new isolated worktree and does not touch the caller's dirty `main` checkout or the previous failed P1 worktree.
