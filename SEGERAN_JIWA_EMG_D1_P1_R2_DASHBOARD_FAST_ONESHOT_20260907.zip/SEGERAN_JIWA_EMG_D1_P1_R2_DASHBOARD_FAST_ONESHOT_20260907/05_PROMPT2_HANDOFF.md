# Prompt Besar 2 handoff

Proceed only after EMG-D1-P1 R2 Preview passes.

Prompt Besar 2 must implement reconciliation/failback from D1 emergency ledger to Firebase with owner preview/approval, idempotent replay, partial-failure handling, anti-double revenue/cash/stock, audit, and full failure drill. Preserve R2 cache-first Owner Beranda and P0-BW01 R6 manual QRIS.
