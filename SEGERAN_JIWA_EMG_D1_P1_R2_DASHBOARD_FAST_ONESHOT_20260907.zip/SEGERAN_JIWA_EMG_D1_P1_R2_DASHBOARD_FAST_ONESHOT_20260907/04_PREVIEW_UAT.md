# EMG-D1-P1 R2 Preview UAT

## A. Beranda speed
1. Open Preview as Owner.
2. Tap Penjualan, then tap Beranda.
3. Beranda should appear immediately from local data; it must not remain on `Memuat Beranda...` waiting for Firebase.
4. During reconnect, small sync copy may say `Data lokal • memperbarui di latar belakang`; KPI may refresh shortly afterward.
5. Repeat Beranda several times within 5 minutes. UI remains immediate; no repeated blocking exact query should be visible.

## B. Existing Cup-01B
Open Add/Edit Product and confirm Cup Paper 10 Oz selector remains present.

## C. D1 emergency standby
1. Open `MODE DARURAT D1`.
2. Authenticate using the OWNER KEY printed by the one-shot script.
3. Check D1 health.
4. While Firebase normal, create/update emergency master snapshot.
5. Activate emergency only for Preview/drill.
6. Open emergency shift, perform Tunai, Transfer and QRIS manual drill sales, record one expense, then close emergency shift.
7. Confirm normal Firebase POS remains separate and automatic failover never occurs.

Do not merge to Production before A+B+C pass.
