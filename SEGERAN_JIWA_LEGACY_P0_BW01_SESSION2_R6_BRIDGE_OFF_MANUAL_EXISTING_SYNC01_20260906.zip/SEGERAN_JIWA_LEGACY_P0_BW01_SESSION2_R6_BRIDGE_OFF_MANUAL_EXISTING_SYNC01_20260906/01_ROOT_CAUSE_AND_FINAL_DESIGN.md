# Root Cause + Final Design

## Yang sebenarnya menghabiskan bandwidth
Ada dua automatic QRIS runtime yang hidup walaupun kasir sudah memakai Manual QRIS:

1. Frozen legacy `SJQrisSignalBeta` melakukan listener Firebase `signals`, `pending`, `events`, dan `inboxState` saat login.
2. `rc01-qris-deferred-settlement-compat.js` menjalankan `refreshEvidence()` setiap 1.4 detik; runtime lama membaca QRIS pending/signals.

Manual bypass memang sudah mencegah pembukaan transaksi QRIS otomatis, tetapi **tidak menghentikan dua background runtime tersebut**.

## R6
Build REF01 mengganti marker awal frozen Beta secara deterministik dengan short circuit yang:

- memasang sentinel `SJQrisSignalBeta` disabled;
- memasang sentinel `SJRC01S10AQrisCompat` disabled;
- `return` sebelum body Beta berjalan.

Akibatnya:

- Beta tidak memasang listener;
- S10A compat file tetap dimuat sesuai build contract tetapi langsung return sebelum polling 1.4 detik;
- existing Manual QRIS yang dimuat sesudahnya tetap mengambil alur QRIS dan memanggil canonical `processTransaction()`;
- frozen source dan `ref01-entry` tidak perlu diubah.
