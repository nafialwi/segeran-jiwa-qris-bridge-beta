#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH='p0-bw01-firebase-bandwidth'
EXPECTED_HEAD_SHORT='1429afc'
BUILD_SHA='7b4b9d436c736bb414ffe1bda1b976cf73578b02c1b45e6813b24dc71cd4f86e'
SYNC_BASE_SHA='a5283642e0a7fcf2679845a60783628d1121340ef8c9bd94d0b10d3200474050'
REF01_ENTRY_SHA='22572c210c5f5c31d570709a023ef36c6983035427aa8a264b88e35098c39f7b'
R3_BOOTSTRAP_SHA='9aaa068a38a4644df11d2aa15132f7363c16c205e082f91b77a9eada208e0496'
R3_TEST_SHA='b87be1bdd7a7ded4c06414db606f28bce89e8239273ce0f6d78fdc31db939aa0'
FROZEN_COMPAT_SHA='d24646468e7d8595ff1b356d9ba6a6f732efd1e40f02e8f6c28f924a39a7e355'
FROZEN_MANUAL_SHA='80d867cca96a0f4b5dfdc2012e51f9e53da999ed4df9e09d4c6aeb7f87363156'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$SCRIPT_DIR/P0_BW01_R6_MANUAL_BRIDGE_OFF_SYNC01.patch"
BUILD='scripts/build-ref01.mjs'
SYNC='src/compat/rc01-sync-authority.js'
ENTRY='src/ref01-entry.js'
BOOTSTRAP='src/app/qris-deferred-settlement-bootstrap.js'
R3_TEST='tests/p0-bw01-runtime-event-cache.test.mjs'
MANUAL='src/compat/rc01-qris-manual-bypass.js'
COMPAT='src/compat/rc01-qris-deferred-settlement-compat.js'
BRIDGE_TEST='tests/p0-bw01-manual-bridge-off.test.mjs'
SYNC_TEST='tests/p0-sync01-device-presence.test.mjs'

stop(){ echo "HARD STOP: $*" >&2; echo 'Jangan commit/push/merge.' >&2; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || stop 'Bukan Git repository.'
cd "$ROOT"
BRANCH="$(git branch --show-current)"
HEAD_SHORT="$(git rev-parse --short HEAD)"
[[ "$BRANCH" == "$EXPECTED_BRANCH" ]] || stop "Branch harus $EXPECTED_BRANCH (sekarang: $BRANCH)."
[[ "$HEAD_SHORT" == "$EXPECTED_HEAD_SHORT" ]] || stop "HEAD harus committed R3 $EXPECTED_HEAD_SHORT (sekarang: $HEAD_SHORT)."
[[ -z "$(git diff --cached --name-only)" ]] || stop 'Ada staged changes. Script tidak menyentuh staged work.'

# R5 gagal setelah full verify dapat meninggalkan source R5 + generated audit/dist.
# Hanya state yang sudah dikenal yang boleh dipulihkan.
mapfile -t TRACKED < <(git diff --name-only)
for p in "${TRACKED[@]}"; do
  case "$p" in
    audit/*|dist-rc01/*|dist-ref01/*|dist-sc03/*|dist-sc04/*|"$BOOTSTRAP"|"$SYNC"|"$ENTRY"|"$R3_TEST") ;;
    *) stop "Tracked change tidak dikenal dari failed R5: $p" ;;
  esac
done
mapfile -t UNTRACKED < <(git ls-files --others --exclude-standard)
for p in "${UNTRACKED[@]}"; do
  case "$p" in
    audit/*|dist-rc01/*|dist-ref01/*|dist-sc03/*|dist-sc04/*|tests/p0-bw01-manual-only.test.mjs|tests/p0-bw01-manual-only-entry.test.mjs|tests/p0-sync01-device-presence.test.mjs) ;;
    *) stop "Untracked file tidak dikenal dari failed R5: $p" ;;
  esac
done

EVIDENCE_DIR="/tmp/p0bw01-r6-recovery-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$EVIDENCE_DIR"
git status --short > "$EVIDENCE_DIR/status-before.txt"
git diff > "$EVIDENCE_DIR/r5-failed-diff.patch" || true

# Restore hanya isolated P0 worktree ke committed R3, bukan workspace main.
git restore --source=HEAD --worktree -- audit dist-rc01 dist-ref01 dist-sc03 dist-sc04 "$BOOTSTRAP" "$SYNC" "$ENTRY" "$R3_TEST" 2>/dev/null || true
rm -f tests/p0-bw01-manual-only.test.mjs tests/p0-bw01-manual-only-entry.test.mjs tests/p0-sync01-device-presence.test.mjs
git clean -fd -- audit dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true
[[ -z "$(git status --short)" ]] || { git status --short; stop 'Recovery failed R5 belum menghasilkan clean committed R3 worktree.'; }

[[ "$(sha "$BUILD")" == "$BUILD_SHA" ]] || stop 'build-ref01 R3 hash tidak cocok.'
[[ "$(sha "$SYNC")" == "$SYNC_BASE_SHA" ]] || stop 'sync-authority R3 hash tidak cocok.'
[[ "$(sha "$ENTRY")" == "$REF01_ENTRY_SHA" ]] || stop 'ref01-entry berubah dari frozen R3.'
[[ "$(sha "$BOOTSTRAP")" == "$R3_BOOTSTRAP_SHA" ]] || stop 'R3 bootstrap hash tidak cocok.'
[[ "$(sha "$R3_TEST")" == "$R3_TEST_SHA" ]] || stop 'R3 event-cache test hash tidak cocok.'
[[ "$(sha "$COMPAT")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen deferred compat berubah.'
[[ "$(sha "$MANUAL")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Existing Manual QRIS berubah.'

git apply --check "$PATCH" || stop 'R6 patch tidak clean pada committed R3.'
git apply "$PATCH"
git diff --check || stop 'git diff --check gagal.'

EXPECTED_PATHS="$(printf '%s\n' "$BUILD" "$SYNC" "$BRIDGE_TEST" "$SYNC_TEST" | sort)"
ACTUAL_PATHS="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$ACTUAL_PATHS" == "$EXPECTED_PATHS" ]] || { git status --short; stop 'Scope R6 bukan tepat 4 file.'; }

# Fast gates: existing Manual QRIS remains unchanged; auto bridge is disabled before Beta/compat can run.
node --check "$BUILD"
node --check "$SYNC"
node --test "$BRIDGE_TEST" "$SYNC_TEST"
node --test tests/rc01-qris-manual-bypass.test.mjs
node --test tests/rc01-s10c-sync-authority.test.mjs

# Build once and prove production candidate contains the manual-only short circuit while old tag contract remains.
node scripts/build-ref01.mjs
grep -Fq 'QRIS_AUTOMATIC_BRIDGE_DISABLED_MANUAL_ONLY' dist-ref01/index.html || stop 'Generated REF01 belum mematikan QRIS automatic bridge.'
grep -Fq 'data-sj-rc01-s10a-qris="true"' dist-ref01/index.html || stop 'S10A script-tag contract hilang.'
grep -Fq 'data-sj-rc01-qris-manual="true"' dist-ref01/index.html || stop 'Existing Manual QRIS tidak termuat.'

# Architecture + full repository gates.
node scripts/build-sc03.mjs
node scripts/verify-sc03.mjs
node scripts/build-sc04.mjs
node scripts/verify-sc04.mjs
npm run build
npm run verify
npm run verify:rc01:s10c-r6d

[[ "$(sha "$COMPAT")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen deferred compat berubah setelah full gates.'
[[ "$(sha "$MANUAL")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Existing Manual QRIS berubah setelah full gates.'
[[ "$(sha "$ENTRY")" == "$REF01_ENTRY_SHA" ]] || stop 'ref01-entry berubah setelah full gates.'

# Keep only intentional R6 delta after generated build/audit files.
TMP="$(mktemp -d)"
cp "$BUILD" "$TMP/build-ref01.mjs"
cp "$SYNC" "$TMP/sync.js"
cp "$BRIDGE_TEST" "$TMP/bridge.test.mjs"
cp "$SYNC_TEST" "$TMP/sync.test.mjs"
git reset --hard HEAD >/dev/null
cp "$TMP/build-ref01.mjs" "$BUILD"
cp "$TMP/sync.js" "$SYNC"
cp "$TMP/bridge.test.mjs" "$BRIDGE_TEST"
cp "$TMP/sync.test.mjs" "$SYNC_TEST"
rm -rf "$TMP"
git clean -fd -- audit dist-rc01 dist-ref01 dist-sc03 dist-sc04 >/dev/null 2>&1 || true

git diff --check || stop 'Final diff check gagal.'
node --test "$BRIDGE_TEST" "$SYNC_TEST"
[[ "$(sha "$COMPAT")" == "$FROZEN_COMPAT_SHA" ]] || stop 'Frozen deferred compat berubah saat cleanup.'
[[ "$(sha "$MANUAL")" == "$FROZEN_MANUAL_SHA" ]] || stop 'Existing Manual QRIS berubah saat cleanup.'
[[ "$(sha "$ENTRY")" == "$REF01_ENTRY_SHA" ]] || stop 'ref01-entry berubah saat cleanup.'
FINAL_PATHS="$(git status --short | sed -E 's/^.. //' | sort)"
[[ "$FINAL_PATHS" == "$EXPECTED_PATHS" ]] || { git status --short; stop 'Final R6 scope bukan tepat 4 file.'; }

echo
echo 'SESSION 2 R6 LOCAL GATE PASS'
echo "Branch: $BRANCH"
echo 'QRIS existing Manual Verification: PRESERVED'
echo 'QRIS Signal Beta automatic bridge: OFF before startup'
echo 'QRIS S10A 1.4s polling compat: OFF before startup'
echo 'QRIS automatic Firebase listeners/reads: OFF'
echo 'Device presence/register heartbeat: ADVISORY'
echo 'Revoke/security/business writes: tetap CRITICAL'
echo 'Frozen Manual QRIS / deferred compat / ref01-entry: PRESERVED'
echo 'Production: BELUM DISENTUH'
echo "Recovery evidence: $EVIDENCE_DIR"
echo 'NEXT: commit 4-file R6 delta, push Preview, UAT QRIS manual + Tutup Shift.'
