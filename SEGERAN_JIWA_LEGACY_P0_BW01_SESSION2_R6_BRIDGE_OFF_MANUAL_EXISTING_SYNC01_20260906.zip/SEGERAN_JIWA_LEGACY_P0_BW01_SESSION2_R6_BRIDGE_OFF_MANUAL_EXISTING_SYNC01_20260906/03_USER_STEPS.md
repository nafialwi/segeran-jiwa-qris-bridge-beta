# User Steps

1. Upload ZIP R6 ke ROOT GitHub pada branch baru `transfer/p0-bw01-r6-upload` yang dibuat dari `main`.
2. Di isolated Codespace worktree: `cd /workspaces/p0-bw01-transfer`.
3. `git fetch origin`.
4. Ambil ZIP menggunakan `git show origin/transfer/p0-bw01-r6-upload:<nama-zip> > /tmp/P0BW01_R6.zip`.
5. Extract ke `/tmp/p0bw01-r6`.
6. Jalankan `APPLY_R6_BRIDGE_OFF_MANUAL_EXISTING_SYNC01.sh`.
7. Hanya jika `SESSION 2 R6 LOCAL GATE PASS`, commit 4 file final dan push Preview.
8. UAT Preview: QRIS existing manual, Diagnostik Critical Pending 0 untuk heartbeat, Tutup Shift.
