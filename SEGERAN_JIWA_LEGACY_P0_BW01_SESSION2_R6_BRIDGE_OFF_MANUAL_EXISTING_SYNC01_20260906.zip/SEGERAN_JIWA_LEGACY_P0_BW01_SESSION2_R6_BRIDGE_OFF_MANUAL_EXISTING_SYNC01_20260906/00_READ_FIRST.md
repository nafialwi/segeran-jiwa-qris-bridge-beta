# P0-BW01 Session 2 R6 — Bridge OFF, Existing Manual QRIS Preserved

Keputusan final operasional:

- Existing Manual QRIS **tidak diubah**.
- QRIS automatic Signal Beta bridge **tidak dijalankan**.
- S10A deferred-settlement compat tetap ada sebagai source/tag untuk release compatibility, tetapi dibuat **return sebelum startup**, sehingga timer polling 1.4 detik tidak aktif.
- `src/ref01-entry.js` **tidak diubah**.
- `src/compat/rc01-qris-manual-bypass.js` **tidak diubah**.
- `src/compat/rc01-qris-deferred-settlement-compat.js` **tidak diubah**.
- Device presence/register heartbeat diperbaiki menjadi ADVISORY agar tidak memblokir tutup shift; revoke/security/business write tetap CRITICAL.

R6 sengaja menggunakan build-time short circuit pada frozen legacy QRIS Beta agar build order dan frozen source authority tetap dipertahankan.
